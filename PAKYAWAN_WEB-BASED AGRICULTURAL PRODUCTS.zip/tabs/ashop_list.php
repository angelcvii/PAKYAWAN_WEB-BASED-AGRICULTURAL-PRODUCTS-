<div class="row" id="ashoplist_main">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            
            <div class="card-body" id="ashoplist_main_content">

            </div>
        </div>
    </div>
</div>
