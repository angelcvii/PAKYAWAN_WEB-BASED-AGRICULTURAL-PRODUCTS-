<div class="row" id="res_content">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
       
            <div class="card-body" id="hreservation_content">

            </div>
        </div>
    </div>
</div>
