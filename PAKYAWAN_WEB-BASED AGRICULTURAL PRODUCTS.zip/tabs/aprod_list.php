<div class="row" id="aprodlist_main">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            
            <div class="card-body" id="aprodlist_main_content">

            </div>
        </div>
    </div>
</div>
