<div id="main_dashboard_content">

	<div class="row mt-3">
		<div class="col-xl-3 flex-column d-flex grid-margin stretch-card">
			<div class="row flex-grow">
				<div class="col-sm-12 grid-margin stretch-card">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col">
									<h4 class="text-dark font-weight-bold mb-2">

										<?php

                                        $shopid = $_SESSION['uid'];

										include "../db.php";

										$sql = "SELECT *  FROM d_shop_views where shop_id = '$shopid' ";
										$result = $con->query($sql);

										$row_cnt = $result->num_rows;

										echo $row_cnt;

										?>

									</h4>
									<h4 class="card-title">Shop Views</h4>


								</div>

								<div class="col dashb_icon">
									<i class="fa fa-eye "></i>
								</div>

							</div>




						</div>
					</div>
				</div>

			</div>
		</div>


		<div class="col-xl-3 flex-column d-flex grid-margin stretch-card">
			<div class="row flex-grow">
				<div class="col-sm-12 grid-margin stretch-card">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col">
									<h4 class="text-dark font-weight-bold mb-2">

										<?php
										$served = 0;

										$sql = "SELECT id  FROM d_product where seller_id = '$shopid' ";
										$result = $con->query($sql);

										if ($result->num_rows > 0) {
										    while ($row = $result->fetch_assoc()) {
										        $prodid = $row['id'];

										      
										                $sqlz = "SELECT status  FROM d_reservation_details where product_id = '$prodid' ";
										                $resultz = $con->query($sqlz);
										                $rowz = $resultz->fetch_assoc();

										                $ostat = $rowz['status'];

										                if ($ostat == "Approved" || $ostat == "Completed") {
										                    $served++;
										                }
										            }
										        }
										    
										 else {
										    $served = 0;
										}

										echo $served;

										?>

									</h4>
									<h4 class="card-title">Served Customers</h4>

								</div>

								<div class="col dashb_icon">
									<i class="fa fa-users "></i>
								</div>

							</div>




						</div>
					</div>
				</div>

			</div>
		</div>

		<div class="col-xl-3 flex-column d-flex grid-margin stretch-card">
			<div class="row flex-grow">
				<div class="col-sm-12 grid-margin stretch-card">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col">
									<h4 class="text-dark font-weight-bold mb-2">

										<?php

										$sql = "SELECT *  FROM d_product where seller_id = '$shopid' ";
										$result = $con->query($sql);

										$row_cnt = $result->num_rows;

										echo $row_cnt;

										?>

									</h4>
									<h4 class="card-title">Products </h4>


								</div>

								<div class="col dashb_icon">
									<i class="fa fa-leaf "></i>
								</div>

							</div>




						</div>
					</div>
				</div>

			</div>
		</div>



		<div class="col-xl-3 flex-column d-flex grid-margin stretch-card">
			<div class="row flex-grow">
				<div class="col-sm-12 grid-margin stretch-card">
					<div class="card ">
						<div class="card-body dashb_icon_total">
							<div class="row ">
								<div class="col ">
									<h4 class="text-light font-weight-bold mb-2">

										<?php
										$delcrop = 0;

										$sql = "SELECT id  FROM d_product where seller_id = '$shopid' ";
										$result = $con->query($sql);

										if ($result->num_rows > 0) {
										    while ($row = $result->fetch_assoc()) {
										        $prodid = $row['id'];

										      
										                $sqlz = "SELECT status  FROM d_reservation_details where product_id = ' $prodid' ";
										                $resultz = $con->query($sqlz);
										                $rowz = $resultz->fetch_assoc();

										                $ostat = $rowz['status'];

										                if ($ostat == "Completed") {
										                    $delcrop++;
										                }
										            }
										        }
										    
										

										echo $delcrop;

										?>

									</h4>
									<h4 class="card-title text-light">Completed Reservation</h4>


								</div>

								<div class="col ">
									<i class="fa fa-clipboard "></i>
								</div>

							</div>




						</div>
					</div>
				</div>

			</div>
		</div>


	</div>
	<div class="row">


		<div class="col-lg-8 grid-margin stretch-card">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col">
							<h4 class="card-title">Reservation Request</h4>
						</div>
						<br>
						<div class="col text-right">

							<button class="btn btn-sm btn-success" onclick="sordertab()">See all &nbsp;<i
									class="fa fa-long-arrow-right" style="font-size:10px;"></i></button>
						</div>
					</div>



					<br>

					<div class="table-responsive">
						<table class="table">
							<thead>
								<tr>
									<th>Transaction No</th>
									<th>Name</th>

									<th>Address</th>
									<th>Reservation Date</th>

									<th>Status</th>
								</tr>
							</thead>
							<tbody>



								<?php


                                $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Pending'  order by id desc LIMIT 5 ";
										$resultz = $con->query($sqlz);
										if ($resultz->num_rows > 0) {
										    while ($rowz = $resultz->fetch_assoc()) {
										        $customer_id = $rowz['buyer_id'];
										        $drid = $rowz['id'];
										        $transaction_no = $rowz['transaction_no'];

										        $ostat = $rowz['status'];
										        $reservation_date = $rowz['added_date'];


										        $sqlg = "SELECT *  FROM m_user_info where userid = '$customer_id'";
										        $resultg = $con->query($sqlg);

										        if ($resultg->num_rows > 0) {
										            $rowg = $resultg->fetch_assoc();
										            $fullname = $rowg['fullname'];

										            $contact = $rowg['contact'];
										            $address = $rowg['address'];
										            $email = $rowg['email'];
										            $age = $rowg['age'];
										            $image = $rowg['image'];
										        }




										        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
										        $resultm = $con->query($sqlm);
										        if ($resultm->num_rows > 0) {
										            $rowm = $resultm->fetch_assoc();





										            ?>


								<tr>
									<td><?php echo  $transaction_no; ?>
									</td>
									<td><?php echo $fullname; ?></td>

									<td><?php echo $address; ?></td>
									<td><?php echo  $reservation_date; ?>
									</td>
									<td><?php echo $ostat; ?>
									</td>
								</tr>


								<?php

										        }
										    }
										} else {
										    ?>
								<tr>
									<td colspan="4">No Data Found !</td>
								</tr>
								<?php
										}



										?>





							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>



		<div class="col-lg-4 grid-margin stretch-card">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col">
							<h4 class="card-title">Recent Shop Views</h4>
						</div>
						<div class="col text-right">

							<button class="btn btn-sm btn-success" onclick="" hidden>See all &nbsp;<i
									class="fa fa-long-arrow-right" style="font-size:10px;"></i></button>
						</div>
					</div>

					<br>
					<div class="table-responsive">
						<table class="table">

							<tbody>

								<?php
										$sql = "SELECT  *  FROM d_shop_views where shop_id = '$shopid' order by id desc LIMIT 5 ";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
										    while ($row = $result->fetch_assoc()) {
										        $cid = $row['customer_id'];


										        $sqlg = "SELECT *  FROM m_user_info where userid = '$cid'";
										        $resultg = $con->query($sqlg);

										        if ($resultg->num_rows > 0) {
										            $rowg = $resultg->fetch_assoc();
										            $cname = $rowg['fullname'];
										            $ccontact = $rowg['contact'];
										        }
										        ?>

								<tr>
									<td><?php echo $cname; ?></td>

									<td><i class="fa fa-phone text-success"></i> &nbsp;
										<?php echo $ccontact; ?>
									</td>


								</tr>




								<?php
										    }
										} else {
										    ?>
								<tr>
									<td colspan="2">No Data Found !</td>
								</tr>
								<?php
										}
										?>



							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>