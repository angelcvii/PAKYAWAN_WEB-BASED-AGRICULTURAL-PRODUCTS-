<div id="main_dashboard_content">

	<div class="row mt-3">
		<div class="col-xl-3 flex-column d-flex grid-margin stretch-card">
			<div class="row flex-grow">
				<div class="col-sm-12 grid-margin stretch-card">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col">
									<h4 class="text-dark font-weight-bold mb-2">

										<?php



                                        include "../db.php";

										$sql = "SELECT *  FROM m_user where user_role = '2' ";
										$result = $con->query($sql);
										$row_cnt = $result->num_rows;

										echo $row_cnt;

										?>

									</h4>
									<h4 class="card-title">Shops</h4>


								</div>

								<div class="col dashb_icon">
									<i class="fa fa-shopping-cart "></i>
								</div>

							</div>




						</div>
					</div>
				</div>

			</div>
		</div>


		<div class="col-xl-3 flex-column d-flex grid-margin stretch-card">
			<div class="row flex-grow">
				<div class="col-sm-12 grid-margin stretch-card">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col">
									<h4 class="text-dark font-weight-bold mb-2">

										<?php




										$sql = "SELECT *  FROM m_user where user_role = '2' or user_role = '3'  ";
										$result = $con->query($sql);
										$row_cnt = $result->num_rows;

										echo $row_cnt;

										?>
									</h4>
									<h4 class="card-title">Users</h4>

								</div>

								<div class="col dashb_icon">
									<i class="fa fa-users "></i>
								</div>

							</div>




						</div>
					</div>
				</div>

			</div>
		</div>

		<div class="col-xl-3 flex-column d-flex grid-margin stretch-card">
			<div class="row flex-grow">
				<div class="col-sm-12 grid-margin stretch-card">
					<div class="card">
						<div class="card-body">
							<div class="row">
								<div class="col">
									<h4 class="text-dark font-weight-bold mb-2">

										<?php





										$sql = "SELECT *  FROM d_product ";
										$result = $con->query($sql);
										$row_cnt = $result->num_rows;

										echo $row_cnt;

										?>

									</h4>
									<h4 class="card-title">Products </h4>


								</div>

								<div class="col dashb_icon">
									<i class="fa fa-leaf "></i>
								</div>

							</div>




						</div>
					</div>
				</div>

			</div>
		</div>



		<div class="col-xl-3 flex-column d-flex grid-margin stretch-card">
			<div class="row flex-grow">
				<div class="col-sm-12 grid-margin stretch-card">
					<div class="card ">
						<div class="card-body dashb_icon_total">
							<div class="row ">
								<div class="col ">
									<h4 class="text-light font-weight-bold mb-2">

										<?php





										$sql = "SELECT *  FROM d_reservation_details where  status = 'Completed'";
										$result = $con->query($sql);
										$row_cnt = $result->num_rows;

										echo $row_cnt;

										?>


									</h4>
									<h4 class="card-title text-light">Completed</h4>


								</div>

								<div class="col ">
									<i class="bi bi-truck "></i>
								</div>

							</div>




						</div>
					</div>
				</div>

			</div>
		</div>


	</div>
	<div class="row">


		<div class="col-lg-8 grid-margin stretch-card">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col">
							<h4 class="card-title">Recent Reservation</h4>
						</div>
						<br>
						<div class="col text-right">

							<button class="btn btn-sm btn-success" onclick="allreservations()">See all &nbsp;<i
									class="fa fa-long-arrow-right" style="font-size:10px;"></i></button>
						</div>
					</div>



					<br>

					<div class="table-responsive">
						<table class="table">
							<thead>
								<tr>
									<th>Transaction No</th>
									<th>Name</th>

									<th>Address</th>
									<th>Reservation Date</th>

									<th>Status</th>
								</tr>
							</thead>
							<tbody>

								<?php


                                $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Pending'  order by id desc LIMIT 5 ";
										$resultz = $con->query($sqlz);
										if ($resultz->num_rows > 0) {
										    while ($rowz = $resultz->fetch_assoc()) {
										        $customer_id = $rowz['buyer_id'];
										        $drid = $rowz['id'];
										        $transaction_no = $rowz['transaction_no'];

										        $ostat = $rowz['status'];
										        $reservation_date = $rowz['added_date'];


										        $sqlg = "SELECT *  FROM m_user_info where userid = '$customer_id'";
										        $resultg = $con->query($sqlg);

										        if ($resultg->num_rows > 0) {
										            $rowg = $resultg->fetch_assoc();
										            $fullname = $rowg['fullname'];

										            $contact = $rowg['contact'];
										            $address = $rowg['address'];
										            $email = $rowg['email'];
										            $age = $rowg['age'];
										            $image = $rowg['image'];
										        }







										        ?>


								<tr>
									<td><?php echo  $transaction_no; ?>
									</td>
									<td><?php echo $fullname; ?></td>

									<td><?php echo $address; ?></td>
									<td><?php echo  $reservation_date; ?>
									</td>
									<td><?php echo $ostat; ?>
									</td>
								</tr>


								<?php

										    }
										} else {
										    ?>
								<tr>
									<td colspan="5">No Data Found !</td>
								</tr>
								<?php
										}



										?>




							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>



		<div class="col-lg-4 grid-margin stretch-card">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col">
							<h4 class="card-title">New Users</h4>
						</div>
						<div class="col text-right">

							<button class="btn btn-sm btn-success" onclick="allusers()">See all &nbsp;<i
									class="fa fa-long-arrow-right" style="font-size:10px;"></i></button>
						</div>
					</div>

					<br>
					<div class="table-responsive">
						<table class="table">
							<thead>
								<th>Name / Shop</th>
								<th>Account type</th>
								<th>Contact</th>
							</thead>
							<tbody>

								<?php
										$sql = "SELECT  *  FROM m_user where user_role = '2' or user_role = '3' order by id desc LIMIT 5 ";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
										    while ($row = $result->fetch_assoc()) {
										        $uid = $row['id'];
										        $userrole = $row['user_role'];

										        if ($userrole == 2) {
										            $userrole = "Shop / Seller";
										        } else {
										            $userrole = "Customer";
										        }


										        $sqlg = "SELECT *  FROM m_user_info where userid = '$uid'";
										        $resultg = $con->query($sqlg);

										        if ($resultg->num_rows > 0) {
										            $rowg = $resultg->fetch_assoc();

										            if ($userrole == 2) {
										                $cname = $rowg['shopname'];
										            } else {
										                $cname = $rowg['fullname'];
										            }

										            $ccontact = $rowg['contact'];
										        }
										        ?>

								<tr>
									<td><?php echo $cname; ?></td>
									<td><?php echo $userrole; ?></td>

									<td><i class="fa fa-phone text-success"></i> &nbsp;
										<?php echo $ccontact; ?>
									</td>


								</tr>




								<?php
										    }
										} else {
										    ?>
								<tr>
									<td colspan="2">No Data Found !</td>
								</tr>
								<?php
										}
										?>



							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>


		<div class="col-lg-6 grid-margin stretch-card">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col">
							<h4 class="card-title">Users</h4>
						</div>

					</div>

					<br>

					<canvas id="userChart" style="width:100%;max-width:600px"></canvas>


				</div>
			</div>
		</div>


		<div class="col-lg-6 grid-margin stretch-card">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col">
							<h4 class="card-title">Registered Users</h4>
						</div>

					</div>

					<br>

					<canvas id="userpermonth" style="width:100%;max-width:600px"></canvas>


				</div>
			</div>
		</div>


		<div class="col-lg-12 grid-margin stretch-card">
			<div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col">
							<h4 class="card-title">Category Products</h4>
						</div>

					</div>

					<br>


					<canvas id="ccount" style="height:70vh;width:100vw;">
					</canvas>

				</div>
			</div>
		</div>


	</div>
</div>







<div class="col-lg-12 grid-margin stretch-card" id="all_reservations" style="display:none;">
	<div class="card">
		<div class="card-body">
			<div class="row">
				<div class="col">

					<h4 class="card-title"> <a onclick="maindashboard()" class="btn btn-light btn-rounded"><i
								class=" fa fa-long-arrow-left "></i> </a> &nbsp; Reservation List</h4>
				</div>
				<div class="col text-right">


				</div>
			</div>
			<br>
			<table class="table table-striped table-bordered table-hover " id="dt_all_reservations">
				<thead>
					<tr>
						<th>Transaction No</th>
						<th>Name</th>

						<th>Address</th>
						<th>Reservation Date</th>

						<th>Status</th>
					</tr>
				</thead>
				<tbody>

					<?php


                    $sqlz = "SELECT  *  FROM d_reservation_details ";
										$resultz = $con->query($sqlz);
										if ($resultz->num_rows > 0) {
										    while ($rowz = $resultz->fetch_assoc()) {
										        $customer_id = $rowz['buyer_id'];
										        $drid = $rowz['id'];
										        $transaction_no = $rowz['transaction_no'];

										        $ostat = $rowz['status'];
										        $reservation_date = $rowz['added_date'];


										        $sqlg = "SELECT *  FROM m_user_info where userid = '$customer_id'";
										        $resultg = $con->query($sqlg);

										        if ($resultg->num_rows > 0) {
										            $rowg = $resultg->fetch_assoc();
										            $fullname = $rowg['fullname'];

										            $contact = $rowg['contact'];
										            $address = $rowg['address'];
										            $email = $rowg['email'];
										            $age = $rowg['age'];
										            $image = $rowg['image'];
										        }







										        ?>


					<tr>
						<td><?php echo  $transaction_no; ?></td>
						<td><?php echo $fullname; ?></td>

						<td><?php echo $address; ?></td>
						<td><?php echo  $reservation_date; ?>
						</td>
						<td><?php echo $ostat; ?>
						</td>
					</tr>


					<?php

										    }
										} else {
										    ?>
					<tr>
						<td colspan="5">No Data Found !</td>
					</tr>
					<?php
										}



										?>




				</tbody>
			</table>



		</div>
	</div>
</div>


<div class="col-lg-12 grid-margin stretch-card" id="all_users" style="display:none;">
	<div class="card">
		<div class="card-body">
			<div class="row">
				<div class="col">

					<h4 class="card-title"> <a onclick="maindashboard()" class="btn btn-light btn-rounded"><i
								class=" fa fa-long-arrow-left "></i> </a> &nbsp; New Users List</h4>
				</div>
				<div class="col text-right">


				</div>
			</div>
			<br>
			<table class="table table-striped table-bordered table-hover " id="dt_users">
				<thead>
					<th>Name / Shop</th>
					<th>Account type</th>
					<th>Contact</th>
					<th>Manage</th>
				</thead>
				<tbody>

					<?php
										$sql = "SELECT  *  FROM m_user where user_role = '2' or user_role = '3' order by id desc ";
										$result = $con->query($sql);
										if ($result->num_rows > 0) {
										    while ($row = $result->fetch_assoc()) {
										        $uid = $row['id'];
										        $urole = $row['user_role'];

										        if ($urole == 2) {
										            $userrole = "Shop / Seller";
										        } else {
										            $userrole = "Customer";
										        }


										        $sqlg = "SELECT *  FROM m_user_info where userid = '$uid'";
										        $resultg = $con->query($sqlg);

										        if ($resultg->num_rows > 0) {
										            $rowg = $resultg->fetch_assoc();

										            if ($urole == 2) {
										                $cname = $rowg['shopname'];
										            } else {
										                $cname = $rowg['fullname'];
										            }

										            $ccontact = $rowg['contact'];
										        }
										        ?>

					<tr>
						<td><?php echo $cname; ?></td>
						<td><?php echo $userrole; ?></td>

						<td><i class="fa fa-phone text-success"></i> &nbsp;
							<?php echo $ccontact; ?>
						</td>
						<td class="text-center">
							<?php
										                        if ($urole == 2) {
										                            ?>
							<i class="fa fa-eye"
								onclick="showshopprofile('<?php echo $uid; ?>')"
								data-bs-toggle="modal" data-bs-target="#userprofile_modal"></i>
							<?php

										                        } else {
										                            ?>
							<i class="fa fa-eye"
								onclick="showprofile('<?php echo $uid; ?>')"
								data-bs-toggle="modal" data-bs-target="#userprofile_modal"></i>

							<?php
										                        }
										        ?>


						</td>

					</tr>




					<?php
										    }
										} else {
										    ?>
					<tr>
						<td colspan="2">No Data Found !</td>
					</tr>
					<?php
										}
										?>



				</tbody>
			</table>



		</div>
	</div>
</div>




<?php


$months = array();
										$monthData = array();
										$months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
										$curryear = date('Y');

										$jf = $curryear . "-01-01 00:00:00";
										$jt = $curryear . "-01-31 23:59:59";

										$ff = $curryear . "-02-01";
										$ft = $curryear . "-02-28 23:59:59";

										$mcf = $curryear . "-03-03";
										$mct = $curryear . "-03-31 23:59:59";

										$apf = $curryear . "-04-01";
										$apt = $curryear . "-04-30 23:59:59";

										$myf = $curryear . "-05-01";
										$myt = $curryear . "-05-30 23:59:59";

										$jnf = $curryear . "-06-01";
										$jnt = $curryear . "-06-31 23:59:59";

										$jlf = $curryear . "-07-01";
										$jlt = $curryear . "-07-30 23:59:59";

										$agf = $curryear . "-08-01";
										$agt = $curryear . "-08-31 23:59:59";

										$sef = $curryear . "-09-01";
										$set = $curryear . "-09-30 23:59:59";

										$ocf = $curryear . "-10-01";
										$oct = $curryear . "-10-31 23:59:59";

										$nof = $curryear . "-11-01";
										$not = $curryear . "-11-30 23:59:59";

										$def = $curryear . "-12-01";
										$det = $curryear . "-12-31 23:59:59";











										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and  added_date BETWEEN '$jf' and '$jt' ";
										$resultz = $con->query($sqlz);
										$smonthData[] =  $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and  added_date BETWEEN '$jf' and '$jt' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;





										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$ff' and '$ff' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$ff' and '$ft' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;




										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$mcf' and '$mct' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$mcf' and '$mct' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;




										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$apf' and '$apt' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$apf' and '$apt' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;



										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$myf' and '$myt' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$myf' and '$myt' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;



										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$jnf' and '$jnt' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$jnf' and '$jnt' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;

										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$jlf' and '$jlt' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$jlf' and '$jlt' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;



										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$agf' and '$agt' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$agf' and '$agt' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$sef' and '$set' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$sef' and '$set' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;




										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$ocf' and '$oct' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$ocf' and '$oct' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;



										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$nof' and '$not' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$nof' and '$not' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' and added_date BETWEEN '$def' and '$det' ";
										$resultz = $con->query($sqlz);

										$smonthData[] = $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' and added_date BETWEEN '$def' and '$det' ";
										$resultz = $con->query($sqlz);

										$cmonthData[] = $resultz->num_rows;







										///count


										$sqlz = "SELECT  *  FROM m_user where user_role = '2' and isActive = '1' ";
										$resultz = $con->query($sqlz);
										$sellerct =  $resultz->num_rows;


										$sqlz = "SELECT  *  FROM m_user where user_role = '3' and isActive = '1' ";
										$resultz = $con->query($sqlz);

										$custct = $resultz->num_rows;



										//Category

										$categ = array();
										$catdata = array();

										$sqlcat = "SELECT  *  FROM m_category ";
										$resultcat = $con->query($sqlcat);
										if ($resultcat->num_rows > 0) {
										    while ($rowcat = $resultcat->fetch_assoc()) {
										        $cattid = $rowcat['id'];
										        $categ[] = $rowcat['description'];



										        $sqlp = "SELECT * FROM d_product where cat_id = '$cattid'  ";
										        $resultp = $con->query($sqlp);
										        if ($resultp->num_rows > 0) {
										            $catdata[] = $resultp->num_rows;
										        } else {
										            $catdata[] = 0;
										        }
										    }
										}






										?>








<script>
	var xValues = ["Customers", "Sellers"];
	var
		yValues = [ <?php echo $custct; ?> , <?php echo $sellerct; ?> ];
	var barColors = [
		"#b91d47",
		"#00aba9"
	];

	new Chart("userChart", {
		type: "pie",
		data: {
			labels: xValues,
			datasets: [{
				backgroundColor: barColors,
				data: yValues
			}]
		},
		options: {
			title: {
				display: false,
				text: "2022 Registered Users"
			}
		}
	});
</script>



<script>
	new Chart("userpermonth", {
		type: "line",
		data: {
			labels: <?php echo json_encode($months) . ','; ?> datasets: [{
				label: 'Customers',
				data: <?php echo json_encode($cmonthData) . ','; ?> borderColor: "red",
				fill: false
			}, {
				label: 'Sellers',
				data: <?php echo json_encode($smonthData) . ','; ?> borderColor: "green",
				fill: false

			}]
		},
		options: {
			legend: {
				display: true
			}
		}
	});
</script>




<script>
	var ctxx = document.getElementById("ccount");
	var myChartx = new Chart(ctxx, {
		backgroundColor: "#fff",
		type: 'bar',
		data: {
			datasets: [{


				label: "Category Products",
				type: "bar",
				backgroundColor: "#E11E0C",
				data: <?php echo json_encode($catdata) . ','; ?>
					// This binds the dataset to the right y axis
					yAxisID: 'right-y-axis',
				fill: false,



			}],
			labels: <?php echo json_encode($categ) . ','; ?>
		},
		options: {
			scales: {
				yAxes: [{
					id: 'right-y-axis',
					type: 'linear',
					position: 'left',
					ticks: {
						beginAtZero: true
					},

				}]
			}
		}
	});
</script>