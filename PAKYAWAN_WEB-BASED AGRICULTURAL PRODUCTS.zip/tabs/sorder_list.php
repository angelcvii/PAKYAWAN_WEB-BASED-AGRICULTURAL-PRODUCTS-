<div class="row" id="so_main">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            
            <div class="card-body" id="shop_orders_main_content">

            </div>
        </div>
    </div>
</div>



<!-- Processed Orders -->

<div class="row hiddenDiv" id="po_main" >
   

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
      
            <div class="card-body" id="processed_order_main_content">
          
            </div>
        </div>
    </div>
</div>


<!-- For Delivery -->

<div class="row hiddenDiv" id="fd_main">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body" id="for_delivery_main_content">
            <i class="btn btn-light btn-rounded bi bi-arrow-left" onclick=" show_div('so_main'); hide_div('po_main'); hide_div('fd_main');hide_div('oh_main');"></i>

            </div>
        </div>
    </div>
</div>

<!-- History -->

<div class="row hiddenDiv" id="oh_main">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body" id="history_main_content">
            <i class="btn btn-light btn-rounded bi bi-arrow-left" onclick=" show_div('so_main'); hide_div('po_main'); hide_div('fd_main');hide_div('oh_main');"></i>

            </div>
        </div>
    </div>
</div>





