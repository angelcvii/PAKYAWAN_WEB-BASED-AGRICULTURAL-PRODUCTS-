<div class="row" id="adminsettings_main" style="display:none;">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">

            <div class="card-body table-reponsive" id="adminsettings_main_content">

            </div>
        </div>
    </div>
</div>


<div class="row" id="prodcat_main" style="display:none;">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">

            <div class="card-body" id="prodcat_main_content">

            </div>
        </div>
    </div>
</div>



<div class="row" id="measurement_main" style="display:none;">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">

            <div class="card-body" id="measurement_main_content">

            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="addadmin_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Administrator</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="addadmin_content">



                <div class="form-group">

                    <form id="addadmin_form">
                        <br>


                        <div class="row">

                            <label for="" class="text-success">Personal Information</label>
                            <hr style="margin:1vh;">



                            <div class="col">


                                <label for="">Name</label>
                                <div class="input-group">

                                    <input type="text" class="form-control form-control-lg  insize" id="up_fullname"
                                        name="up_fullname" style="height:6vh;" placeholder="Full Name" value="">
                                </div>


                            </div>

                            <div class="col">
                                <label for="">Age</label>
                                <div class="input-group">


                                    <input type="number" class="form-control form-control-lg  insize" id="up_age"
                                        name="up_age" style="height:6vh;" placeholder="Age" value="">


                                </div>


                            </div>





                        </div>


                        <div class="row">




                            <div class="col">
                                <label for="">Address</label>
                                <div class="input-group">

                                    <input type="text" class="form-control form-control-lg insize" id="up_address"
                                        name="up_address" style="height:6vh;" placeholder="Address" value="">
                                </div>


                            </div>




                        </div>









                        <div class="row">


                            <label for="" class="text-success">Contact Information</label>
                            <hr style="margin:1vh;">




                            <div class="col">
                                <label for="">Contact No</label>
                                <div class="input-group">

                                    <input type="text" class="form-control form-control-lg insize" id="up_contact"
                                        name="up_contact" style="height:6vh;" placeholder="Contact" value="">
                                </div>


                            </div>


                            <div class="col">
                                <label for="">Email</label>
                                <div class="input-group">

                                    <input type="text" class="form-control form-control-lg insize" id="up_email"
                                        name="up_email" style="height:6vh;" placeholder="Email" value="">
                                </div>


                            </div>





                        </div>


                        <div class="row">


                            <label for="" class="text-success">Account Information</label>
                            <hr style="margin:1vh;">




                            <div class="col">
                                <label for="">Username</label>
                                <div class="input-group">

                                    <input type="text" class="form-control form-control-lg insize" id="up_username"
                                        name="up_username" style="height:6vh;" placeholder="Username" value="">
                                </div>


                            </div>


                            <div class="col">
                                <label for="">Password</label>
                                <div class="input-group">

                                    <input type="text" class="form-control form-control-lg insize" id="up_password"
                                        name="up_password" style="height:6vh;" placeholder="Password" value="">
                                </div>


                            </div>






                        </div>


                        <br>

                        <div class="float-right">

                            <a href="#" class="btn btn-rounded btn-outline-success" onclick="add_admin()"><i
                                    class="fa fa-check approved"></i> Save</a>

                        </div>



                    </form>



                </div>

            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="editadmin_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Administrator</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="editadmin_content">





            </div>

        </div>
    </div>
</div>


<div class="modal fade" id="addcategory_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Product Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="addcatprod_content">

                <div class="row">



                    <div class="col">


                        <label for="">Product Category</label>
                        <div class="input-group">

                            <input type="text" class="form-control form-control-lg  insize" id="pcat" name="pcat"
                                style="height:6vh;" placeholder="Product Category" value="">
                        </div>


                    </div>






                </div>

                <div class="row">

                    <div class="col">
                        <div class="float-right">
                            <br>
                            <a href="#" class="btn btn-rounded btn-outline-success" onclick="add_category()"><i
                                    class="fa fa-check approved"></i> Save</a>

                        </div>

                    </div>




                </div>



            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="editcategory_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Product Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="editcatprod_content">





            </div>

        </div>
    </div>
</div>



<div class="modal fade" id="addmeasurement_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Product Measurement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="addcatprod_content">

                <div class="row">



                    <div class="col">


                        <label for="">Product Measurement</label>
                        <div class="input-group">

                            <input type="text" class="form-control form-control-lg  insize" id="pmes" name="pmes"
                                style="height:6vh;" placeholder="Product Measurement" value="">
                        </div>


                    </div>






                </div>

                <div class="row">

                    <div class="col">
                        <div class="float-right">
                            <br>
                            <a href="#" class="btn btn-rounded btn-outline-success" onclick="add_measurement()"><i
                                    class="fa fa-check approved"></i> Save</a>

                        </div>

                    </div>




                </div>



            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="editmeasurement_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Product Measurement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="editmesprod_content">





            </div>

        </div>
    </div>
</div>