<div class="row" id="res_content">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
       
            <div class="card-body" id="reservation_content">

            </div>
        </div>
    </div>
</div>





<div class="modal fade" id="reservation_details_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Reservation Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="reservation_modalcontent">





            </div>

        </div>
    </div>
</div>