<div class="row" id="products_main_content">

	<div class="col-lg-12 grid-margin stretch-card">
		<div class="card">
			<div class="card-body">






				<div class="container" id="prodbycat_content">
					<div class="float-center" style="overflow-x:auto;">
						<h4>Categories</h4>
						<hr><br>

						<a class="btn btn-success" onclick="getcprodlist('99');">
							All Categories </a>
						<?php

                        include "../db.php";


						$sql = "SELECT *  FROM m_category  ";
						$result = $con->query($sql);




						$i = 0;
						$in_catid = 0;
						if ($result->num_rows > 0) {
						    while ($row = $result->fetch_assoc()) {
						        $catid = $row['id'];
						        $cat = $row['description'];

						        if ($i == 0) {
						            $in_catid =  $catid;
						            ?>
						<a class="btn btn-outline-success"
							onclick="getcprodlist(<?php echo $catid; ?>);">
							<?php echo $cat; ?>
						</a>

						<?php

						        } else {
						            ?>
						<a class="btn btn-outline-success"
							onclick="getcprodlist(<?php echo $catid; ?>);">
							<?php echo $cat; ?> </a>
						<?php

						        }
						        $i++;
						        ?>


						<?php

						    }
						}

						?>





					</div>

					<br>

					<div class="row">
						<h4>Products</h4><br>
						<hr>

						<?php
						$path = "../data/products/";
						$sql = "SELECT *  FROM d_product where isAvailable = '1'  order by id desc  ";
						$result = $con->query($sql);
						if ($result->num_rows > 0) {
						    while ($row = $result->fetch_assoc()) {
						        $prodid = $row['id'];
						        $prodimage = $row['image'];
						        $prodname = $row['description'];
						        $seller_id = $row['seller_id'];
						        $price = $row['price'];
						        $meas_id = $row['measurement_id'];
						        $qty = $row['qty'];
						        $c_location = $row['c_location'];
						        $planted_date = $row['planted_date'];
						        $harvest_date = $row['harvest_date'];



						        $sqlS = "SELECT *  FROM m_user_info where userid = '$seller_id'";
						        $resultS = $con->query($sqlS);
						        $rowS = $resultS->fetch_assoc();
						        $shopname = $rowS['shopname'];



						        $sqlM = "SELECT *  FROM m_measurement where id = '$meas_id'";
						        $resultM = $con->query($sqlM);
						        $rowM = $resultM->fetch_assoc();
						        $measurement = $rowM['description'];


						        ?>

						<div class="col-sm-4">

							<div class="card">
								<img src="<?php echo $path.$prodimage; ?>"
									class="card-img-top" alt="..." style="height:40vh;">
								<div class="card-body">
									<h4 class="card-title">
										<?php echo $prodname; ?>
									</h4>
									<a href="#" class="text-success"
										onclick="shopProfile('<?php echo $seller_id; ?>')">
										<h6 class="card-sub-title"> <i class="bi bi-shop-window"></i> &nbsp;
											<?php echo $shopname; ?>
									</a>
									</h6>
									<h6 class="card-sub-title"> <i class="bi bi-tag-fill"></i> &nbsp; Pakyaw Price @ Php
										<?php echo $price ; ?>
									</h6>
									<h6 class="card-sub-title"> <i class="bi bi-geo-alt"></i> &nbsp;
										<?php echo $c_location; ?>
									</h6>
									<h6 class="card-sub-title" hidden> <i class="bi bi-calendar-check"></i> &nbsp;
										Planted Date
										:
										<?php echo $planted_date; ?>
									</h6>
									<h6 class="card-sub-title" hidden> <i class="bi bi-calendar-check-fill"></i> &nbsp;
										Harvest
										Date :
										<?php echo $harvest_date; ?>
									</h6>



									<div>
										<center>
											<br>
											<a class="btn btn-outline-success btn-rounded" data-bs-toggle="modal"
												data-bs-target="#product_addtocart"
												onclick="addtocartmodal(<?php echo $prodid; ?>)">
												View Details</a>
										</center>
									</div>

								</div>
							</div>
						</div>


						<?php

						    }
						}
						?>





					</div>
				</div>


			</div>
		</div>
	</div>
</div>


<!---- Reservation Panel ---->