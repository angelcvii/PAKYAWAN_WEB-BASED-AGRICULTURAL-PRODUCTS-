
<?php

include "../backend/userprofile.php";
?>

<div class="row" id="sprofcontent">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">

                <div class="float-end">
                    <i class="fa fa-edit text-success" data-bs-toggle="modal" data-bs-target="#userprofile_modal"
                        style="cursor:pointer; font-size:20px;" onclick="editprofile()"></i>
                </div>

                <div class="container emp-profile" id="sprofile_content">
                    <form method="post">
                        <div class="row">

                            <div class="col-md-11">

                            <?php

                            if(!$image == ""){

                                ?>
<img src="../data/profile/<?php echo $image; ?>" class="border border-light"
                                    style="height:30vh;width:30vh; margin-bottom:5px;" id="prevs_prof">
                                <?php

                            }else{
    ?>

                                <img src="../img/default.jpeg" class="border border-light"
                                    style="height:30vh;width:30vh; margin-bottom:5px;" id="prevs_prof">

<?php

}
?>


                                <div class="profile-head">
                                    <h5 class="text-success"><b>
                                            <?php 
                                            echo $fullname;
                                            ?>

                                        </b>
                                    </h5>


                                    <br>




                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item">

                                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Profile Information</button>

                                          
                                        </li>
                                        <li class="nav-item">

                                        <button class="nav-link " id="home-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="true" onclick="getHReservationList()">Reservation History</button>

                                           
                                        </li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                        <div class="row">

                            <div class="col-md-12">
                                <div class="tab-content profile-tab" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home" role="tabpanel"
                                        aria-labelledby="home-tab">


                                        <div class="card">
                                            <div class="card-body">
                                                <table class="table table-borderless">


                                                    <tbody>
                                                        <tr>
                                                            <td colspan="2">
                                                                <b class="text-success"> Personal Details </b>
                                                            </td>

                                                        </tr>
                                                        <tr>
                                                            <td><b>Full Name </b></td>
                                                            <td>  <?php 
                                            echo $fullname;
                                            ?></td>

                                                        </tr>
                                                        <tr>
                                                            <td><b> Age </b></td>
                                                            <td>  <?php 
                                            echo $age;
                                            ?></td>

                                                        </tr>
                                                        <tr>
                                                            <td><b>Delivery Address </b></td>
                                                            <td> <?php 
                                            echo $address;
                                            ?></td>

                                                        </tr>

                                                        <tr>
                                                            <td><b>Active Since </b></td>
                                                            <td><?php echo $registered ; ?></td>

                                                        </tr>
                                                     
                                                        <tr>
                                                            <td colspan="2">
                                                                <b class="text-success"> Contact Details </b>
                                                            </td>

                                                        </tr>

                                                        <tr>
                                                            <td><b>Mobile No</b></td>
                                                            <td><?php echo $contact; ?> </td>

                                                        </tr>
                                                        <tr>
                                                            <td><b>Email Address</b></td>
                                                            <td><?php echo $email; ?></td>

                                                        </tr>


                                                    </tbody>

                                                </table>
                                            </div>
                                        </div>




                                    </div>
                                    <div class="tab-pane fade" id="profile" role="tabpanel"
                                        aria-labelledby="profile-tab">

                                        <div class="col-lg-12 grid-margin stretch-card">
                                            <div class="card">
                                                <div class="card-body">





                                                    <div class="table-responsive" id="h_content">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>




<div class="modal fade" id="userprofile_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">User Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="userprofile_content">





            </div>

        </div>
    </div>
</div>




<div class="modal fade" id="hreservation_details_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Reservation Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="hreservation_modalcontent">





            </div>

        </div>
    </div>
</div>