<div class="row" id="sproduct_main">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">

            <div class="card-body" id="shop_product_main_content">

            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="addprod_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="addprod_modalcontent">


                <div class="row">



                    <div class="col">



                        <center>



                            <img src="../data/products/default.png" class="img-fluid rounded" alt="" style="height:200px;width:200px;" id="prev_image" />




                            <br><br>
                            <i class="fa fa-edit btn btn-outline-success" onclick="selectimage()"> Select Product
                                Image</i>
                        </center>


                    </div>




                </div>

                <form id="addproduct_form">
                    <br>
                    <div class="row">
                        <div class="col">

                            <div class="input-group">

                                <input type="file" class="form-control form-control-lg border-left-0 insize" id="product_pic" name="product_pic" style="height:6vh;display:none" accept="image/*" onchange="uloadFile(event)">
                                <script>
                                    var uloadFile = function(event) {
                                        var output = document.getElementById('prev_image');

                                        output.src = URL.createObjectURL(event.target.files[0]);

                                        output.onload = function() {
                                            URL.revokeObjectURL(output.src) // free memory


                                        }


                                    };


                                    function selectimage() {
                                        $("#product_pic").click();
                                    }
                                </script>
                            </div>


                        </div>
                    </div>

                    <div class="row">

                        <label for="" class="text-success">Product Information</label>
                        <hr style="margin:1vh;">



                        <div class="col-12">

                            <label for="">Product Name</label>
                            <div class="input-group">

                                <input type="text" class="form-control form-control-lg  insize" id="prodname" name="prodname" style="height:6vh;" placeholder="Product Name">
                            </div>


                        </div>
                        <div class="col-12">

                            <label for="">Category</label>
                            <div class="input-group">

                                <select class="form-control form-control-lg  insize " style="background:white;" id="category" name="category">
                                    <option value="">Please Select</option>

                                    <?php
                                    include "../db.php";
                                    $sql = "SELECT  *  FROM m_category ";
                                    $result = $con->query($sql);

                                    while ($row = $result->fetch_assoc()) {
                                    ?>
                                        <option value="<?php echo $row['id']; ?>"><?php echo $row['description']; ?>
                                        </option>
                                    <?php
                                    }
                                    ?>

                                </select>
                            </div>


                        </div>

                        <div class="col-12">

                            <label for="">Farm Size (SQM)</label>
                            <div class="input-group">

                                <input type="number" class="form-control form-control-lg  insize" id="sqm" name="sqm" style="height:6vh;" placeholder="Farm Size">
                            </div>


                        </div>

                        <div class="col-12">

                            <label for="">Price</label>
                            <div class="input-group">

                                <input type="number" class="form-control form-control-lg  insize" id="price" name="price" style="height:6vh;" placeholder="Product Price">
                            </div>


                        </div>

                        <div class="col-12">

                            <label for="">Crop Location</label>
                            <div class="input-group">

                                <input type="text" class="form-control form-control-lg  insize" id="clocation" name="clocation" style="height:6vh;" placeholder="Crop Location">
                            </div>


                        </div>

                        <div class="col-12">

                            <label for="">Planted Date</label>
                            <div class="input-group">

                                <input type="date" class="form-control form-control-lg  insize" id="pdate" name="pdate" style="height:6vh;" placeholder="Product Name">
                            </div>


                        </div>

                        <div class="col-12">

                            <label for="">Harvest Date</label>
                            <div class="input-group">

                                <input type="date" class="form-control form-control-lg  insize" id="hdate" name="hdate" style="height:6vh;" placeholder="Product Name">
                            </div>


                        </div>







                    </div>

                    <br>

                    <div class="float-right">
                        <a href="#" class="btn btn-rounded btn-outline-success" onclick="a_product()"><i class="fa fa-check approved"></i> Save Product</a>

                    </div>

            </div>







            </form>


        </div>


    </div>

</div>


<div class="modal fade" id="editprod_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="editprod_modalcontent">


            </div>
        </div>
    </div>
</div>