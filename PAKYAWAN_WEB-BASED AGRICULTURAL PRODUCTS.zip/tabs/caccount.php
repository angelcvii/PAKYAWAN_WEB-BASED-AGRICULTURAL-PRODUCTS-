<div class="row align-center" id="acc_content">
    <div class="col-lg-2"></div>

    <div class="col-lg-6 grid-margin stretch-card">
        <div class="card">

            <div class="card-body" id="accounts_content">

                <div class="container">

                    <h5> <i class="fa fa-shield"></i> &nbsp; Account Settings</h5>
                    <form id="account_form">
                    <div class="row">


                        <hr style="margin:1vh;">



                        <div class="col-12">

                            <label for="">Username</label>
                            <div class="input-group">

                                <input type="text" class="form-control form-control-lg  insize" id="up_uname"
                                    name="up_uname" style="height:6vh;" placeholder="Username"
                                    value="<?php echo $uname; ?>">
                            </div>


                        </div>

                        <div class="col-12">
                            <label for="">Old Password</label>
                            <div class="input-group">


                                <input type="password" class="form-control form-control-lg  insize" id="up_oldpass"
                                    name="up_oldpass" style="height:6vh;" placeholder="Password" value="">


                            </div>


                        </div>
                        <div class="col-12">
                            <label for="">New Password</label>
                            <div class="input-group">


                                <input type="password" class="form-control form-control-lg  insize" id="up_newpass"
                                    name="up_newpass" style="height:6vh;" placeholder="Password" value="">


                            </div>


                        </div>

                        <div class="col-12">
                          
                          

                            <a href="#" class="btn btn-rounded btn-outline-success float-right " onclick="up_account()" style="margin-top:1vh;"><i
                          class="fa fa-check "></i> Save Changes</a>


                     


                        </div>





                    </div>
                    </form>

                </div>


            </div>
        </div>
    </div>
    <div class="col-lg-2"></div>
</div>