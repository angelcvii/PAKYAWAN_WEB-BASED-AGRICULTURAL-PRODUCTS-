<div class="row" id="accreq_main">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            
            <div class="card-body" id="accreq_main_content">

            </div>
        </div>
    </div>
</div>




<div class="row" id="activeacc_main" style="display:none;">

    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            
            <div class="card-body" id="activeacc_main_content">

            </div>
        </div>
    </div>
</div>




