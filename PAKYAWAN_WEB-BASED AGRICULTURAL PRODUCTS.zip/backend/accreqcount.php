<?php
    

       require_once "../db.php";
                                     
       $sql = "SELECT *  FROM m_user where user_role = '2' or user_role = '3' ";
                                    
       $result = $con->query( $sql );
       $row_cnt = 0;
                                     
      
if ($result->num_rows > 0) {
while ($row = $result->fetch_assoc()) {
$isActive = $row['isActive'];
    if($isActive=='0'){
    $row_cnt++;
    }
}
    echo $row_cnt;
}else{
    echo "0";
}                               
 ?>


