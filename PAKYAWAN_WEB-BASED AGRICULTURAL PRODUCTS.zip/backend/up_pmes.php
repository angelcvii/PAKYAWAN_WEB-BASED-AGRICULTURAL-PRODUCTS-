<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";



    date_default_timezone_set("Asia/Taipei");
    $date = date('Y-m-d H:i:s');

    $mesid = $_POST['mesid'];
    $prodmes = $_POST['mes'];
    


        $sql = "UPDATE m_measurement SET  description = '$prodmes' where id = '$mesid' ";
        $result = $con->query($sql);

        if ($result) {
            echo '1';
        } else {
            echo '0';
        }
    }

        ?>