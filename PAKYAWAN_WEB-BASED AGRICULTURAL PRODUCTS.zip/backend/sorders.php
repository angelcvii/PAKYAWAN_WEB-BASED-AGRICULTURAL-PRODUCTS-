<h4>Reservation List </h4>

<div class="float-right">

	<i class="btn btn-outline-success btn-rounded "
		onclick="show_div('po_main'); hide_div('so_main'); hide_div('fd_main'); hide_div('oh_main');getPOList();"> <i
			class="bi bi-check"></i> Approved Reservations</i>
	<i class="btn btn-outline-danger btn-rounded"
		onclick="hide_div('po_main'); hide_div('so_main'); show_div('fd_main'); hide_div('oh_main');getFDList();"
		hidden> <i class="bi bi-x"></i> Declined Reservation</i>
	<i class="btn btn-outline-light btn-rounded"
		onclick="hide_div('po_main'); hide_div('so_main'); hide_div('fd_main'); show_div('oh_main');getOHList();"> <i
			class="bi bi-clock-history"></i> History</i>


</div>
<br>
<br>
<hr>
<table id="dt_orders_list" class="table table-striped table-bordered table-hover   ">
	<thead>
		<tr>
			<th> Product Image </th>
			<th> Transaction No </th>
			<th>Customer</th>
			<th> Total Amount </th>
			<th> Address</th>
			<th> Status </th>
			<th> Date</th>
			<th class="text-center">Manage</th>
		</tr>
	</thead>
	<tbody>
		<?php
        include "../db.php";
		session_start();
		$sellerid = $_SESSION['uid'];
		$path = "../data/products/";
		$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Pending'   ";
		$resultz = $con->query($sqlz);
		if ($resultz->num_rows > 0) {
		    while ($rowz = $resultz->fetch_assoc()) {
		        $customer_id = $rowz['buyer_id'];
		        $drid = $rowz['id'];
		        $transaction_no = $rowz['transaction_no'];

		        $ostat = $rowz['status'];
		        $reservation_date = $rowz['added_date'];
		        $subtotal= $rowz['subtotal'];
		        $resfee= $rowz['res_fee'];
		        $totalamount = $rowz['total_amount'];
		        $prodid = $rowz['product_id'];


		        $sqlg = "SELECT *  FROM m_user_info where userid = '$customer_id'";
		        $resultg = $con->query($sqlg);

		        if ($resultg->num_rows > 0) {
		            $rowg = $resultg->fetch_assoc();
		            $fullname = $rowg['fullname'];

		            $contact = $rowg['contact'];
		            $address = $rowg['address'];
		            $email = $rowg['email'];
		            $age = $rowg['age'];
		            $image = $rowg['image'];
		        }





		        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$sellerid'  ";
		        $resultm = $con->query($sqlm);
		        if ($resultm->num_rows > 0) {
		            $rowm = $resultm->fetch_assoc();
		            $prodimage = $rowm['image'];





		            ?>


		<tr>
			<td><img src="<?php echo $path.$prodimage;?>"
					class="rounded" style="height:10vh;width:10vh;">
			</td>
			<td><?php echo  $transaction_no; ?></td>
			<td><?php echo $fullname; ?></td>
			<td><?php echo $totalamount; ?></td>

			<td><?php echo $address; ?></td>

			<td><?php echo $ostat; ?>
			</td>
			<td><?php echo  $reservation_date; ?>
			</td>
			<td class="text-center"> <i class="fa fa-eye"
					onclick="res_details(<?php echo   $drid; ?>)"
					data-bs-toggle="modal" data-bs-target="#reservation_details_modal"></i> </td>
			</td>
		</tr>


		<?php

		        }
		    }
		}




		?>


	</tbody>
</table>