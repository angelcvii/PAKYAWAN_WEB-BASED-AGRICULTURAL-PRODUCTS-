<?php



    include "../db.php";

    $sql = "SELECT *  FROM m_user_info where userid = '$uid'";
    $result = $con->query( $sql );

    if ( $result->num_rows > 0 ) {
        $row = $result->fetch_assoc();
        $fullname = $row['fullname'];
    
        $contact = $row['contact'];
        $address = $row['address'];
        $email = $row['email'];
        $age = $row['age'];
        $image = $row['image'];


    }


    $sql = "SELECT *  FROM m_user where id = '$uid'";
    $result = $con->query( $sql );
    $rowb = $result->fetch_assoc();
    $registered = $rowb['added_date'];
    $uname = $rowb['username'];
    $password = $rowb['password'];

?>