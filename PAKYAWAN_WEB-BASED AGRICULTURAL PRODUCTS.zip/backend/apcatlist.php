<h4>
    <i class="bi bi-bookmark-fill "> </i> &nbsp;Product Category List 
    <i class="btn btn-rounded btn-outline-success bi bi-bookmark-plus float-right"  data-bs-toggle="modal" data-bs-target="#addcategory_modal"> Add Product Category</i></i>
</h4>


<hr>

<div class="table-responsive">
<table id="dt_pcat_list" class="table table-striped table-bordered table-hover ">
    <thead>
        <tr>

            <th> Category </th>
            <th> Added by</th>
            <th> Added Date</th>
            <th class="text-center">Manage</th>
        </tr>
    </thead>
    <tbody>
        <?php
        include "../db.php";



        $sql = "SELECT  *  FROM m_category   ";
        $result = $con->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $catid = $row['id'];
                $category = $row['description'];
              
                $addeddate = $row['added_date'];
                $addedby = $row['added_by'];






            
        ?>


                    <tr>

                        <td><?php echo  $category; ?></td>

        
                        <td><?php echo $addeddate; ?>
                        </td>
                        <td><?php echo $addedby; ?>
                        </td>
                        <td class="text-center">

                           
                                <i class="fa fa-edit" onclick="edit_category('<?php echo $catid; ?>')" data-bs-toggle="modal" data-bs-target="#editcategory_modal"></i>
                           
                        
                        </td>
                    </tr>


        <?php

                }
            }
        



        ?>


    </tbody>
</table>
</div>