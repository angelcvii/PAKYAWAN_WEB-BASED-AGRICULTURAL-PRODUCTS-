<h4>Reservations</h4>
<hr><br>
<table id="dt_reservation_list" class="table table-striped table-bordered table-hover   ">
	<thead>
		<tr>
			<th> Product Image</th>
			<th> Transaction No </th>
			<th> Sub - total </th>
			<th> Reservation Fee</th>
			<th> Amount</th>
			<th> Status </th>
			<th> Date</th>
			<th class="text-center">Manage</th>
		</tr>
	</thead>
	<tbody>
		<?php

session_start();
		$cid = $_SESSION['uid'];
		include "../db.php";
		$path = "../data/products/";

		$sql = "SELECT *  FROM d_reservation_details where buyer_id = '$cid' and status = 'Pending'";
		$result = $con->query($sql);





		if ($result->num_rows > 0) {
		    while ($row = $result->fetch_assoc()) {
		        $rid = $row['id'];

		        $transaction = $row['transaction_no'];
		        $subtotal = $row['subtotal'];
		        $res_fee = $row['res_fee'];
		        $amt = $row['total_amount'];
		        $stat = $row['status'];
		        $date = $row['added_date'];
		        $prodid = $row['product_id'];

		        $sqlI = "SELECT  *  FROM d_product where id = '$prodid' ";
		        $resultI = $con->query($sqlI);
		        $rowI = $resultI->fetch_assoc();
		        $prodimage = $rowI['image'];

		        ?>
		<tr>
			<td><img src="<?php echo $path.$prodimage;?>"
					class="rounded" style="height:10vh;width:10vh;">
			</td>
			<td> <?php echo $transaction; ?> </td>
			<td> <?php echo $subtotal; ?> </td>
			<td> <?php echo $res_fee; ?> </td>
			<td> <?php echo  $amt; ?> </td>
			<td> <?php echo $stat; ?> </td>
			<td> <?php echo $date; ?> </td>
			<td class="text-center"> <i class="fa fa-eye"
					onclick="res_details(<?php echo  $rid; ?>)"
					data-bs-toggle="modal" data-bs-target="#reservation_details_modal"></i> </td>

		</tr>


		<?php

		    }
		}
		?>

	</tbody>
</table>