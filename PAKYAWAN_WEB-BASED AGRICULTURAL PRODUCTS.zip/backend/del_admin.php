<?php

  include "../db.php";


  $userid = $_POST['id'];
  $sql = "DELETE FROM m_user where id = '$userid' ";

  $result = $con->query($sql);

  $sqlx = "DELETE FROM m_user_info where userid = '$userid' ";

  $resultx = $con->query($sqlx);

if ($result && $resultx) {
    echo '1';
}else{
    echo '0';

}

?>