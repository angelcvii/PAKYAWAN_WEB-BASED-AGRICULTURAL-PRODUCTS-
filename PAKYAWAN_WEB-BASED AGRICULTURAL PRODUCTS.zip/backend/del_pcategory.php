<?php

  include "../db.php";


  $catid = $_POST['catid'];
  $sql = "DELETE FROM m_category where id = '$catid' ";

  $result = $con->query($sql);


if ($result ) {
    echo '1';
}else{
    echo '0';

}

?>