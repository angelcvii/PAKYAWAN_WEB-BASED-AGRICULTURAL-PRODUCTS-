<?php

 session_start();
 $customerid = $_SESSION['uid'];

 include "../db.php";
 $path = "../data/products/";

 date_default_timezone_set("Asia/Taipei");
 $date = date('Y-m-d H:i:s');

 $prodid = $_POST['prodid'];
 $stot = $_POST['stot'];
 $rfee = $_POST['rfee'];
 $tot = $_POST['tot'];

 $stat = "Pending";

 $sql = "SELECT  *  FROM d_reservation_details where buyer_id = '$customerid' and product_id = '$prodid' and status = 'Pending' ";
 $result = $con->query($sql);
 if ($result->num_rows > 0) {
     echo '7';
 } else {
     $sqlT = "SELECT *  FROM d_reservation_details order by id desc ";
     $resultT = $con->query($sqlT);
     $rowT = $resultT->fetch_assoc();

     if (!isset($rowT['id'])) {
         $tid = 1;
     } else {
         $tid = intval($rowT['id']) + 1;
     }




     $sql = "SELECT *  FROM m_user_info where userid = '$customerid'";
     $result = $con->query($sql);
     $row = $result->fetch_assoc();

     $fname = $row['fullname'];
     $dtrans = date('YmdHis');

     $transaction_no = $fname[0] . "-" . $dtrans . "-" . $tid;



     $sql = "INSERT INTO d_reservation_details (transaction_no, buyer_id, product_id, subtotal, res_fee, total_amount, status, added_date)
 VALUES ('$transaction_no','$customerid','$prodid','$stot','$rfee','$tot','$stat','$date')";
     $result = $con->query($sql);



     if ($result) {
         echo '1';
     } else {
         echo '0';
     }
 }
