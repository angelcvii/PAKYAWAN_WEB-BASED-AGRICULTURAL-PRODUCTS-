<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";


     $resid = $_POST['rid'];

        $stat = "Order Cancelled";
        $sql = "UPDATE d_reservation_details SET  status = '$stat' where id = $resid ";
        $result = $con->query($sql);

        if ($result) {
            echo '1';
        } else {
            echo '0';
        }
    }

        ?>