<h4>Reservation History</h4>
<hr><br>
<table id="dt_hreservation_list" class="table table-striped table-bordered table-hover   ">
	<thead>
		<tr>
			<th> Transaction No </th>
			<th> Sub - total </th>
			<th> Reservation Fee</th>
			<th> Amount</th>
			<th> Status </th>
			<th> Date</th>
			<th class="text-center">Manage</th>
		</tr>
	</thead>
	<tbody>
		<?php

session_start();
		$cid = $_SESSION['uid'];
		include "../db.php";


		$sql = "SELECT *  FROM d_reservation_details where buyer_id = '$cid' and status = 'Completed' ";
		$result = $con->query($sql);





		if ($result->num_rows > 0) {
		    while ($row = $result->fetch_assoc()) {
		        $rid = $row['id'];

		        $transaction = $row['transaction_no'];
		        $subtotal = $row['subtotal'];
		        $res_fee = $row['res_fee'];
		        $amt = $row['total_amount'];
		        $stat = $row['status'];
		        $date = $row['added_date'];

		        ?>
		<tr>
			<td> <?php echo $transaction; ?> </td>
			<td> <?php echo $subtotal; ?> </td>
			<td> <?php echo $res_fee; ?> </td>
			<td> <?php echo  $amt; ?> </td>
			<td> <?php echo $stat; ?> </td>
			<td> <?php echo $date; ?> </td>
			<td class="text-center"> <i class="fa fa-eye"
					onclick="hres_details(<?php echo  $rid; ?>)"
					data-bs-toggle="modal" data-bs-target="#hreservation_details_modal"></i> </td>

		</tr>


		<?php

		    }
		}
		?>

	</tbody>
</table>