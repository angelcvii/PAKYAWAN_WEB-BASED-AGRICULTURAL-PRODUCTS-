<?php
        include "../db.php";

        $prodid = $_POST['prodid'];
        $path = "../data/products/";

        $sql = "SELECT  *  FROM d_product where id = '$prodid' ";
        $result = $con->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            $prodid = $row['id'];
            $prodimage = $row['image'];
            $prodname = $row['description'];
            $price = $row['price'];
            $cloc = $row['c_location'];
            $sqm = $row['farmsize'];
            $catid = $row['cat_id'];
            $pdate = $row['planted_date'];
            $hdate = $row['harvest_date'];






            $sqlm = "SELECT  description  FROM m_category where id = '$catid' ";
            $resultm = $con->query($sqlm);
            $rowm = $resultm->fetch_assoc();
            $category = $rowm['description'];


            if ($prodimage == "") {
                $prodimage = "default.png";
            }
        }

        ?>


<div class="row">



	<div class="col">



		<center>



			<img src="../data/products/<?php echo $prodimage; ?>"
				class="img-fluid rounded" alt="" style="height:200px;width:200px;" id="prev_prod" />




			<br><br>
			<i class="fa fa-edit btn btn-outline-success" onclick="selectprodimage()"> Edit Product
				Image</i>
		</center>


	</div>




</div>

<form id="updateproduct_form">
	<br>
	<div class="row">
		<div class="col">

			<div class="input-group">

				<input type="file" class="form-control form-control-lg border-left-0 insize" id="u_product_pic"
					name="u_product_pic" style="height:6vh;display:none" accept="image/*" onchange="ueloadFile(event)">
				<script>
					var ueloadFile = function(event) {
						var output = document.getElementById('prev_prod');

						output.src = URL.createObjectURL(event.target.files[0]);

						output.onload = function() {
							URL.revokeObjectURL(output.src) // free memory


						}


					};


					function selectprodimage() {
						$("#u_product_pic").click();
					}
				</script>
			</div>


		</div>
	</div>

	<div class="row">

		<label for="" class="text-success">Product Information</label>
		<hr style="margin:1vh;">



		<div class="col-12">

			<label for="">Product Name</label>
			<div class="input-group">
				<input type="text" class="form-control form-control-lg  insize" id="up_id" name="up_id"
					style="height:6vh;"
					value="<?php echo  $prodid; ?>" hidden>
				<input type="text" class="form-control form-control-lg  insize" id="u_prodname" name="u_prodname"
					style="height:6vh;" placeholder="Product Name"
					value="<?php echo  $prodname; ?>">
			</div>


		</div>
		<div class="col-12">

			<label for="">Category</label>
			<div class="input-group">

				<select class="form-control form-control-lg  insize " style="background:white;" id="u_category"
					name="u_category">
					<option value="<?php echo  $catid; ?>">
						<?php echo  $category; ?> (SELECTED)
					</option>

					<?php
        include "../db.php";
        $sql = "SELECT  *  FROM m_category ";
        $result = $con->query($sql);

        while ($row = $result->fetch_assoc()) {
            ?>
					<option
						value="<?php echo $row['id']; ?>">
						<?php echo $row['description']; ?>
					</option>
					<?php
        }
        ?>

				</select>
			</div>


		</div>

		<div class="col-12">

			<label for="">Farm Size (SQM)</label>
			<div class="input-group">

				<input type="number" class="form-control form-control-lg  insize" id="usqm" name="usqm"
					style="height:6vh;" placeholder="Farm Size"
					value="<?php echo $sqm; ?>">
			</div>


		</div>


	</div>
	<div class="col-12">

		<label for="">Price</label>
		<div class="input-group">

			<input type="number" class="form-control form-control-lg  insize" id="u_price" name="u_price"
				style="height:6vh;" placeholder="Product Price"
				value="<?php echo $price; ?>">
		</div>


	</div>

	<div class="col-12">

		<label for="">Crop Location</label>
		<div class="input-group">

			<input type="text" class="form-control form-control-lg  insize" id="u_clocation" name="u_clocation"
				style="height:6vh;" placeholder="Crop Location"
				value="<?php echo $cloc; ?>">
		</div>


	</div>

	<div class="col-12">

		<label for="">Planted Date</label>
		<div class="input-group">

			<input type="date" class="form-control form-control-lg  insize" id="u_pdate" name="u_pdate"
				style="height:6vh;" value="<?php echo $pdate;?>">
		</div>


	</div>

	<div class="col-12">

		<label for="">Harvest Date</label>
		<div class="input-group">

			<input type="date" class="form-control form-control-lg  insize" id="u_hdate" name="u_hdate"
				style="height:6vh;" value="<?php echo $hdate;?>">
		</div>


	</div>







	</div>

	<br>

	<div class="float-right">
		<a href="#" class="btn btn-rounded btn-danger"
			onclick="dconfirm_dproduct('<?php echo   $prodid;?>')"><i
				class="fa fa-trash danger"></i> </a>
		<a href="#" class="btn btn-rounded btn-outline-success" onclick="u_product()"><i
				class="fa fa-check approved"></i> Save Changes</a>



	</div>

	</div>







</form>