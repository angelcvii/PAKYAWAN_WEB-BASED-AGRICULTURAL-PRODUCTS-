<?php
   include "../db.php";
   $mesid = $_POST['mesid'];
    $sql = "SELECT  *  FROM m_measurement where id = '$mesid' ";
    $result = $con->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
 
    $measurement = $row['description'];
}
?>

<div class="row">
    <div class="col">


        <label for="">Product Measurement</label>
        <div class="input-group">

            <input type="text" class="form-control form-control-lg  insize" id="up_pmes" name="up_pmes"
                style="height:6vh;" placeholder="Product Measurement" value="<?php echo  $measurement;?>">
        </div>


    </div>

</div>

<div class="row">

    <div class="col">
        <div class="float-right">
            <br>

            <a href="#" class="btn btn-rounded btn-danger" onclick="delcon_mes('<?php echo $mesid ; ?>')"><i
                    class="fa fa-trash"></i></a>
            <a href="#" class="btn btn-rounded btn-outline-success" onclick="up_mes('<?php echo $mesid; ?>')"><i
                    class="fa fa-check approved"></i> Save Changes</a>

        </div>

    </div>




</div>