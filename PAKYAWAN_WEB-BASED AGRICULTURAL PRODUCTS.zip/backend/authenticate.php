<?php

session_start();
require_once "../db.php";

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM m_user where username = '$username' and password = '$password' ";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $type = $row['user_role'];

    $_SESSION["uid"] = $row['id'];
    $_SESSION["username"] = $row['username'];
    $_SESSION["user_role"] = $row['user_role'];

    $passcheck = $row['password'];
    $usercheck = $row['username'];

    if (strcmp($password, $passcheck) !== 0) {
        echo '4';
    } elseif (strcmp($username, $usercheck) !== 0) {
        echo '4';
    } else {
        $isactive = $row['isActive'];

        if ($isactive == 1) {
            echo $type;
        } elseif ($isactive == 7) {
            echo $isactive;
        } else {
            echo '8';
        }
    }
} else {
    echo '0';
}
