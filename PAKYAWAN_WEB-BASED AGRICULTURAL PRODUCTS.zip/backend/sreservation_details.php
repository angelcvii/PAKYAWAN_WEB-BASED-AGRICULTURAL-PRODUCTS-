<?php
include "../db.php";
$rid = $_POST['rid'];


$sql = "SELECT *  FROM d_reservation_details where id = '$rid'";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $prodid = $row['product_id'];
    $transaction = $row['transaction_no'];
    $subtotal = $row['subtotal'];
    $res_fee = $row['res_fee'];
    $amt = $row['total_amount'];
    $stat = $row['status'];
    $date = $row['added_date'];
    $buyerid = $row['buyer_id'];


    $sql = "SELECT *  FROM m_user_info where userid = '$buyerid'  ";
    $result = $con->query($sql);
    $row = $result->fetch_assoc();
    $customername = $row['fullname'] ;
    $address = $row['address'];
    $buyeremail = $row['email'];
}
?>

<div class="row">
	<div class="col-12">
		<h5>Transaction No : <span class="text-success">
				<?php echo $transaction; ?> </span></h5>
	</div>

	<div class="col-12">
		<h5>Customer Name : <span class="text-success">
				<?php echo $customername; ?> </span></h5>
	</div>

	<div class="col-12">
		<h5>Delivery Address : <span class="text-success">
				<?php echo  $address; ?> </span></h5>
	</div>
	<div class="col-12">
		<h5>Status : <span class="text-success"> <?php echo $stat; ?>
			</span></h5>
	</div>

</div>

<hr style="margin:1vh;">
<h5 class="text-dark">Product </h5>

<br>

<div style="overflow-y:auto; overflow-x:hidden; ">

	<?php

 $path = "../data/products/";
$sql = "SELECT *  FROM d_product where id = '$prodid'  ";
$resultx = $con->query($sql);
$rowx = $resultx->fetch_assoc();

$prodimage = $rowx['image'];
$prodname = $rowx['description'];
$seller_id = $rowx['seller_id'];
$price = $rowx['price'];
$meas_id = $rowx['measurement_id'];
$qty = $rowx['qty'];
$c_location = $rowx['c_location'];
$planted_date = $rowx['planted_date'];
$harvest_date = $rowx['harvest_date'];


$sql = "SELECT *  FROM m_user_info where userid = '$seller_id'  ";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$shopname = $row['shopname'];

?>

	<div class="card mb-3">

		<div class="row g-0">


			<div class="col-md-4">
				<img src="<?php echo $path . $prodimage; ?>"
					class="img-fluid rounded-start" alt="...">
			</div>
			<div class="col-md-8">
				<div class="card-body">


					<div>
						<h4><?php echo $prodname; ?> </h4>
					</div>




					<hr>
					<p class="card-text">

					<h4> Subtotal : <span class="text-danger">₱
							<?php echo $sto = intval($price); ?>
						</span></h4>





					</p>



				</div>
			</div>
		</div>

	</div>



</div>
<hr style="margin:1vh;">

<h5> Sub Total : <span class="text-danger"> ₱
		<?php echo $subtotal; ?></span> </h5>
<h5> Reservation Fee : <span class="text-danger"> ₱
		<?php echo $res_fee; ?></span> </h5>

<div class="float-right">

	<?php
if ($stat=="Pending") {
    ?>
	<a class="btn btn-outline-success" href="#"
		onclick="up_orderstat('<?php echo $rid; ?>','Approved'); sendemail('<?php echo $buyeremail; ?>','Reservation Status','Your Reservation with Transaction No : <?php echo  $transaction; ?> Has been Approved ! ');">
		<i class="bi bi-check"></i> Approve</a>

	<a class="btn btn-outline-danger" href="#"
		onclick="up_orderstat('<?php echo $rid; ?>','Declined'); sendemail('<?php echo $buyeremail; ?>','Reservation Status','Your Reservation with Transaction No : <?php echo  $transaction; ?> Has been Declined ! ');">
		<i class="bi bi-x"></i> Decline</a>
	<?php
}

if ($stat=="Approved") {
    ?>
	<a class="btn btn-outline-success" href="#"
		onclick="up_orderstat('<?php echo $rid; ?>','Completed');">
		<i class="bi bi-check"></i>Completed</a>
	<?php
}


?>

</div>