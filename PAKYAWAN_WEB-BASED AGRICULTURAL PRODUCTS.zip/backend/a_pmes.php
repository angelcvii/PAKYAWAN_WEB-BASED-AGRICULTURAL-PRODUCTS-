<?php
session_start();
$adminid = $_SESSION['uid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";




    date_default_timezone_set("Asia/Taipei");
    $date = date('Y-m-d H:i:s');

    $pmes = $_POST['mes'];


    $sql = "SELECT *  FROM m_user where id = '$adminid'";
    $result = $con->query($sql);
    $rowb = $result->fetch_assoc();
    $uname = $rowb['username'];




    $sql = "SELECT *  FROM m_measurement where description = '$pmes' ";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        echo '3';
    } else {




        //Update details
        $sql_update_hstat = "INSERT INTO m_measurement (description,added_by,added_date) VALUES ('$pmes','$uname','$date')";
        $u_hresult = $con->query($sql_update_hstat);

        if ($u_hresult) {
            echo '1';
        } else {
            echo '0';
        }
    }
}
