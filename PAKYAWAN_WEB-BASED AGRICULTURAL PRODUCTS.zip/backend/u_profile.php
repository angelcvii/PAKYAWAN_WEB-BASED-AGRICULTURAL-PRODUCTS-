<?php

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) {
    include "../db.php";

    $id = $_POST['up_id']; 
   
    $fname = $_POST['up_fullname'];
    $age = $_POST['up_age'];
    $address = $_POST['up_address'];
    $email = $_POST['up_email'];
    $contact = $_POST['up_contact'];

    $is_uploading = $_FILES["profile_pic"]["error"];
    $can_pass = $is_uploading == 0 ? true : false;
    
    
if ( $can_pass ) {

    $path = "../data/profile/";
    
    $sqlf = "SELECT image FROM m_user_info where userid = $id";
    $resf = $con->query( $sqlf );

    $row = $resf->fetch_assoc();

    if ( !file_exists( $path.$row['image'] ) )  {

    } else {

        if($row['image'] !== ""){
 //remove file
 unlink($path.$row['image'] );

        }

       
    }
    mysqli_close( $con );
    
    
    
    //add new file
    include "../db.php";
    
    $file_parts = pathinfo($_FILES["profile_pic"]["name"]);
    $file_path = $fname.date('Ymd').'updated.'.$file_parts['extension'];
    move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $path.$file_path);
    $file = $file_path;
    
    

    
    
    //Update details
    $sql_update_hstat = "UPDATE m_user_info SET  fullname = '$fname', age = '$age', address = '$address', contact = '$contact', email = '$email',  image = '$file' where userid = '$id'";
    $u_hresult = $con->query($sql_update_hstat);
    
    if( $u_hresult){
        echo '1';
    }else{
        echo '0';
    } 
    
    
    
    
   
}else{
   
    
    //Update details
    $sql_update_hstat = "UPDATE m_user_info SET  fullname = '$fname', age = '$age', address = '$address', contact = '$contact', email = '$email' where userid = '$id'";
     $u_hresult = $con->query($sql_update_hstat);
    
    if( $u_hresult){
        echo '1';
    }else{
        echo '0';
    } 
}
}


?>