<?php

  session_start();
  $customerid = $_SESSION['uid'];
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      include "../db.php";



      date_default_timezone_set("Asia/Taipei");
      $date = date('Y-m-d H:i:s');

      $rid = $_POST['rid'];
      $stat = $_POST['stat'];

      if ($stat == "Completed") {
          $sql = "UPDATE d_reservation_details SET  status = '$stat' , delivered_date = '$date' where id = '$rid' ";
      } else {
          $sql = "UPDATE d_reservation_details SET  status = '$stat'  where id = '$rid' ";
      }

      if ($stat == "Approved") {
          $sqlz = "SELECT  product_id  FROM d_reservation_details where id = '$rid'   ";
          $resultz = $con->query($sqlz);
          $rowz = $resultz->fetch_assoc();
          $prodid = $rowz['product_id'];

          $sqlA = "UPDATE d_product SET  isAvailable = '0' where id = '$prodid' ";
          $resultA = $con->query($sqlA);

          $sqlR = "UPDATE d_reservation_details SET status = 'Declined' where id != '$rid' and status = 'Pending' ";
          $resultR = $con->query($sqlR);
      } elseif ($stat == "Cancelled") {
          $sqlz = "SELECT  product_id  FROM d_reservation_details where id = '$rid'   ";
          $resultz = $con->query($sqlz);
          $rowz = $resultz->fetch_assoc();
          $prodid = $rowz['product_id'];

          $sqlA = "UPDATE d_product SET  isAvailable = '1' where id = '$prodid' ";
      }



      $result = $con->query($sql);

      if ($result) {
          echo '1';
      } else {
          echo '0';
      }
  }
