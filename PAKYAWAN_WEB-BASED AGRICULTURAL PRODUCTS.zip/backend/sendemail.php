<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);


$from = "notification@pakyawan-wholesale-reservation.online ";
$to = $_POST['email'];
$subject = $_POST['subject'];
$msg = $_POST['msg'];
$message = $msg;
$headers = "From:" . $from;
if (mail($to, $subject, $message, $headers)) {
    echo '1';
} else {
    echo '0';
}
