<?php


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";




    date_default_timezone_set("Asia/Taipei");
    $date = date('Y-m-d H:i:s');



    $unme = $_POST['username'];
    $pword = $_POST['password'];
    $fname = $_POST['fname'];
    $address = $_POST['address'];
    $userrole = $_POST['userrole'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];





    $sql = "SELECT *  FROM m_user where username = '$unme' and password = '$pword' ";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        echo '3';
    } else {
        $sql = "SELECT id  FROM m_user where email = '$email' ";
        $result = $con->query($sql);
        if ($result->num_rows > 0) {
            echo '4';
        } else {
            if ($userrole == 2) {
                $sql = "INSERT INTO m_user (username,password,user_role,added_by,added_date) VALUES ('$unme','$pword','$userrole','account','$date')";
                $result = $con->query($sql);

                $sql = "SELECT id  FROM m_user where username = '$unme' and password = '$pword'";
                $result = $con->query($sql);
                $rowb = $result->fetch_assoc();
                $userid = $rowb['id'];



                $path = "../data/shop/";
                $file_parts = pathinfo($_FILES["validid"]["name"]);
                $file_path = $fname.date('Ymd').'valid.'.$file_parts['extension'];
                move_uploaded_file($_FILES["validid"]["tmp_name"], $path.$file_path);
                $file = $file_path;

                $sqlx = "INSERT INTO m_user_info (userid,shopname,address,contact,email, valid_id) VALUES ('$userid','$fname','$address','$contact','$email','$file')";
                $resultx = $con->query($sqlx);
            } elseif ($userrole == 3) {
                $sql = "INSERT INTO m_user (username,password,user_role,added_by,added_date) VALUES ('$unme','$pword','$userrole','account','$date')";
                $result = $con->query($sql);

                $sql = "SELECT id  FROM m_user where username = '$unme' and password = '$pword'";
                $result = $con->query($sql);
                $rowb = $result->fetch_assoc();
                $userid = $rowb['id'];


                $path = "../data/profile/";
                $file_parts = pathinfo($_FILES["validid"]["name"]);
                $file_path = $fname.date('Ymd').'valid.'.$file_parts['extension'];
                move_uploaded_file($_FILES["validid"]["tmp_name"], $path.$file_path);
                $file = $file_path;

                $sqlx = "INSERT INTO m_user_info (userid,fullname,address,contact,email, valid_id) VALUES ('$userid','$fname','$address','$contact','$email','$file')";
                $resultx = $con->query($sqlx);
            }




            if ($result && $resultx) {
                echo '1';
            } else {
                echo '0';
            }
        }
    }
}
