
<div class="row container" style="overflow-y:auto; height:60vh;">

<div class="col-12" id="cart_items">


<?php
 session_start();
 $customerid = $_SESSION['uid'];  

include "../db.php";
$path = "../data/products/";

$subtotal = array();
$rfee = array();


$sql = "SELECT *  FROM d_reservation_cart where customer_id = '$customerid' and order_id = 0 ";
$result = $con->query( $sql );  

if ($result->num_rows > 0) {
    $data = 1;
    while ($row = $result->fetch_assoc()) {
        $cartid = $row['id'];
        $prodid = $row['product_id'];
        $proqty = $row['qty'];

        //get product details

        $sql = "SELECT *  FROM d_product where id = '$prodid'  ";
        $resultx = $con->query($sql);
        if ($resultx->num_rows > 0) {
            $rowx = $resultx->fetch_assoc();
         
            $prodimage = $rowx['image'];
            $prodname = $rowx['description'];
            $seller_id = $rowx['seller_id'];
            $price = $rowx['price'];
            $meas_id = $rowx['measurement_id'];
            $qty = $rowx['qty'];
            $c_location = $rowx['c_location'];
            $planted_date = $rowx['planted_date'];
            $harvest_date = $rowx['harvest_date'];



            $sqlS = "SELECT *  FROM m_user_info where userid = '$seller_id'";
            $resultS = $con->query($sqlS);
            $rowS = $resultS->fetch_assoc();
            $shopname = $rowS['shopname'];



            $sqlM = "SELECT *  FROM m_measurement where id = '$meas_id'";
            $resultM = $con->query($sqlM);
            $rowM = $resultM->fetch_assoc();
            $measurement = $rowM['description'];


            $sqlF= "SELECT fee  FROM d_reservation_fee where seller_id = '$seller_id'";
            $resultF = $con->query($sqlF);
            $rowF= $resultF->fetch_assoc();
            $reserv_fee = $rowF['fee'];

            $total = intval($price) + intval($reserv_fee);

            $subtotal[] = intval($price) * intval($proqty);
            $rfee[] = $reserv_fee;


        }


        ?>













        <div class="card mb-3">

            <div class="row g-0">
                <div class="col-md-4">
                    <img src="<?php echo $path.$prodimage; ?>" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <div>
                            <h4><?php echo $prodname; ?> <i class=" float-right fa fa-trash text-danger" onclick="dconfirm_citm('<?php echo   $cartid ; ?>')"></i></h4>
                        </div>


                        <h4 class="text-danger">₱ <?php echo $price; ?></h4>
                        <hr>
                        <p class="card-text">
                        <table>
                            <tbody>

                                <tr>
                                    <td>
                                        <h5>Qty </h5>
                                    </td>
                                    <td> <a class="btn btn-success btn-sm" href="#"
                                            onclick="UpQty('<?php echo $price; ?>','<?php echo $prodid; ?>','min')">
                                            - </a></td>

                                    <td><input class="form-control form-control-sm text-center" type="text"
                                            value="<?php echo $proqty; ?>" style="max-width:10vh;" id="qty_prod<?php echo $prodid; ?>" readonly> </td>
                                    <td><a class="btn btn-success btn-sm" href="#"
                                            onclick="UpQty('<?php echo $price; ?>','<?php echo $prodid; ?>','add')">+</a>
                                    </td>

                                </tr>


                                <tr>
                                    <h5> Variation </h5>
                                </tr>

                                <tr>
                                    <h5 class="btn btn-success"> <?php echo   $measurement;  ?> </h5>
                                </tr>

                            </tbody>

                        </table>





                        </p>



                    </div>
                </div>
            </div>
        </div>



        <?php

    }
}else{
    $data = 0;
    ?>
<div>
    <center>
<img src="../data/emptycart.png" class="img-fluid " alt="...">
<br>

<a href="#" class="btn btn-outline-success btn-rounded" style="margin-right:2vh;" onclick="cprodtab()"> <i class="bi bi-cart"></i> Order Now ! </a>
        
</center>
</div>        



<?php
}
    ?>




    </div>


</div>

<?php
if(!$data==0){
?>


<hr>
<div class=" float-right" id="cost_panel">

    <table>
        <tbody>
            <tr>

                <td>
                    <h5> Sub Total : </h5>
                </td>
                <td class="right">
                    <h5 class="text-danger" style="margin-left:2vh;">₱ <?php echo $stotal = array_sum($subtotal); ?></h5>
                </td>
            </tr>

            <tr>

                <td>
                    <h5> Reservation fee : </h5>
                </td>
                <td class="right">
                    <h5 class="text-danger" style="margin-left:2vh;">₱ <?php echo  $sfee = array_sum($rfee); ?></h5>
                </td>
            </tr>
            <tr>

<td>
    <h5> Total Amount : </h5>
</td>
<td class="right">
    <h5 class="text-danger" style="margin-left:2vh;">₱ <?php echo $tamount = intval($stotal + $sfee); ?></h5>
</td>
</tr>
            <tr>

                <td></td>
                <td class="right">
                    <a href="#" class="btn btn-outline-success" style="margin-right:2vh;" onclick="placeorder('<?php echo $stotal; ?>','<?php echo $sfee; ?>','<?php echo $tamount; ?>')"> <i class="fa fa-check"></i> Place Order </a>
                </td>
            </tr>
        </tbody>

    </table>








</div>
</div>

<?php
}
?>