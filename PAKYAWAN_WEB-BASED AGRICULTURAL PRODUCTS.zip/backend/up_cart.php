<?php
  session_start();
  $customerid = $_SESSION['uid'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";



    date_default_timezone_set("Asia/Taipei");
    $date = date('Y-m-d H:i:s');

    $prodid = $_POST['pid'];
    $qty = $_POST['qty'];
    $price = $_POST['price'];

    $total = intval($qty) * intval($price);



    $sql = "SELECT *  FROM d_reservation_cart where product_id = '$prodid' and customer_id = '$customerid' and order_id = '0' ";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
     

       

        $sql = "UPDATE d_reservation_cart SET  qty = '$qty' , total = '$total' where product_id = '$prodid' and customer_id = '$customerid' and order_id = '0' ";
        $result = $con->query($sql);

        if ($result) {
            echo '1';
        } else {
            echo '0';
        }
    }
}
        ?>