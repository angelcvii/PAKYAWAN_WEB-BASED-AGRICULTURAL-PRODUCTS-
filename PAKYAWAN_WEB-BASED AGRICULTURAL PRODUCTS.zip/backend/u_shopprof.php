<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";

    $id = $_POST['up_sid'];

    $sname = $_POST['up_sname'];
    $sdesc = $_POST['up_sdesc'];

    $address = $_POST['up_address'];
    $email = $_POST['up_email'];
    $contact = $_POST['up_contact'];

    $is_uploading = $_FILES["shop_pic"]["error"];
    $can_pass = $is_uploading == 0 ? true : false;

    $is_banner_up = $_FILES["shop_banner"]["error"];
    $ban_can_pass = $is_banner_up == 0 ? true : false;



    //shop logo
    if ($can_pass) {

        $path = "../data/shop/";

        $sqlf = "SELECT s_logo FROM m_user_info where userid = $id";
        $resf = $con->query($sqlf);

        $row = $resf->fetch_assoc();

        if (!file_exists($path . $row['s_logo'])) {
        } else {

            if ($row['s_logo'] !== "") {
                //remove file
                unlink($path . $row['s_logo']);
            }
        }
        mysqli_close($con);






        //add new file
        include "../db.php";

        $file_parts = pathinfo($_FILES["shop_pic"]["name"]);
        $file_path = $sname . date('Ymd') . 'shop.' . $file_parts['extension'];
        move_uploaded_file($_FILES["shop_pic"]["tmp_name"], $path . $file_path);
        $slgfile = $file_path;





        //Update details
        $sql_update_hstat = "UPDATE m_user_info SET  shopname = '$sname', address = '$address', contact = '$contact', email = '$email',  s_logo = '$slgfile', s_description='$sdesc' where userid = '$id'";
        $u_hresult = $con->query($sql_update_hstat);

        if ($u_hresult) {
            echo '1';
        } else {
            echo '0';
        }
    } else {


        //Update details
        $sql_update_hstat = "UPDATE m_user_info SET  shopname = '$sname', address = '$address', contact = '$contact', email = '$email', , s_description='$sdesc' where userid = '$id'";
        $u_hresult = $con->query($sql_update_hstat);

        if ($u_hresult) {
            echo '1';
        } else {
            echo '0';
        }
    }



//banner

if ($ban_can_pass) {

    $path = "../data/shop/";

    $sqlf = "SELECT s_banner FROM m_user_info where userid = $id";
    $resf = $con->query($sqlf);

    $row = $resf->fetch_assoc();

    if (!file_exists($path . $row['s_banner'])) {
    } else {

        if ($row['s_banner'] !== "") {
            //remove file
            unlink($path . $row['s_banner']);
        }
    }
    mysqli_close($con);






    //add new file
    include "../db.php";

    $file_parts = pathinfo($_FILES["shop_banner"]["name"]);
    $file_path = $sname . date('Ymd') . 'ban.' . $file_parts['extension'];
    move_uploaded_file($_FILES["shop_banner"]["tmp_name"], $path . $file_path);
    $sbanfile = $file_path;





    //Update details
    $sql_update_hstat = "UPDATE m_user_info SET  shopname = '$sname', address = '$address', contact = '$contact', email = '$email',  s_banner = '$sbanfile',  s_description='$sdesc' where userid = '$id'";
    $u_hresult = $con->query($sql_update_hstat);

    if ($u_hresult) {
        echo '1';
    } else {
        echo '0';
    }
} else {


    //Update details
    $sql_update_hstat = "UPDATE m_user_info SET  shopname = '$sname', address = '$address', contact = '$contact', email = '$email' , s_description='$sdesc' where userid = '$id'";
    $u_hresult = $con->query($sql_update_hstat);

    if ($u_hresult) {
        echo '1';
    } else {
        echo '0';
    }
}



}
