<?php

  include "../db.php";


  $mesid = $_POST['mesid'];
  $sql = "DELETE FROM m_measurement where id = '$mesid' ";

  $result = $con->query($sql);


if ($result ) {
    echo '1';
}else{
    echo '0';

}

?>