<?php

session_start();
$customerid = $_SESSION['uid']; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";

    $shopid = $_POST['shopid'];
    

    
    $sql = "SELECT *  FROM d_shop_views where shop_id = '$shopid' and customer_id = '$customerid'";
    $result = $con->query($sql);
    if ($result->num_rows == 0) {

         
        $sql = "INSERT INTO d_shop_views (shop_id,customer_id) VALUES ('$shopid','$customerid')";
        $result = $con->query($sql);
 
        if($result){
                echo '1';
        }else{
                echo '0';
        }

    }
    



 

}
    ?>