<?php
 session_start();
 $customerid = $_SESSION['uid'];  
  include "../db.php";


  $pid = $_POST['pid'];
  $sql = "DELETE FROM d_reservation_cart where id = '$pid' ";

  $result = $con->query($sql);

if ($result) {
    echo '1';
}else{
    echo '0';

}

?>