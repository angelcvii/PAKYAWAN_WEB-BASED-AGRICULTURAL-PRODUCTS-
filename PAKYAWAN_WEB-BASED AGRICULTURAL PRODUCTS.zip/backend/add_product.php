<?php

session_start();
$sellerid = $_SESSION['uid']; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";

    $prodname = $_POST['prodname'];
    $category = $_POST['category'];
    $sqm = $_POST['sqm'];
    $price = $_POST['price'];
    $cloc = $_POST['clocation'];
    $pdate = $_POST['pdate'];
    $hdate = $_POST['hdate'];
    $date = date('Y-m-d H:i:s' );
    $path = "../data/products/";


    $file_parts = pathinfo($_FILES["product_pic"]["name"]);
    $file_path = $prodname.date('Ymd').'.'.$file_parts['extension'];
    move_uploaded_file($_FILES["product_pic"]["tmp_name"], $path.$file_path);
    $file = $file_path;
    

    
    $sql = "SELECT *  FROM d_product where description = '$prodname' and seller_id = '$sellerid'";
    $result = $con->query($sql);
    if ($result->num_rows == 0) {

         
        $sql = "INSERT INTO d_product (cat_id,seller_id,description,price,farmsize,c_location,planted_date,harvest_date,image,added_date) 
        VALUES ('$category','$sellerid','$prodname','$price','$sqm','$cloc','$pdate','$hdate','$file','$date')";
        $result = $con->query($sql);
 
        if($result){
                echo '1';
        }else{
                echo '0';
        }

    }else{
        echo '3';
    }
    



 

}
    ?>