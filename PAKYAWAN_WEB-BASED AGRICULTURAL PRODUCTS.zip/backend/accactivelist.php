<h4>
    <i class="bi bi-person "> </i> &nbsp; Active Accounts <i
        class="btn btn-rounded btn-outline-success bi bi-person-plus float-right" onclick="getAccRList()"> Account Requests</i></i>
</h4>


<hr>
<table id="dt_active_list" class="table table-striped table-bordered table-hover   ">
    <thead>
        <tr>
            <th> Image </th>
            <th> Name </th>
            <th> Contact</th>
            <th>Email</th>
            <th> Registered Date</th>
            <th> Status </th>
            <th class="text-center">Manage</th>
        </tr>
    </thead>
    <tbody>
        <?php
        include "../db.php";

        

        $sql = "SELECT  *  FROM m_user where  user_role = '2' or user_role = '3'   ";
        $result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $userid = $row['id'];
        $userrole = $row['user_role'];
        $isactive = $row['isActive'];



        $sqlx = "SELECT *  FROM m_user_info where userid = '$userid'";
        $resultx = $con->query($sqlx);

        if ($resultx->num_rows > 0) {
            $rowx = $resultx->fetch_assoc();


            if ($userrole == 2) {
                $name = $rowx['shopname'];
                $image = $rowx['s_logo'];
                $path = "../data/shop/";
            } elseif ($userrole == 3) {
                $name = $rowx['fullname'];
                $image = $rowx['image'];
                $path = "../data/profile/";
            }

            if ($isactive == '1') {
                $stat = "Active";
          
            }



            $contact = $rowx['contact'];
            $address = $rowx['address'];
            $email = $rowx['email'];
            $addeddate = $row['added_date'];
        }




        if ($isactive == '1' ) {
            ?>


        <tr>
            <td class="text-center"><img src="<?php echo $path . $image; ?>" style="height:10vh;width:10vh;"
                    class="rounded"> </td>

            <td><?php echo  $name; ?></td>

            <td><?php echo  $contact; ?></td>
            <td><?php echo  $email; ?></td>
            <td><?php echo $addeddate; ?>
            </td>
            <td><?php echo $stat; ?>
            </td>
            <td class="text-center"> 
                
            <?php 
                if($userrole == '2'){

                    ?>
                <i class="fa fa-eye" onclick="showshopprofile('<?php echo $userid; ?>')" data-bs-toggle="modal"
                    data-bs-target="#userprofile_modal"></i>
                <?php

                }else{
                    ?>
                <i class="fa fa-eye" onclick="showprofile('<?php echo $userid; ?>')" data-bs-toggle="modal"
                    data-bs-target="#userprofile_modal"></i>

                <?php
                }
                ?>
            </td>
        </tr>


        <?php

        }
    }
}



        ?>


    </tbody>
</table>