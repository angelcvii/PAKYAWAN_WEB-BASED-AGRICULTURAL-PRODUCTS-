<?php
        session_start();
         $customerid = $_SESSION['uid'];     

       require_once "../db.php";
                                     
       $sql = "SELECT *  FROM d_reservation_cart where customer_id = '$customerid' and order_id = 0 ";
                                    
       $result = $con->query( $sql );
                                     
      
if ($result->num_rows > 0) {
    $row_cnt = $result->num_rows;
    echo $row_cnt;
}else{
    echo "0";
}
                                     
 ?>