<?php

$sid = $_POST['shopid'];
include "../db.php";
$sql = "SELECT *  FROM m_user_info where userid = '$sid'  ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $shopname = $row['shopname'];
    $s_desc = $row['s_description'];
    $s_banner = $row['s_banner'];
    $s_logo = $row['s_logo'];
    $s_contact = $row['contact'];
    $s_email = $row['email'];

    if ($s_logo == "") {
        $s_logo = "default.png";
    }

    if ($s_banner == "") {
        $s_banner = "shop.jpg";
    }

    if ($s_desc == "") {
        $s_desc = "This is a sample shop description";
    }
}

?>



<div class="row">

	<div class="col-sm-12 grid-margin stretch-card">

		<div class="card">
			<div style="margin:1vh;"> <a href="#" class="btn btn-outline-success btn-rounded" onclick=" cprodtab();"> <i
						class="bi bi-arrow-left"></i></a>
			</div>
			<div class="card-body">

				<div class="row"
					style="background-image:url('../data/shop/<?php echo $s_banner; ?>'); background-size:cover;">

					<div class="col-3">

						<img src="../data/shop/<?php echo $s_logo; ?>"
							class="img-fluid rounded-circle" alt="" style="height:35vh;width:35vh;margin-top:1.5vh;"
							id="prev_prof" />

					</div>

					<div class="col-9"></div>


				</div>

				<div class="row" style="margin-top:1vh;">

					<div class="col">

						<h4> <?php echo $shopname; ?> </h4>
						<h6> <?php echo $s_desc; ?></h6>

						<h6> Contact : <?php echo $s_contact; ?></h6>
						<h6> Email: <?php echo $s_email; ?></h6>
					</div>
				</div>


			</div>
		</div>
	</div>
</div>

<div class="row" id="sprods_content">
	<div class="float-center" style="overflow-x:auto;">
		<h4>Categories</h4>
		<hr>





		<?php



        $ctrap = 1;





$sqlc = "SELECT *  FROM m_category";
$resultc = $con->query($sqlc);
while ($rowc = $resultc->fetch_assoc()) {
    $catid = $rowc['cat_id'];
    $cid =  $rowc['id'];
    $cat = $rowc['description'];


    $sql = "SELECT DISTINCT cat_id  FROM d_product where seller_id = '$sid'";
    $result = $con->query($sql);





    if ($result->num_rows > 0) {
        if ($ctrap == 1) {
            $fcat = $cid;
            ?>
		<a class="btn btn-success"
			onclick="getcprodlistS('<?php echo $cid; ?>','<?php echo $sid; ?>');">
			<?php echo $cat; ?>
		</a>

		<?php

        } else {
            ?>
		<a class="btn btn-outline-success"
			onclick="getcprodlistS('<?php echo $cid; ?>','<?php echo $sid; ?>');">
			<?php echo $cat; ?> </a>
		<?php

        }

        ?>


		<?php
        $ctrap++;
    }
}

?>




















	</div>
	<br>
	<br>

	<div class="row">
		<h4>Products</h4><br>
		<hr>

		<?php
$path = "../data/products/";
$sql = "SELECT *  FROM d_product where cat_id = '$fcat' and seller_id = '$sid' and isActive = '1' order by  RAND()  ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $prodid = $row['id'];
        $prodimage = $row['image'];
        $prodname = $row['description'];
        $seller_id = $row['seller_id'];
        $price = $row['price'];
        $meas_id = $row['measurement_id'];
        $qty = $row['qty'];
        $c_location = $row['c_location'];
        $planted_date = $row['planted_date'];
        $harvest_date = $row['harvest_date'];



        $sqlS = "SELECT *  FROM m_user_info where userid = '$seller_id'";
        $resultS = $con->query($sqlS);
        $rowS = $resultS->fetch_assoc();
        $shopname = $rowS['shopname'];



        $sqlM = "SELECT *  FROM m_measurement where id = '$meas_id'";
        $resultM = $con->query($sqlM);
        $rowM = $resultM->fetch_assoc();
        $measurement = $rowM['description'];


        ?>

		<div class="col-sm-4">

			<div class="card">
				<img src="<?php echo $path . $prodimage; ?>"
					class="card-img-top" alt="..." style="height:40vh;">
				<div class="card-body">
					<h4 class="card-title">
						<?php echo $prodname; ?>
					</h4>
					<a href="#" class="text-success"
						onclick="shopProfile('<?php echo $seller_id; ?>')">
						<h6 class="card-sub-title"> <i class="bi bi-shop-window"></i> &nbsp;
							<?php echo $shopname; ?>
					</a>
					</h6>
					<h6 class="card-sub-title"> <i class="bi bi-tag-fill"></i> &nbsp; Pakyaw Price @ Php
						<?php echo $price; ?>
					</h6>
					<h6 class="card-sub-title"> <i class="bi bi-geo-alt"></i> &nbsp;
						<?php echo $c_location; ?>
					</h6>
					<h6 class="card-sub-title" hidden> <i class="bi bi-calendar-check"></i> &nbsp;
						Planted Date
						:
						<?php echo $planted_date; ?>
					</h6>
					<h6 class="card-sub-title" hidden> <i class="bi bi-calendar-check-fill"></i> &nbsp;
						Harvest
						Date :
						<?php echo $harvest_date; ?>
					</h6>



					<div>
						<center>
							<br>
							<a class="btn btn-outline-success btn-rounded" data-bs-toggle="modal"
								data-bs-target="#product_addtocart"
								onclick="addtocartmodal(<?php echo $prodid; ?>)">
								View Details</a>
						</center>
					</div>

				</div>
			</div>
		</div>


		<?php

    }
}
?>





	</div>




</div>