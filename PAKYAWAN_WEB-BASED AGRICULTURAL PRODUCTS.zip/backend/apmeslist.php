<h4>
    </i> &nbsp;Product Measurement List
    <i class="btn btn-rounded btn-outline-success bi bi-plus float-right" data-bs-toggle="modal"
        data-bs-target="#addmeasurement_modal"> Add Product Measurement </i></i>
</h4>


<hr>

<div class="table-responsive">
    <table id="dt_pmes_list" class="table table-striped table-bordered table-hover ">
        <thead>
            <tr>

                <th> Measurement </th>
                <th> Added by</th>
                <th> Added Date</th>
                <th class="text-center">Manage</th>
            </tr>
        </thead>
        <tbody>
            <?php
        include "../db.php";



        $sql = "SELECT  *  FROM m_measurement   ";
        $result = $con->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $mesid = $row['id'];
                $mes = $row['description'];
              
                $addeddate = $row['added_date'];
                $addedby = $row['added_by'];






            
        ?>


            <tr>

                <td><?php echo  $mes; ?></td>


                <td><?php echo $addeddate; ?>
                </td>
                <td><?php echo $addedby; ?>
                </td>
                <td class="text-center">


                    <i class="fa fa-edit" onclick="edit_measurement('<?php echo $mesid; ?>')" data-bs-toggle="modal"
                        data-bs-target="#editmeasurement_modal"></i>


                </td>
            </tr>


            <?php

                }
            }
        



        ?>


        </tbody>
    </table>
</div>