<?php
  session_start();
  $adminid = $_SESSION['uid'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";


  

    date_default_timezone_set("Asia/Taipei");
    $date = date('Y-m-d H:i:s');

    $fname = $_POST['up_fullname'];
    $age = $_POST['up_age'];
    $address = $_POST['up_address'];
    $email = $_POST['up_email'];
    $contact = $_POST['up_contact'];
    $username = $_POST['up_username'];
    $pass = $_POST['up_password'];

    
    $sql = "SELECT *  FROM m_user where id = '$adminid'";
    $result = $con->query( $sql );
    $rowb = $result->fetch_assoc();
    $uname = $rowb['username'];




    $sql = "SELECT *  FROM m_user where username = '$username' ";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        echo '3';
    } else {
       
      
      

        //Update details
        $sql_update_hstat = "INSERT INTO m_user (username,password,isActive,user_role,added_by,added_date) VALUES ('$username','$pass','1','1','$uname','$date')";
        $u_hresult = $con->query($sql_update_hstat);

        if ($u_hresult) {

            $sql = "SELECT id  FROM m_user where username = '$username' and password = '$pass'";
            $result = $con->query( $sql );
            $rowb = $result->fetch_assoc();
            $userid = $rowb['id'];

            
            $sql = "INSERT INTO m_user_info (userid,fullname,age,address,contact,email) VALUES ('$userid','$fname','$age','$address','$contact','$email')";
            $result = $con->query($sql);

            if($result){
                echo '1';
            }else{
                echo '0';
            }
        } else {
            echo '0';
        }
    }
}
