<?php

session_start();
$customerid = $_SESSION['uid']; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";

    $username = $_POST['up_uname'];
    $oldpass = $_POST['up_oldpass'];
    $newpass = $_POST['up_newpass'];

    
    $sql = "SELECT *  FROM m_user where password = '$oldpass' and id = '$customerid'";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {

         //Update account
        $sql_update_hstat = "UPDATE m_user SET  username = '$username', password = '$newpass' where id = '$customerid'";
        $u_hresult = $con->query($sql_update_hstat);
 
        if( $u_hresult){
                echo '1';
        }else{
                echo '0';
        }

    }else{
        echo '3';

    }



 

}
    ?>