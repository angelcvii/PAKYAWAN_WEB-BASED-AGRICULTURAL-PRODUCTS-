<?php
include "../db.php";
session_start();
$id = $_SESSION['uid'];     

?>


<div class="form-group">
    <?php

    $path = "../data/shop/";

$sqlx = "SELECT *  FROM m_user_info where userid = '$id' ";
$resultx = $con->query( $sqlx );
$rowx = $resultx->fetch_assoc();
$shopname = $rowx['shopname'];
$age = $rowx['age'];
$address = $rowx['address'];
$semail = $rowx['email'];
$scontact = $rowx['contact'];
$image = $rowx['image'];
    
$s_desc = $rowx['s_description'];
$s_banner = $rowx['s_banner'];
$s_logo = $rowx['s_logo'];

if ($s_logo == "") {
    $s_logo = "default.png";
}

if ($s_banner == "") {
    $s_banner = "shop.jpg";
}

if ($s_desc == "") {
    $s_desc = "This is a sample shop description";
}

if ($scontact == "") {
    $scontact = "N/A";
}

if($semail == ""){
    $semail = "N/A";
}

    
    

?>



    <div class="row" id="banner_image" style="background-image:url('<?php echo $path.$s_banner; ?>'); background-size:cover;" >
    


        <div class="col-3">



           

                <?php
                                         if( $s_logo == null){
                                             
                                             ?>

                <img src="../data/shop/default.png" class="img-fluid rounded-circle" alt=""
                    style="height:150px;width:150px;margin-top:1vh;" id="shop_prof" />


                <?php
                                             
                                         }else{
                                             
                                             ?>

                <img src="../data/shop/<?php echo   $s_logo; ?>" class="img-fluid rounded-circle" alt=""
                    style="height:200px;width:200px;" id="shop_prof" />

                <?php
                                             
                                         }
                                         
                                         ?>




                <br><br>
            
      


        </div>
       
<div class="col-9"></div>


    </div>

    <form id="shopprofile_form">
        <br>
    <i class="fa fa-edit btn  btn-rounded btn-outline-success" onclick="selectimage()"> Edit Shop Logo</i>
    <i class="fa fa-edit btn btn-rounded btn-outline-success  float-right" onclick="selectbanner()"> Edit banner</i>
        <br>
        <div class="row">
            <div class="col">

                <div class="input-group">

                    <input type="file" class="form-control form-control-lg border-left-0 insize" id="shop_pic"
                        name="shop_pic" style="height:6vh;display:none" accept="image/*" onchange="uloadFile(event)">

                        <input type="file" class="form-control form-control-lg border-left-0 insize" id="shop_banner"
                        name="shop_banner" style="height:6vh;display:none" accept="image/*" onchange="putbanner(event)">

                    <script>
                    var uloadFile = function(event) {
                        var output = document.getElementById('shop_prof');

                        output.src = URL.createObjectURL(event.target.files[0]);

                        output.onload = function() {
                            URL.revokeObjectURL(output.src) // free memory


                        }


                    };


                    var putbanner = function(event) {
                        var output = document.getElementById('banner_image');
                        var url = URL.createObjectURL(event.target.files[0]);

                        output.style.background="url("+url+")";
                        output.style.backgroundSize="cover";
                    

                    }
                    function selectbanner(){
                        $("#shop_banner").click();
                    }


                    function selectimage() {
                        $("#shop_pic").click();
                    }
                    </script>
                </div>


            </div>
        </div>
        <br>
        <div class="row">

            <h6>Shop Information</h6>
            <hr style="margin:1vh;">



            <div class="col">
                <input type="text" class="form-control form-control-lg  insize" id="up_sid" name="up_sid"
                    style="height:6vh;" value="<?php echo $id; ?>" hidden>

                <label for="">Shop Name</label>
                <div class="input-group">

                    <input type="text" class="form-control form-control-lg  insize" id="up_sname" name="up_sname"
                        style="height:6vh;" placeholder="Shop Name" value="<?php echo $shopname ; ?>">
                </div>


            </div>



            <div class="col-12">
               
                <label for="">Shop Description</label>
        

                  <textarea class="form-control form-control-lg" style="height:20vh;" id="up_sdesc" name="up_sdesc"><?php echo $s_desc;?></textarea>
             


            </div>

           





        </div>


        <div class="row">




            <div class="col">
                <label for="">Address</label>
                <div class="input-group">

                    <input type="text" class="form-control form-control-lg insize" id="up_saddress" name="up_address"
                        style="height:6vh;" placeholder="Address" value="<?php echo $address;
    ?>">
                </div>


            </div>




        </div>







<br>

        <div class="row">


            <h6>Contact Information</h6>
            <hr style="margin:1vh;">




            <div class="col">
            <label for="">Contact No</label>
            <div class="input-group">
              
                <input type="text" class="form-control form-control-lg insize" id="up_scontact" name="up_contact" style="height:6vh;" placeholder="Contact`" value="<?php echo $scontact;
    ?>">
            </div>


        </div>


        <div class="col">
            <label for="">Email</label>
            <div class="input-group">
              
                <input type="text" class="form-control form-control-lg insize" id="up_semail" name="up_email" style="height:6vh;" placeholder="Email" value="<?php echo $semail;
    ?>">
            </div>


        </div>





        </div>

        <br>

        <div class="float-right">
            <a href="#" class="btn btn-rounded btn-outline-success" onclick="up_shopprofile()"><i
                    class="fa fa-check approved"></i> Save Changes</a>

        </div>



    </form>


</div>