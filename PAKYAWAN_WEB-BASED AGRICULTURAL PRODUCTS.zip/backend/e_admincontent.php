<?php
include "../db.php";

$id = $_POST['userid'];     

?>


<div class="form-group">
    <?php

$sqlx = "SELECT *  FROM m_user_info where userid = '$id' ";
$resultx = $con->query( $sqlx );
$rowx = $resultx->fetch_assoc();
$fullname = $rowx['fullname'];
$age = $rowx['age'];
$address = $rowx['address'];
$email = $rowx['email'];
$contact = $rowx['contact'];
$image = $rowx['image'];
    
    
    

?>


<div class="form-group">

    <form id="userprofile_form">
        <br>
        

        <div class="row">

            <label for="" class="text-success">Personal Information</label>
            <hr style="margin:1vh;">



            <div class="col">
                <input type="text" class="form-control form-control-lg  insize" id="up_id" name="up_id"
                    style="height:6vh;" value="<?php echo $id; ?>" hidden>

                <label for="">Name</label>
                <div class="input-group">

                    <input type="text" class="form-control form-control-lg  insize" id="up_fullname" name="up_fullname"
                        style="height:6vh;" placeholder="Full Name" value="<?php echo $fullname; ?>">
                </div>


            </div>

            <div class="col">
                <label for="">Age</label>
                <div class="input-group">


                    <input type="number" class="form-control form-control-lg  insize" id="up_age" name="up_age"
                        style="height:6vh;" placeholder="Age" value="<?php echo $age; ?>">


                </div>


            </div>





        </div>


        <div class="row">




            <div class="col">
                <label for="">Address</label>
                <div class="input-group">

                    <input type="text" class="form-control form-control-lg insize" id="up_address" name="up_address"
                        style="height:6vh;" placeholder="Address" value="<?php echo $address;
    ?>">
                </div>


            </div>




        </div>









        <div class="row">


            <label for="" class="text-success">Contact Information</label>
            <hr style="margin:1vh;">




            <div class="col">
            <label for="">Contact No</label>
            <div class="input-group">
              
                <input type="text" class="form-control form-control-lg insize" id="up_contact" name="up_contact" style="height:6vh;" placeholder="Contact`" value="<?php echo $contact;
    ?>">
            </div>


        </div>


        <div class="col">
            <label for="">Email</label>
            <div class="input-group">
              
                <input type="text" class="form-control form-control-lg insize" id="up_email" name="up_email" style="height:6vh;" placeholder="Email" value="<?php echo $email;
    ?>">
            </div>


        </div>





        </div>

        <br>

        <div class="float-right">
        <a href="#" class="btn btn-rounded btn-danger" onclick="dconfirm_admin('<?php echo $id; ?>')"><i
                    class="fa fa-trash "></i></a>
            <a href="#" class="btn btn-rounded btn-outline-success" onclick="up_profile()"><i
                    class="fa fa-check approved"></i> Save Changes</a>

        </div>



    </form>


</div>