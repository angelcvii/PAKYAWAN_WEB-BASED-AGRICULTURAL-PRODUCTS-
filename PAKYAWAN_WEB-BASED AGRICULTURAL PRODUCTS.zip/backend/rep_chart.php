<?php
session_start();
$shopid = $_SESSION['uid'];
?>
<div class="col-xl-12 ">
	<article class="stat-cards-item">


		<h4>
			<i class="fa fa-folder "> &nbsp;
				<?php echo date('Y'); ?>
				Reservation Sales Report </i> <i
				class="btn btn-rounded btn-outline-success bi bi-clipboard-data float-right" onclick="sdata()"
				id="data_c"> Data</i> <i class="btn btn-rounded btn-success bi bi-bar-chart  float-right"
				onclick="cchart()" id="chart_c"> Chart </i> <i class="fa fa-print btn btn-rounded btn-light float-right"
				onclick="printreport()"></i>
		</h4>

		<hr>
		<br>

		<div id="chart_content">

			<canvas id="ocount" style="height:70vh;width:100vw;">
			</canvas>

			<?php
            include "../db.php";

$months = array();
$monthData = array();
$months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
$curryear = date('Y');

$jf = $curryear . "-01-01 00:00:00";
$jt = $curryear . "-01-31 23:59:59";

$ff = $curryear . "-02-01";
$ft = $curryear . "-02-28 23:59:59";

$mcf = $curryear . "-03-03";
$mct = $curryear . "-03-31 23:59:59";

$apf = $curryear . "-04-01";
$apt = $curryear . "-04-30 23:59:59";

$myf = $curryear . "-05-01";
$myt = $curryear . "-05-30 23:59:59";

$jnf = $curryear . "-06-01";
$jnt = $curryear . "-06-31 23:59:59";

$jlf = $curryear . "-07-01";
$jlt = $curryear . "-07-30 23:59:59";

$agf = $curryear . "-08-01";
$agt = $curryear . "-08-31 23:59:59";

$sef = $curryear . "-09-01";
$set = $curryear . "-09-30 23:59:59";

$ocf = $curryear . "-10-01";
$oct = $curryear . "-10-31 23:59:59";

$nof = $curryear . "-11-01";
$not = $curryear . "-11-30 23:59:59";

$def = $curryear . "-12-01";
$det = $curryear . "-12-31 23:59:59";








$jdata = array();
$fdata = array();
$mdata = array();
$adata = array();
$mydata = array();
$jndata = array();
$jldata = array();
$audata = array();
$sedata = array();
$odata = array();
$ndata = array();
$ddata = array();



$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$jf' and '$jt' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $jdata[] =  $totalAmt;
        }
    }
}



$monthData[] = array_sum($jdata);

$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$ff' and '$ft' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $fdata[] =  $totalAmt;
        }
    }
}



$monthData[] = $fdata;

$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$mcf' and '$mct' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $mdata[] =  $totalAmt;
        }
    }
}



$monthData[] = array_sum($mdata);

$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$apf' and '$apt' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $adata[] =  $totalAmt;
        }
    }
}



$monthData[] = array_sum($adata);


$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$myf' and '$myt' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $mydata[] =  $totalAmt;
        }
    }
}



$monthData[] =  array_sum($mydata);



$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$jnf' and '$jnt' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $jndata[] =  $totalAmt;
        }
    }
}



$monthData[] =  array_sum($jndata);


$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$jlf' and '$jlt' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $jldata[] =  $totalAmt;
        }
    }
}



$monthData[] =  array_sum($jldata);


$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$agf' and '$agt' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $audata[] =  $totalAmt;
        }
    }
}



$monthData[] =  array_sum($audata);

$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$sef' and '$set' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $sedata[] =  $totalAmt;
        }
    }
}



$monthData[] =  array_sum($sedata);




$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$ocf' and '$oct' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $odata[] =  $totalAmt;
        }
    }
}



$monthData[] =  array_sum($odata);


$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$nof' and '$not' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];

        $prodid = $rowz['product_id'];
        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $ndata[] =  $totalAmt;
        }
    }
}



$monthData[] =  array_sum($ndata);


$sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$def' and '$det' ";
$resultz = $con->query($sqlz);
if ($resultz->num_rows > 0) {
    while ($rowz = $resultz->fetch_assoc()) {
        $drid = $rowz['id'];
        $totalAmt = $rowz['total_amount'];
        $prodid = $rowz['product_id'];

        $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
        $resultm = $con->query($sqlm);
        if ($resultm->num_rows > 0) {
            $ddata[] =  $totalAmt;
        }
    }
}



$monthData[] =  array_sum($ddata);





?>

		</div>



		<!--data--->
		<div id="data_content">



		</div>





	</article>
</div>
<script>
	var ctx = document.getElementById("ocount");
	var myChart = new Chart(ctx, {
		backgroundColor: "#fff",
		type: 'bar',
		data: {
			datasets: [{


				label: "<?php echo $curryear; ?> Reservations Sales",
				type: "bar",
				backgroundColor: "#E11E0C",
				data:
					<?php echo json_encode($monthData) . ','; ?>
					// This binds the dataset to the right y axis
					yAxisID: 'right-y-axis',
				fill: false,



			}],
			labels: <?php echo json_encode($months) . ','; ?>
		},
		options: {
			scales: {
				yAxes: [{
					id: 'right-y-axis',
					type: 'linear',
					position: 'left',
					ticks: {
						beginAtZero: true
					},

				}]
			}
		}
	});