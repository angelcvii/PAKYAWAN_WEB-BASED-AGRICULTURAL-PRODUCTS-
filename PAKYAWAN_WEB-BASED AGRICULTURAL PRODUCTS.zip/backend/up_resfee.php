<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";



    date_default_timezone_set("Asia/Taipei");
    $date = date('Y-m-d H:i:s');

    $sellerid = $_POST['sellerid'];
    $resfee = $_POST['resfee'];

    $sql = "SELECT *  FROM d_reservation_fee  where seller_id = '$sellerid'  ";
    $result = $con->query($sql);
    if ($result->num_rows > 0) {
        $sql = "UPDATE d_reservation_fee SET  fee = '$resfee' , added_date = '$date' where seller_id = '$sellerid'  ";
        $result = $con->query($sql);

        if ($result) {
            echo '1';
        } else {
            echo '0';
        }
    } else {
        $sql = "INSERT INTO d_reservation_fee (seller_id,fee,added_date) VALUES ('$sellerid','$resfee','$date') ";
        $result = $con->query($sql);

        if ($result) {
            echo '1';
        } else {
            echo '0';
        }
    }
}
