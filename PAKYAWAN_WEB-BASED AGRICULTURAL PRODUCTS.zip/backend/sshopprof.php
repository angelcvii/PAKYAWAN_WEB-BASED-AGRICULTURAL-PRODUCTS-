<?php
session_start();
$sid = $_SESSION['uid'];

include "../db.php";
$sql = "SELECT *  FROM m_user_info where userid = '$sid'  ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $scontact = $row['contact'];
    $sadress = $row['address'];
    $semail = $row['email'];
    $shopname = $row['shopname'];
    $s_desc = $row['s_description'];
    $s_banner = $row['s_banner'];
    $s_logo = $row['s_logo'];

    if ($s_logo == "") {
        $s_logo = "default.png";
    }

    if ($s_banner == "") {
        $s_banner = "shop.jpg";
    }

    if ($s_desc == "") {
        $s_desc = "This is a sample shop description";
    }

    if ($scontact == "") {
        $scontact = "N/A";
    }

    if($semail == ""){
        $semail = "N/A";
    }
}

?>



<div class="row">

    <div class="col-sm-12 grid-margin stretch-card">

        <div class="card">
            <div style="margin:1vh;"> <a href="#" class="btn btn-outline-light btn-rounded float-right" onclick="e_shop_prof()" data-bs-toggle="modal" data-bs-target="#shopprofile_modal"> <i class="bi bi-pencil-square"></i> Edit Shop profile</a>
            </div>
            <div class="card-body">

                <div class="row" style="background-image:url('../data/shop/<?php echo $s_banner; ?>'); background-size:cover;">

                    <div class="col-3">

                        <img src="../data/shop/<?php echo $s_logo; ?>" class="img-fluid rounded-circle" alt="" style="height:35vh;width:35vh;margin-top:1.5vh;" id="prev_prof" />

                    </div>

                    <div class="col-9"></div>


                </div>

                <div class="row" style="margin-top:1vh;">

                    <div class="col">

                        <h4> <?php echo $shopname; ?> </h4>
                        <h6> <?php echo $s_desc; ?></h6>
                    </div>
                </div>

                <hr style="margin:1vh;">

                <div class="row" style="margin-top:1vh;">

                    <div class="col-12">


                        <h5 > Shop Address : <span class="text-success"> <?php echo $sadress; ?></span></h5>
                    </div>
                    <div class="col-12">


                        <h5 > Shop Contact : <span class="text-success"><?php echo $scontact; ?></span></h5>
                    </div>

                    <div class="col-12">


                        <h5 > Email : <span class="text-success"><?php echo $semail; ?></span></h5>
                    </div>

                </div>

                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="shopprofile_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog  modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Shop Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="shopprofile_content">

          



            </div>

        </div>
    </div>
</div>
