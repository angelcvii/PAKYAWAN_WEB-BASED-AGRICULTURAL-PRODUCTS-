<h4>
    <i class="bi bi-shield-lock "> </i> &nbsp; Administrator List 
    <i class="btn btn-rounded btn-outline-success bi bi-person-plus float-right"  data-bs-toggle="modal" data-bs-target="#addadmin_modal"> Add Admin</i></i>
</h4>


<hr>

<div class="table-responsive">
<table id="dt_admin_list" class="table table-striped table-bordered table-hover ">
    <thead>
        <tr>

            <th> Name </th>
            <th> Contact</th>
            <th>Email</th>
            <th>Username</th>
            <th> Registered Date</th>
            <th> Added by</th>
            <th class="text-center">Manage</th>
        </tr>
    </thead>
    <tbody>
        <?php
        include "../db.php";



        $sql = "SELECT  *  FROM m_user where  user_role = '1'   ";
        $result = $con->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $userid = $row['id'];
                $userrole = $row['user_role'];
                $username = $row['username'];
                $addeddate = $row['added_date'];
                $addedby = $row['added_by'];


                $sqlx = "SELECT *  FROM m_user_info where userid = '$userid'";
                $resultx = $con->query($sqlx);

                if ($resultx->num_rows > 0) {
                    $rowx = $resultx->fetch_assoc();


                    $name = $rowx['fullname'];
                    $contact = $rowx['contact'];
                    $address = $rowx['address'];
                    $email = $rowx['email'];
                  
                }




            
        ?>


                    <tr>

                        <td><?php echo  $name; ?></td>

                        <td><?php echo  $contact; ?></td>
                        <td><?php echo  $email; ?></td>
                        <td><?php echo  $username; ?></td>
                        <td><?php echo $addeddate; ?>
                        </td>
                        <td><?php echo $addedby; ?>
                        </td>
                        <td class="text-center">

                           
                                <i class="fa fa-edit" onclick="edit_admin('<?php echo $userid; ?>')" data-bs-toggle="modal" data-bs-target="#editadmin_modal"></i>
                           
                        
                        </td>
                    </tr>


        <?php

                }
            }
        



        ?>


    </tbody>
</table>
</div>