<?php

  include "../db.php";


  $pid = $_POST['prodid'];


  $path = "../data/products/";

  $sqlf = "SELECT image FROM d_product where id = '$pid' ";
  $resf = $con->query($sqlf);

  $row = $resf->fetch_assoc();

  if (!file_exists($path.$row['image'])) {
      $sql = "DELETE FROM d_product where id = '$pid' ";

      $result = $con->query($sql);

      if ($result) {
          echo '1';
      } else {
          echo '0';
      }
  } else {
      if ($row['image'] !== "") {
          //remove file
          unlink($path.$row['image']);


          $sql = "DELETE FROM d_product where id = '$pid' ";

          $result = $con->query($sql);

          if ($result) {
              echo '1';
          } else {
              echo '0';
          }
      }
  }
