<?php
include "../db.php";
$path = "../data/products/";
$prodid = $_POST['productid'];
$sql = "SELECT *  FROM d_product where id = '$prodid'  ";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $prodid = $row['id'];
    $catid = $row['cat_id'];
    $prodimage = $row['image'];
    $prodname = $row['description'];
    $seller_id = $row['seller_id'];
    $price = $row['price'];
    $farmsize = $row['farmsize'];
    $qty = $row['qty'];
    $c_location = $row['c_location'];
    $planted_date = $row['planted_date'];
    $harvest_date = $row['harvest_date'];



    $sqlS = "SELECT *  FROM m_user_info where userid = '$seller_id'";
    $resultS = $con->query($sqlS);
    $rowS = $resultS->fetch_assoc();
    $shopname = $rowS['shopname'];

    $sqlC = "SELECT *  FROM m_category where id = '$catid'";
    $resultC = $con->query($sqlC);
    $rowC = $resultC->fetch_assoc();
    $category = $rowC['description'];




    $sqlF= "SELECT fee  FROM d_reservation_fee where seller_id = '$seller_id'";
    $resultF = $con->query($sqlF);
    $rowF= $resultF->fetch_assoc();
    $reserv_fee = $rowF['fee'];

    $total = intval($price) + intval($reserv_fee);
}
?>


<div class="row">
	<div class="col-12">
		<div class="card ">
			<div class="row g-0">
				<div class="col-12">
					<img src="<?php echo $path.$prodimage; ?>"
						class="img-fluid rounded-start" alt="...">
				</div>
				<div class="col">
					<div class="card-body">
						<a href="#" class="text-success"
							onclick="shopProfile('<?php echo $seller_id; ?>')">
							<h6 class="card-sub-title"> <i class="bi bi-shop-window"></i> &nbsp;
								<?php echo $shopname; ?>
						</a>
						<h4><?php echo $prodname; ?></h4>

						<h4 class="text-danger">Pakyaw Price @ Php
							<?php echo  $price; ?>
						</h4>
						<hr>




						<table>
							<tbody>

								<tr>
									<td colspan="8">
										<h5>Category :</h5>
									</td>
									<td colspan="6">
										<h5 class="text-success">
											<?php echo $category; ?>
										</h5>
									</td>
								</tr>

								<tr>
									<td colspan="8">
										<h5>Farm Space :</h5>
									</td>
									<td colspan="6">
										<h5 class="text-success">
											<?php echo $farmsize; ?>
											Sqm
										</h5>
									</td>
								</tr>

								<tr>
									<td colspan="8">
										<h5>Planted Date :</h5>
									</td>
									<td colspan="6">
										<h5 class="text-success">
											<?php echo $planted_date; ?>
										</h5>
									</td>
								</tr>
								<tr>
									<td colspan="8">
										<h5> Ready to Harvest :
										</h5>
									</td>
									<td colspan="6">
										<h5 class="text-success">
											<?php echo $harvest_date; ?>
										</h5>
									</td>
								</tr>

								<tr>
									<td colspan="8">
										<h5> Reservation Fee :
										</h5>
									</td>
									<td colspan="6">
										<h5 class="text-success"> Php
											<?php echo  $reserv_fee; ?>
										</h5>
									</td>
								</tr>
								<tr>

									<td hidden> <input class="form-control form-control-sm text-center" type="number"
											value="1" id="itemqty" style="max-width:20vh;"></td>

									<td colspan="10">



									</td>

								</tr>
							</tbody>
						</table>

						<hr>
						<input type="checkbox" id="terms" class="bg-success"> I agree
						to the Terms
						and Conditions
						<br>

						<a class="btn btn-success btn-sm float-end" href="#"
							onclick="placeorder('<?php echo $prodid; ?>','<?php echo $price; ?>','<?php echo $reserv_fee; ?>','<?php echo $total; ?>')"
							style="max-width:60vh;">
							<i class="bi bi-clipboard-check"></i> Reserve</a>




					</div>

				</div>








				</p>



			</div>
		</div>
	</div>
</div>
</div>



</div>