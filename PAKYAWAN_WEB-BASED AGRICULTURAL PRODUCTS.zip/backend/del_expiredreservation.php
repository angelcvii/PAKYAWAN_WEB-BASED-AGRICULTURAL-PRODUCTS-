<?php

include "../db.php";
date_default_timezone_set("Asia/Taipei");
$date = date('Y-m-d');


$sql = "SELECT * FROM d_product where harvest_date >= DATE_SUB(($date),INTERVAL 1 DAY)";
$result = $con->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $prodid = $row['product_id'];

        $sqlx = "SELECT * FROM d_reservation_details where product_id = '$prodid'";
        $resultx = $con->query($sqlx);
        if ($resultx->num_rows > 0) {
            //Has Reservation
        } else {
            //No Reservation
            $sql = "DELETE FROM d_product where id = '$prodid' ";
            $result = $con->query($sql);
        }
    }
}
