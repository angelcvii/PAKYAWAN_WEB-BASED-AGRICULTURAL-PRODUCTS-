<?php
   include "../db.php";
   $catid = $_POST['catid'];
    $sql = "SELECT  *  FROM m_category where id = '$catid' ";
    $result = $con->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $catid = $row['id'];
    $category = $row['description'];
}
?>

<div class="row">
    <div class="col">


        <label for="">Product Category</label>
        <div class="input-group">

            <input type="text" class="form-control form-control-lg  insize" id="up_pcat" name="up_pcat"
                style="height:6vh;" placeholder="Product Category" value="<?php echo $category;?>">
        </div>


    </div>

</div>

<div class="row">

    <div class="col">
        <div class="float-right">
            <br>

            <a href="#" class="btn btn-rounded btn-danger" onclick="delcon_cat('<?php echo $catid; ?>')"><i
                    class="fa fa-trash"></i></a>
            <a href="#" class="btn btn-rounded btn-outline-success" onclick="up_category('<?php echo $catid; ?>')"><i
                    class="fa fa-check approved"></i> Save Changes</a>

        </div>

    </div>




</div>