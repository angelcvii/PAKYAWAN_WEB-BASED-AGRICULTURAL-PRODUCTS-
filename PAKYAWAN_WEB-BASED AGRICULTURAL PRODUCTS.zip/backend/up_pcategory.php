<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";



    date_default_timezone_set("Asia/Taipei");
    $date = date('Y-m-d H:i:s');

    $catid = $_POST['catid'];
    $prodcat = $_POST['cat'];
    


        $sql = "UPDATE m_category SET  description = '$prodcat' where id = '$catid' ";
        $result = $con->query($sql);

        if ($result) {
            echo '1';
        } else {
            echo '0';
        }
    }

        ?>