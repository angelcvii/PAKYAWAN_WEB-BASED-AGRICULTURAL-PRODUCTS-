
<h4> 
<i class="fa fa-leaf "> &nbsp; Shop Products </i> <i class="btn btn-rounded btn-outline-success fa fa-plus float-right" data-bs-toggle="modal"
                                            data-bs-target="#addprod_modal"> Add Product</i></i> </h4>


<hr>
<table id="dt_products_list" class="table table-striped table-bordered table-hover   ">
    <thead>
        <tr>
            <th> Product Image </th>
            <th> Product </th>
            <th> Price </th>
            <th>Farm Lot Size</th>
            <th> Added Date</th>
            <th class="text-center">Manage</th>
        </tr>
    </thead>
    <tbody>
        <?php
        include "../db.php";
        session_start();
        $sellerid = $_SESSION['uid'];
        $path = "../data/products/";

        $sql = "SELECT  *  FROM d_product where seller_id = '$sellerid' ";
        $result = $con->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                $prodid = $row['id'];
                $prodimage = $row['image'];
                $prodname = $row['description'];
                $price = $row['price'];
                $sqm = $row['farmsize'];
                $addeddate = $row['added_date'];



                $sqlm = "SELECT  description  FROM m_measurement where id = '$mes_id' ";
                $resultm = $con->query($sqlm);
                $rowm = $resultm->fetch_assoc();
                $measurement = $rowm['description'];
              




        ?>


                        <tr>
                            <td class="text-center"><img src="<?php echo $path.$prodimage; ?>" style="height:10vh;width:10vh;" class="rounded"> </td>
                        
                            <td><?php echo  $prodname; ?></td>

                            <td><?php echo  $price ; ?></td>
                            
                            <td>
                            <?php echo 
                            $sqm; 

                            ?> Sqm
                            </td>
                            <td><?php echo $addeddate; ?>
                            </td>
                            <td class="text-center"> <i class="fa fa-eye" onclick="editproduct(<?php echo   $prodid ; ?>)"  data-bs-toggle="modal"
                                            data-bs-target="#editprod_modal"></i> </td>
</td>
                        </tr>


        <?php

                    }
                }
      



        ?>


    </tbody>
</table>