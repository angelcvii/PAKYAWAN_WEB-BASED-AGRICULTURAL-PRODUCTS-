<?php

session_start();
$shopid = $_SESSION['uid'];
include "../db.php";
$order = 0;

$sql = "SELECT id  FROM d_product where seller_id = '$shopid' ";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $prodid = $row['id'];


        $sqlz = "SELECT status  FROM d_reservation_details where product_id = '$prodid' ";
        $resultz = $con->query($sqlz);
        $rowz = $resultz->fetch_assoc();

        $ostat = $rowz['status'];

        if ($ostat == "Pending") {
            $order++;
        }
    }
}

echo $order;
