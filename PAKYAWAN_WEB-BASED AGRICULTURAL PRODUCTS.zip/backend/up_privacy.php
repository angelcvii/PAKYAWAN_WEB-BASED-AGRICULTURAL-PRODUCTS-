<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";



    date_default_timezone_set("Asia/Taipei");
    $date = date('Y-m-d H:i:s');


    $pc = $_POST['privacy'];



    $sql = "UPDATE m_privacy SET  description = '$pc'  ";
    $result = $con->query($sql);

    if ($result) {
        echo '1';
    } else {
        echo '0';
    }
}
