<h4>
    <i class="fa fa-leaf "> </i> &nbsp; Products
</h4>


<hr>
<table id="dt_prod_list" class="table table-striped table-bordered table-hover   ">
    <thead>
        <tr>

            <th> Image </th>
            <th> Product </th>
            <th> Shop </th>
            <th> Price</th>
            <th> Farm Size</th>
            <th>Planted Date</th>
            <th> Harvest Date</th>
            <th> Crop Location</th>
            <th> Added Date </th>

        </tr>
    </thead>
    <tbody>
        <?php
        include "../db.php";

        $path = "../data/products/";

        $sql = "SELECT  *  FROM d_product   ";
        $result = $con->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {

                $pid = $row['id'];
                $catid = $row['cat_id'];
                $seller_id = $row['seller_id'];
                $prodname = $row['description'];
                $croplocation = $row['c_location'];
                $hdate = $row['harvest_date'];
                $pdate = $row['planted_date'];
                $image = $row['image'];
                $price = $row['price'];
                $addeddate = $row['added_date'];
                $sqm = $row['farmsize'];


                //measurement
                $sqlm = "SELECT *  FROM m_measurement where id = '$mesid'";
                $resultm = $con->query($sqlm);

                $rowm = $resultm->fetch_assoc();
                $measurement = $rowm['description'];


                $sqlx = "SELECT *  FROM m_user_info where userid = '$seller_id'";
                $resultx = $con->query($sqlx);

                if ($resultx->num_rows > 0) {
                    $rowx = $resultx->fetch_assoc();
                    $sname = $rowx['shopname'];


        ?>
                    <tr>
                        <td class="text-center"><img src="<?php echo $path . $image; ?>" style="height:10vh;width:10vh;" class="rounded"> </td>

                        <td><?php echo $prodname; ?></td>
                        <td><?php echo $sname; ?></td>
                        <td><?php echo   $price; ?></td>
                        <td><?php echo    $sqm; ?> Sqm</td>
                       
                        <td><?php echo   $pdate; ?></td>
                        <td><?php echo   $hdate; ?></td>
                        <td><?php echo    $croplocation; ?></td>
                        <td><?php echo   $addeddate; ?></td>
                    </tr>
        <?php

                }
            }
        }



        ?>


    </tbody>
</table>