<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include "../db.php";

    $proid = $_POST['up_id'];

    $pname = $_POST['u_prodname'];
    $catid = $_POST['u_category'];
    $sqm = $_POST['usqm'];
    $price = $_POST['u_price'];
    $cloc = $_POST['u_clocation'];
    $pdate = $_POST['u_pdate'];
    $hdate = $_POST['u_hdate'];

    $is_uploading = $_FILES["u_product_pic"]["error"];
    $can_pass = $is_uploading == 0 ? true : false;


    if ($can_pass) {
        $path = "../data/products/";

        $sqlf = "SELECT image FROM d_product where id = $proid";
        $resf = $con->query($sqlf);

        $row = $resf->fetch_assoc();

        if (!file_exists($path.$row['image'])) {
        } else {
            if ($row['image'] !== "") {
                //remove file
                unlink($path.$row['image']);
            }
        }
        mysqli_close($con);



        //add new file
        include "../db.php";

        $file_parts = pathinfo($_FILES["u_product_pic"]["name"]);
        $file_path = $pname.date('Ymd').'updated.'.$file_parts['extension'];
        move_uploaded_file($_FILES["u_product_pic"]["tmp_name"], $path.$file_path);
        $file = $file_path;





        //Update details
        $sql_update_hstat = "UPDATE d_product SET  cat_id = '$catid',description='$pname', price='$price', farmsize='$sqm',c_location='$cloc',planted_date='$pdate',harvest_date='$hdate',image='$file' where id = '$proid'";
        $u_hresult = $con->query($sql_update_hstat);

        if ($u_hresult) {
            echo '1';
        } else {
            echo '0';
        }
    } else {
        //Update details
        $sql_update_hstat = "UPDATE d_product SET  cat_id = '$catid',description='$pname', price='$price', farmsize='$sqm',c_location='$cloc',planted_date='$pdate',harvest_date='$hdate'  where id = '$proid'";
        $u_hresult = $con->query($sql_update_hstat);

        if ($u_hresult) {
            echo '1';
        } else {
            echo '0';
        }
    }
}
