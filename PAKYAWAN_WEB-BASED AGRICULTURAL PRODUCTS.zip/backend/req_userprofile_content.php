<?php
include "../db.php";

$userid = $_POST['userid'];

?>


<div class="form-group">
	<?php

    $sqlx = "SELECT *  FROM m_user_info where userid = '$userid' ";
$resultx = $con->query($sqlx);
$rowx = $resultx->fetch_assoc();
$fullname = $rowx['fullname'];
$age = $rowx['age'];
$address = $rowx['address'];
$email = $rowx['email'];
$contact = $rowx['contact'];
$image = $rowx['image'];


$sql = "SELECT *  FROM m_user where id = '$userid'";
$result = $con->query($sql);
$rowb = $result->fetch_assoc();
$isactive = $rowb['isActive'];

?>


	<div class="row" id="prof_image">



		<div class="col">



			<center>

				<?php
            if ($image == null) {
                ?>

				<img src="../data/profile/default.jpeg" class="img-fluid rounded-circle" alt=""
					style="height:200px;width:200px;" id="prev_prof" />


				<?php

            } else {
                ?>

				<img src="../data/profile/<?php echo $image; ?>"
					class="img-fluid rounded-circle" alt="" style="height:200px;width:200px;" id="prev_prof" />

				<?php

            }

?>




				<br><br>
			</center>


		</div>




	</div>

	<form id="userprofile_form">
		<br>
		<div class="row">
			<div class="col">

				<div class="input-group">

					<input type="file" class="form-control form-control-lg border-left-0 insize" id="profile_pic"
						name="profile_pic" style="height:6vh;display:none" accept="image/*" onchange="uloadFile(event)">

				</div>


			</div>
		</div>

		<div class="row">

			<label for="" class="text-success">Personal Information</label>
			<hr style="margin:1vh;">



			<div class="col">
				<input type="text" class="form-control form-control-lg  insize" id="up_id" name="up_id"
					style="height:6vh;"
					value="<?php echo $userid; ?>" hidden>

				<label for="">Name</label>
				<div class="input-group">

					<input type="text" class="form-control form-control-lg  insize" id="up_fullname" name="up_fullname"
						style="height:6vh;" placeholder="Full Name"
						value="<?php echo $fullname; ?>" disabled>
				</div>


			</div>

			<div class="col">
				<label for="">Age</label>
				<div class="input-group">


					<input type="number" class="form-control form-control-lg  insize" id="up_age" name="up_age"
						style="height:6vh;" placeholder="Age"
						value="<?php echo $age; ?>" disabled>


				</div>


			</div>





		</div>


		<div class="row">




			<div class="col">
				<label for="">Address</label>
				<div class="input-group">

					<input type="text" class="form-control form-control-lg insize" id="up_address" name="up_address"
						style="height:6vh;" placeholder="Address" value="<?php echo $address;
?>" disabled>
				</div>


			</div>




		</div>









		<div class="row">


			<label for="" class="text-success">Contact Information</label>
			<hr style="margin:1vh;">




			<div class="col">
				<label for="">Contact No</label>
				<div class="input-group">

					<input type="text" class="form-control form-control-lg insize" id="up_contact" name="up_contact"
						style="height:6vh;" placeholder="Contact`" value="<?php echo $contact;
?>" disabled>
				</div>


			</div>


			<div class="col">
				<label for="">Email</label>
				<div class="input-group">

					<input type="text" class="form-control form-control-lg insize" id="up_email" name="up_email"
						style="height:6vh;" placeholder="Email" value="<?php echo $email;
?>" disabled>
				</div>


			</div>





		</div>

		<br>

		<div class="float-right">
			<a href="#" class="btn btn-rounded btn-danger"
				onclick="delconfirm_req('<?php echo $userid; ?>','3')"><i
					class="fa fa-trash danger"></i>
			</a>


			<?php
            if ($isactive == 1) {
                ?>
			<a href="#" class="btn btn-rounded btn-outline-danger"
				onclick="up_account_stat('<?php echo $userid; ?>','2','7')"><i
					class="fa fa-close text-danger"></i>
				Block User Account</a>
			<?php

            } elseif ($isactive == 3) {
                ?>
			<a href="#" class="btn btn-rounded btn-outline-success"
				onclick="up_account_stat('<?php echo  $userid; ?>','2','1')"><i
					class="fa fa-check text-success"></i>
				Unblock User Account</a>
			<?php

            } else {
                ?>
			<a href="#" class="btn btn-rounded btn-outline-success"
				onclick="up_account_stat('<?php echo $userid; ?>','2','1')"><i
					class="fa fa-check approved"></i> Approve
				User Account</a>
			<?php
            }
?>
		</div>



	</form>


</div>