function success(notif) {
    Swal.fire({

        icon: 'success',
        title: notif,
        showConfirmButton: false,
        timer: 1500
    })
}



function failed(notif) {
    Swal.fire({

        icon: 'error',
        title: notif,
        showConfirmButton: false,
        timer: 1500
    })
}
function warning(notif) {
    Swal.fire({

        icon: 'warning',
        title: notif,
        showConfirmButton: false,
        timer: 1500
    })
}


function sendemail(sendto,subject,msg){
    var dataString = "email="+sendto+"&subject="+subject+"&msg="+msg;
    var url = '../backend/sendemail.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

           if(data == 1){
            success("Email Sent !");
           }


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}