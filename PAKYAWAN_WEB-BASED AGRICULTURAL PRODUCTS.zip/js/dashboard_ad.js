//general functions
function hide_div(div){
    $("#"+div).hide();
  }
  
  function show_div(div){
    $("#"+div).show();
  }

  function hidemodal(id){
    $("#"+id).modal("hide");
}

function allreservations(){
  show_div("all_reservations");
  hide_div("main_dashboard_content");
  hide_div("all_users");
  $("#dt_all_reservations").DataTable();
}

function maindashboard(){
  hide_div("all_reservations");
  show_div("main_dashboard_content");
  hide_div("all_users");
  $("#dt_users").DataTable();
}

function allusers(){
  hide_div("all_reservations");
  hide_div("main_dashboard_content");
  show_div("all_users");
  $("#dt_users").DataTable();
}


