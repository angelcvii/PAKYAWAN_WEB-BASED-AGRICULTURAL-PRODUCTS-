function getAShopList() {

  var dataString = "";
  var url = "../backend/ashoplist.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#ashoplist_main_content").html(data);
      $("#dt_shop_list").DataTable();
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}
