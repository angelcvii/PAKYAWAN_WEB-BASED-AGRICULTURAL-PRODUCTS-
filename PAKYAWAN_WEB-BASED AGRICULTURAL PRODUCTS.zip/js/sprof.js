function getshopprof(){
    var dataString = "";
    var url = '../backend/sshopprof.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#Sshopprof_content").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function e_shop_prof(){
    var dataString = "";
    var url = '../backend/e_shopprof_content.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#shopprofile_content").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function up_shopprofile() {
    var form = document.getElementById("shopprofile_form");
    var fdata = new FormData(form);
    $.ajax({
      type: "POST",
      url: "../backend/u_shopprof.php",
      data: fdata,
      contentType: false,
      cache: false,
      processData: false,
      success: function (result) {
        if (result == 11 || result == 01) {
         
          success("Changes Saved !");
          $("#shopprofile_modal").modal("hide");
       
          setTimeout(function() {
            getshopprof();
          }, 1000);
     
        
        } else {
          failed("Failed, Please try again later.");
        }
      },
    });
  }
