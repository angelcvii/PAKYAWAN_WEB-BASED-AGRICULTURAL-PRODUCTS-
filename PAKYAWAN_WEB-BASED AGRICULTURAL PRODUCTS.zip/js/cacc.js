function up_account() {
    var form = document.getElementById("account_form");
    var fdata = new FormData(form);
    $.ajax({
      type: "POST",
      url: "../backend/u_account.php",
      data: fdata,
      contentType: false,
      cache: false,
      processData: false,
      success: function (result) {
        if (result == 1) {
         
          success("Account Changes Saved !");
        
          setTimeout(function() {
            location.reload();
          }, 1000);
     
        }else if(result == 3){
            warning("Old Password Mismatch !");
        } else {
          failed("Failed, Please try again later.");
        }
      },
    });
  }