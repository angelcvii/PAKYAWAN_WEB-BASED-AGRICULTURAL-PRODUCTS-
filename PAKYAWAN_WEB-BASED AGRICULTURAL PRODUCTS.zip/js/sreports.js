function getSRepchart(){
    var dataString = "";
    var url = '../backend/rep_chart.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#shop_reports_main_content").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}



function curr(id) {
    const element = document.getElementById(id);
    element.classList.remove("btn-outline-success");
    element.classList.add("btn-success");
    
  }
  
  function ncurr(id) {
    const element = document.getElementById(id);
    element.classList.add("btn-outline-success");
    element.classList.remove("btn-success");
  }
  
  function sdata(){
  curr("data_c");
  ncurr("chart_c");
  getrepdata();
  hide_div("chart_content");
  show_div("data_content");
  }
  
  function cchart(){
    ncurr("data_c");
    curr("chart_c");
    show_div("chart_content");
    hide_div("data_content");
  }



  function getrepdata(){
    var dataString = "";
    var url = '../backend/rep_data.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#data_content").html(data);
            $("#dt_reporders_list").DataTable();

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
  }


  function printreport(){
    var url = '../report/printreport.php';
    window.open(url, '_blank');
  }

