function active(id) {
    const element = document.getElementById(id);
    element.classList.add("active");
}

function notactive(id) {
    const element = document.getElementById(id);
    element.classList.remove("active");
}

///Seller Side Bar
//content
var adash = "#Adash_content";
var aaccreq = "#Aacc_req_content";
var ashop = "#Ashop_list_content";
var aprods = "#Aproducts_list_content";
var asett = "#Aacc_settings_content";
var asetcont = "#ASettings_content";


//Sidebar item Name
var asda = "aside_dash";
var assac = "aside_accrequest";
var aspl = "aside_shoplist";
var aspr = "aside_prods";
var asacs = "aside_accsetting";
var asad = "aside_admin";

adashtab();
function adashtab() {

  $(adash).show();
  $(aaccreq).hide();
  $(ashop).hide();
  $(aprods).hide();
  $(asett).hide();
  $(asetcont).hide();

  active(asda);
  notactive(assac);
  notactive(aspl);
  notactive(aspr);
  notactive(asacs);
  notactive(asad);
  accrequests_count();

}

function aaccreqtab() {

    $(adash).hide();
    $(aaccreq).show();
    $(ashop).hide();
    $(aprods).hide();
    $(asett).hide();
    $(asetcont).hide();
  
    notactive(asda);
    active(assac);
    notactive(aspl);
    notactive(aspr);
    notactive(asacs);
    notactive(asad);
    getAccRList();
    accrequests_count();
  
  }

  function ashoplsttab(){

    $(adash).hide();
    $(aaccreq).hide();
    $(ashop).show();
    $(aprods).hide();
    $(asett).hide();
    $(asetcont).hide();
  
    notactive(asda);
    notactive(assac);
    active(aspl);
    notactive(aspr);
    notactive(asacs);
    notactive(asad);
    accrequests_count();
    getAShopList();
  }


  function aprodstab(){
    $(adash).hide();
    $(aaccreq).hide();
    $(ashop).hide();
    $(aprods).show();
    $(asett).hide();
    $(asetcont).hide();
  
    notactive(asda);
    notactive(assac);
    notactive(aspl);
    active(aspr);
    notactive(asacs);
    notactive(asad);
    accrequests_count();
    getAProductList();
  }


  function accsettab(){
    $(adash).hide();
    $(aaccreq).hide();
    $(ashop).hide();
    $(aprods).hide();
    $(asett).show();
    $(asetcont).hide();
  
    notactive(asda);
    notactive(assac);
    notactive(aspl);
    notactive(aspr);
    active(asacs);
    notactive(asad);
    accrequests_count();
  }

  function aadmintab(){
    $(adash).hide();
    $(aaccreq).hide();
    $(ashop).hide();
    $(aprods).hide();
    $(asett).hide();
    $(asetcont).show();
  
    notactive(asda);
    notactive(assac);
    notactive(aspl);
    notactive(aspr);
    notactive(asacs);
    active(asad);
    accrequests_count();

    show_div("adminsettings_main");
    hide_div("prodcat_main");
    hide_div("measurement_main");

    getAadminList();
  }

  function prodcattab(){
    $(adash).hide();
    $(aaccreq).hide();
    $(ashop).hide();
    $(aprods).hide();
    $(asett).hide();
    $(asetcont).show();
  
    notactive(asda);
    notactive(assac);
    notactive(aspl);
    notactive(aspr);
    notactive(asacs);
    active(asad);

    hide_div("adminsettings_main");
    show_div("prodcat_main");
    hide_div("measurement_main");

    getPCatList();
  }

  function measuretab(){
    $(adash).hide();
    $(aaccreq).hide();
    $(ashop).hide();
    $(aprods).hide();
    $(asett).hide();
    $(asetcont).show();
  
    notactive(asda);
    notactive(assac);
    notactive(aspl);
    notactive(aspr);
    notactive(asacs);
    active(asad);

    hide_div("adminsettings_main");
    hide_div("prodcat_main");
    show_div("measurement_main");

    getPMeasList();
  }