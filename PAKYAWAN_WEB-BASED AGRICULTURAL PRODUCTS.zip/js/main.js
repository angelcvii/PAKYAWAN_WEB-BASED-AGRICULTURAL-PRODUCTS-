//Side navigation//


function dashbtab() {
    document.getElementById("dashb_tab").style.display = "block";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";
    document.getElementById("users_tab").style.display = "none";
    document.getElementById("documentl_tab").style.display = "none";
    //navigation_active_tab
    activetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_incident");
    notactivetab("side_project");
    notactivetab("side_resident");
    notactivetab("side_cost");
    notactivetab("side_user");
    notactivetab("side_ldocument");

    getresidentcount()
    getrequestcount()
    getincidentcount()
    getprojectscount()
}

function documenttab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "block";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";
    document.getElementById("users_tab").style.display = "none";
    document.getElementById("documentl_tab").style.display = "none";

    //navigation_active_tab
    activetab("side_document");
    notactivetab("side_dash");
    notactivetab("side_incident");
    notactivetab("side_project");
    notactivetab("side_resident");
    notactivetab("side_cost");
    notactivetab("side_user");
    notactivetab("side_ldocument");
    getdrequestlist()
}

function addcomp_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "block";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";
    document.getElementById("users_tab").style.display = "none";
    document.getElementById("documentl_tab").style.display = "none";
    //navigation_active_tab

    activetab("side_incident");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_project");
    notactivetab("side_resident");
    notactivetab("side_cost");
    notactivetab("side_user");
    notactivetab("side_ldocument");

}

function complist_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "block";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";
    document.getElementById("users_tab").style.display = "none";
    document.getElementById("documentl_tab").style.display = "none";
    //navigation_active_tab
    activetab("side_incident");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_project");
    notactivetab("side_resident");
    notactivetab("side_cost");
    notactivetab("side_user");
    notactivetab("side_ldocument");
    getincidentlist()
}



function addproj_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "block";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";
    document.getElementById("users_tab").style.display = "none";
    //navigation_active_tab
    activetab("side_project");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_incident");
    notactivetab("side_resident");
    notactivetab("side_cost");
    notactivetab("side_user");
    notactivetab("side_ldocument");
    document.getElementById("documentl_tab").style.display = "none";
}

function projlist_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "block";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";
    document.getElementById("users_tab").style.display = "none";
    //navigation_active_tab
    activetab("side_project");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_incident");
    notactivetab("side_resident");
    notactivetab("side_cost");
    notactivetab("side_user");
    notactivetab("side_ldocument");
    document.getElementById("documentl_tab").style.display = "none";
    getprojectlist();
}

function addresident_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";

    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "block";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";
    document.getElementById("users_tab").style.display = "none";
    document.getElementById("documentl_tab").style.display = "none";
    //navigation_active_tab
    activetab("side_resident");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_incident");
    notactivetab("side_project");

    notactivetab("side_cost");
    notactivetab("side_user");
    notactivetab("side_ldocument");

}

function residentlist_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "block";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";
    document.getElementById("users_tab").style.display = "none";
    //navigation_active_tab
    document.getElementById("documentl_tab").style.display = "none";
    activetab("side_resident");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_incident");
    notactivetab("side_project");
    notactivetab("side_cost");
    notactivetab("side_user");
    notactivetab("side_ldocument");
    getresidentlist()

}

function incomereport_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "block";
    document.getElementById("expenditures_tab").style.display = "none";
    document.getElementById("users_tab").style.display = "none";
    document.getElementById("documentl_tab").style.display = "none";
    //navigation_active_tab

    activetab("side_cost");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_incident");
    notactivetab("side_project");
    notactivetab("side_resident");
    notactivetab("side_user");
    notactivetab("side_ldocument");
}

function expenditures_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "block";
    document.getElementById("users_tab").style.display = "none";
    document.getElementById("documentl_tab").style.display = "none";
    activetab("side_cost");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_incident");
    notactivetab("side_project");
    notactivetab("side_resident");
    notactivetab("side_user");
    notactivetab("side_ldocument");
}

function users_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";


    document.getElementById("users_tab").style.display = "block";
    document.getElementById("documentl_tab").style.display = "none";

    activetab("side_user");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_incident");
    notactivetab("side_project");
    notactivetab("side_resident");
    notactivetab("side_cost");
    notactivetab("side_ldocument");
 getuserlist();
}

function Documentl_tab() {
    document.getElementById("dashb_tab").style.display = "none";
    document.getElementById("document_tab").style.display = "none";
    document.getElementById("addcomp_tab").style.display = "none";
    document.getElementById("complist_tab").style.display = "none";
    document.getElementById("addproj_tab").style.display = "none";
    document.getElementById("projlist_tab").style.display = "none";
    document.getElementById("addresident_tab").style.display = "none";
    document.getElementById("residentlist_tab").style.display = "none";
    document.getElementById("incomereport_tab").style.display = "none";
    document.getElementById("expenditures_tab").style.display = "none";


    document.getElementById("users_tab").style.display = "none";
    document.getElementById("documentl_tab").style.display = "block";

    activetab("side_ldocument");
    notactivetab("side_user");
    notactivetab("side_dash");
    notactivetab("side_document");
    notactivetab("side_incident");
    notactivetab("side_project");
    notactivetab("side_resident");
    notactivetab("side_cost");
    
   getudocumentlist()

}


function activetab(id) {
    var element = document.getElementById(id);
    element.classList.add("active");
}

function notactivetab(id) {
    var element = document.getElementById(id);
    element.classList.remove("active");
}
//Side navigation//


function success(notif) {
    Swal.fire({

        icon: 'success',
        title: notif,
        showConfirmButton: false,
        timer: 1500
    })
}

function warning(notif) {
    Swal.fire({

        icon: 'warning',
        title: notif,
        showConfirmButton: false,
        timer: 1500
    })
}



function failed(notif) {
    Swal.fire({

        icon: 'error',
        title: notif,
        showConfirmButton: false,
        timer: 1500
    })
}

//Authenticate

function login() {

    var username = $.trim($("#username").val());
    var password = $.trim($("#passw").val());

    var dataString = "username=" + username + "&password=" + password;
    var url = './backend/auth.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {




            if (data.trim() === 'admin') {
                success("Access Granted");
                setTimeout((window.location.href = 'admin/admin'), 3000);

            } else if (data.trim() === 'secretary') {
                success("Access Granted");
                setTimeout((window.location.href = 'secretary/secretary'), 3000);

            } else if (data.trim() === 'chairman') {
                success("Access Granted");
                setTimeout((window.location.href = 'chairman/chairman'), 3000);
                
                   } else if (data.trim() === 'official') {
                success("Access Granted");
                setTimeout((window.location.href = 'officials/official'), 3000);
                       
                         } else if (data.trim() === 'treasurer') {
                success("Access Granted");
                setTimeout((window.location.href = 'treasurer/treasurer'), 3000);


            } else {
                failed("Access Denied");
            }







        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}


//******** ADD RESIDENT *******//

$('#add_resident_form').on('submit', function (e) {
    e.preventDefault();
    var form = document.getElementById('add_resident_form');
    var fdata = new FormData(form);
    $.ajax({
        type: "POST",
        url: '../backend/addresident',
        data: fdata,
        contentType: false,
        cache: false,
        processData: false,
        success: function (result) {

            if (result.trim() === 'success') {

                success("Resident Added !")

                resetform("add_resident_form");
                //document.getElementById("prev_dept").src = "../images/default_image.png";

            } else if (result.trim() === 'exist') {
                failed("Resident already exist !")
            } else {
                failed("Failed, Please try again later.")
            }
        }
    });
});

function resetform(id) {
    document.getElementById(id).reset();

}

function getresidentlist() {
    var dataString = "";
    var url = '../backend/residentlist.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#rlist").html(data);
            $("#rtable").DataTable();
            document.getElementById("photo").src = "../img/avatar/user-default.png";




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function getr_details(id) {
    var dataString = "id=" + id;
    var url = '../backend/residentdetails.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#r_content").html(data);




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function deleteresidentconfirm(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            deleteresident(id)
        }
    })
}

function deleteresident(id) {
    var dataString = "id=" + id;
    var url = '../backend/deleteresident';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {
                getresidentlist();
                $("#r_details").modal("hide");
                success("Deleted Successfully !")




            } else {
                failed("Failed, Please try again later.")
            }






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

/*** Document Request panel***/


function getdrequestlist() {
    var dataString = "";
    var url = '../backend/reqdoclist';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#document_request_list").html(data);
            $("#docreq_table").DataTable();


            $("#resresult").hide();
            $("#resquerylist").hide();
            $("#reqpayment").hide();


            $("#drmaindiv").show();

            $("#resquerylist").show();

            $("#resqueryinput").show();


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function queryresident(resname) {
    var dataString = "name=" + resname;
    var url = '../backend/queryresident';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#t_qresidentlist").html(data);

            $("#resquerylist").show();
            $("#resresult").hide();



        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function selectresident(id) {
    var dataString = "id=" + id;
    var url = '../backend/d_req_resident';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#resresult").html(data);

            $("#resresult").show();
            $("#resquerylist").hide();




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function docpayment() {


    var resident_id = $.trim($("#resident_id").val());
    var doc_type = $.trim($("#doctype").val());

    if (doc_type === '') {
        warning("Please Select Document !")
    } else {





        var dataString = "residentid=" + resident_id + "&doctype=" + doc_type;
        var url = '../backend/paymentrequest';



        $.ajax({
            type: "POST",
            crossDomain: true,
            cache: false,
            url: url,
            data: dataString,
            beforeSend: function () {

            },
            success: function (data) {



                $("#reqpayment").html(data);

                $("#resqueryinput").hide();




            },
            error: function (jqXHR, status, err) {

            },
            complete: function (jqXHR, status) {



            }
        });




        $("#resresult").hide();
        $("#resquerylist").hide();
        $("#reqpayment").show();
        $("#drmaindiv").hide();
    }
}


function requestmore(id) {
    $("#drmaindiv").show();
    $("#resresult").show();
    $("#resquerylist").hide();
    $("#reqpayment").hide();
    $("#cartbtn").show();
    getrcount(id)
}

function viewreqcart() {
    $("#drmaindiv").hide();
    $("#resresult").hide();
    $("#resquerylist").hide();
    $("#reqpayment").show();

}

function removedocx(id, resid) {
    var dataString = "id=" + id + "&resid=" + resid;
    var url = '../backend/deletedocrequest';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            $("#prequest").html(data);






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}


function totalchange() {

    let change = 0;
    change = parseFloat($("#r_ct").val(), 10) - parseFloat($('#totalamt').val(), 10);
    $("#change").val(change);

}

function cancelrequest(sessid) {



    var dataString = "sessid=" + sessid;
    var url = '../backend/cancelreq';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            if (data.trim() === 'success') {

                $("#drmaindiv").show();
                $("#resresult").hide();
                $("#resquerylist").show();
                $("#reqpayment").hide();
                $("#resqueryinput").show();
                $("#cartbtn").hide();

            } else {
                failed("Something's wrong, Please Contact Administrator !.")
            }




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function getrcount(sessid) {
    var dataString = "sessid=" + sessid;
    var url = '../backend/rcount';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            $("#r_count").html(data);






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}


function proceedpayment(sessid) {
    var resident_id = $.trim($("#resid").val());
    var totalamt = $.trim($("#totalamt").val());
    var cashtendered = $.trim($("#r_ct").val());
    var change = $.trim($("#change").val());



    if (parseFloat(cashtendered) < parseFloat(totalamt)) {
        failed("Unsufficient Cash Payment !")
    } else {



        var dataString = "sessid=" + sessid + "&totalamt=" + totalamt + "&cashtendered=" + cashtendered + "&change=" + change + "&resid=" + resident_id;


        var url = '../backend/proceedpayment';



        $.ajax({
            type: "POST",
            crossDomain: true,
            cache: false,
            url: url,
            data: dataString,
            beforeSend: function () {

            },
            success: function (data) {




                if (data.trim() === 'success') {
                    getdrequestlist()
                    cancelrequest();
                    $("#m_docrequest").modal("hide");
                    success("Payment Success !")




                } else {
                    failed("Failed, Please try again later.")
                }





            },
            error: function (jqXHR, status, err) {

            },
            complete: function (jqXHR, status) {



            }
        });
    }

}


function deleterequest(id) {
    var dataString = "id=" + id;
    var url = '../backend/deleteresrequest';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {


                success("Deleted Successfully !")

                getdrequestlist()


            } else {
                failed("Failed, Please try again later.")
            }






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function deleterequestconfirm(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            deleterequest(id)
        }
    })
}

function printdocx(r_id, doc_page,doc_id) {


 if (doc_id === '4'){
        var url = '../documents/' + doc_page + '?resid=' + r_id + "&docid="+doc_id;
    window.open(url, '_blank');
   }else{
    
   var url = '../documents/' + doc_page + '?resid=' + r_id;
    window.open(url, '_blank');
    
   }
    
    




}

function resverification(id, docid, stat) {

    var dataString = "id=" + id + "&docid=" + docid + "&stat=" + stat;
    var url = '../backend/docreqverification';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {
            $("#residentprof_modal").html(data);







        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}


function approverequest(id, docid) {
    var dataString = "resid=" + id + "&docid=" + docid;
    var url = '../backend/docreqapprove';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {


                success("Request Approved !")
                getdrequestlist()
                $("#docrequest_mod").modal("hide");



            } else {
                failed("Failed, Please try again later.")
            }




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}



/*Complaints tab*/

function querycomplainee(resname) {
    var dataString = "name=" + resname;
    var url = '../backend/querycomplainee';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#t_qcomplaineelist").html(data);

            $("#complaineequerylist").show();




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function selectcomplainee(id, fname) {


    $("#c_resident").val(fname);
    $("#c_id").val(id);
    $("#complaineequerylist").hide();

}

function querycomplainant(resname) {
    var dataString = "name=" + resname;
    var url = '../backend/querycomplainant';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#t_qcomplainantlist").html(data);

            $("#complainantquerylist").show();




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function selectcomplainant(id, fname) {


    $("#co_resident").val(fname);
    $("#co_id").val(id);
    $("#complainantquerylist").hide();

}


function savecomplaint() {

    var c_subject = $.trim($("#c_subject").val());
    var complainant_id = $.trim($("#co_id").val());
    var complainee_id = $.trim($("#c_id").val());
    var c_description = $.trim($("#c_description").val());

    if (complainant_id === '' && complainee_id === '' && c_subject === '' && c_description === '' && c_description === '') {
        warning("Missing Required fields ! ")

    } else if (complainant_id === '') {
        warning("Please Enter Complainant Name")
    } else if (complainee_id === '') {
        warning("Please Enter Complainee Name")
    } else if (complainant_id == complainee_id) {
        warning("Same name detected ")
    } else if (c_subject === '') {
        warning("Complaint Subject is required ! ")
    } else if (c_description === '') {
        warning("Please Describe Scenario ")

    } else {




        var dataString = "c_subject=" + c_subject + "&complainant=" + complainant_id + "&complainee=" + complainee_id + "&c_description=" + c_description;


        var url = '../backend/addcomplaint';



        $.ajax({
            type: "POST",
            crossDomain: true,
            cache: false,
            url: url,
            data: dataString,
            beforeSend: function () {

            },
            success: function (data) {




                if (data.trim() === 'success') {

                    success("Added Successfully !")

                    clearaddcomp()


                } else {
                    failed("Failed, Please try again later.")
                }





            },
            error: function (jqXHR, status, err) {

            },
            complete: function (jqXHR, status) {



            }
        });

    }
}


function clearaddcomp() {
    $("#c_subject").val("");
    $("#co_id").val("");
    $("#co_resident").val("");
    $("#c_resident").val("");
    $("#c_id").val("");
    $("#c_description").val("");
}

function getincidentlist() {
    var dataString = "";
    var url = '../backend/incidentlist';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#ilist").html(data);
            $("#incident_table").DataTable();





        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function geti_details(id) {
    var dataString = "id=" + id;
    var url = '../backend/incidentdetails';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#i_content").html(data);




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}




function equerycomplainee(resname) {
    var dataString = "name=" + resname;
    var url = '../backend/equerycomplainee';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#t_ecomplaineelist").html(data);

            $("#ecomplaineequerylist").show();




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function eselectcomplainee(id, fname) {


    $("#ce_resident").val(fname);
    $("#ce_id").val(id);
    $("#ecomplaineequerylist").hide();

}

function equerycomplainant(resname) {
    var dataString = "name=" + resname;
    var url = '../backend/equerycomplainant';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#t_ecomplainantlist").html(data);

            $("#ecomplainantquerylist").show();




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function eselectcomplainant(id, fname) {


    $("#coe_resident").val(fname);
    $("#coe_id").val(id);
    $("#ecomplainantquerylist").hide();

}


function updatecomplaint(id) {
    var c_subject = $.trim($("#ce_subject").val());
    var complainant_id = $.trim($("#coe_id").val());
    var complainee_id = $.trim($("#ce_id").val());
    var c_description = $.trim($("#ce_description").val());

    if (complainant_id === '' && complainee_id === '' && c_subject === '' && c_description === '' && c_description === '') {
        warning("Missing Required fields ! ")

    } else if (complainant_id === '') {
        warning("Please Enter Complainant Name")
    } else if (complainee_id === '') {
        warning("Please Enter Complainee Name")
    } else if (complainant_id == complainee_id) {
        warning("Same name detected ")
    } else if (c_subject === '') {
        warning("Complaint Subject is required ! ")
    } else if (c_description === '') {
        warning("Please Describe Scenario ")

    } else {




        var dataString = "c_subject=" + c_subject + "&complainant=" + complainant_id + "&complainee=" + complainee_id + "&c_description=" + c_description + "&id=" + id;


        var url = '../backend/updatecomplaint';



        $.ajax({
            type: "POST",
            crossDomain: true,
            cache: false,
            url: url,
            data: dataString,
            beforeSend: function () {

            },
            success: function (data) {




                if (data.trim() === 'success') {

                    success("Changes Saved !")

                    getincidentlist()
                    $("#incident_details").modal("hide");

                } else {
                    failed("Failed, Please try again later.")
                }





            },
            error: function (jqXHR, status, err) {

            },
            complete: function (jqXHR, status) {



            }
        });
    }

}

function deletecomplaint(id) {
    var dataString = "id=" + id;
    var url = '../backend/deleteincident';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {

                success("Deleted Successfully !")

                getincidentlist()
                $("#incident_details").modal("hide");

            } else {
                failed("Failed, Please try again later.")
            }







        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function deleteincidentconfirm(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            deletecomplaint(id)
        }
    })
}


/***** Project Proposal *****/


function setbudget() {


    var pname = $.trim($("#a_projectname").val());
    var pcontractor = $.trim($("#a_contractor").val());
    var dfrom = $.trim($("#dfrom").val());
    var dto = $.trim($("#dto").val());
    var desc = $.trim($("#a_desc").val());

    if (pname === '' && pcontractor === '' && dfrom === '' && dto === '' && desc === '') {
        warning("Missing Required fields !")
    } else if (pname === '') {
        warning("Project Name is Required !")
    } else if (pcontractor === '') {
        warning("Project Contractor is Required !")
    } else if (dfrom === '') {
        warning("Project Duration is Required !")
    } else if (dto === '') {
        warning("Project Duration is Required !")
    } else if (desc === '') {
        warning("Project Description is Required !")
    } else {





        $("#steps").html("Step 2 : Setting Up Project Budget Proposal");
        $("#s1").hide();
        $("#s3").hide();
        $("#s2").show();
        $("#s4").hide();

    }


}

function backs1() {
    $("#steps").html("Step 1 : Setting Up Project Details");
    $("#s1").show();
    $("#s2").hide();
    $("#s3").hide();
    $("#s4").hide();
}

function createexpenditure() {
    var pbudget = $.trim($("#p_budget").val());

    if (pbudget === '0.00') {
        warning("Budget is Required !")
    } else {

        getitemtemp()

        $("#steps").html("Step 3 : Creating Project Expenditures");
        $("#s4").hide();
        $("#s3").show();
        $("#s2").hide();
        $("#s1").hide();
    }


}

function backs2() {
    $("#steps").html("Step 2 : Setting Up Project Budget Proposal");
    $("#s1").hide();
    $("#s2").show();
    $("#s3").hide();
}

function projectreview() {
    var pname = $.trim($("#a_projectname").val());
    var dfrom = $.trim($("#dfrom").val());
    var dto = $.trim($("#dto").val());
    var desc = $.trim($("#a_desc").val());
    var pbudget = $.trim($("#p_budget").val());

    $("#pname_rev").val(pname);
    $("#dfrom_rev").val(dfrom);
    $("#dto_rev").val(dto);
    $("#desc_rev").val(desc);
    $("#pbudget_rev").val(pbudget);

    $("#steps").html("Step 4 : Project Review");
    $("#s1").hide();
    $("#s2").hide();
    $("#s3").hide();
    $("#s4").show();
}


function additem() {

    var iname = $.trim($("#item_name").val());
    var iqty = $.trim($("#item_qty").val());
    var amtpc = $.trim($("#amtpc").val());
    var t_amount = $.trim($("#itm_total").val());




    var dataString = "iname=" + iname + "&qty=" + iqty + "&amtpc=" + amtpc + "&tamount=" + t_amount;
    var url = '../backend/addtmpitem';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {



                getitemtemp()
                $("#add_item").modal("hide");
                clearitem()


            } else {
                failed("Failed, Please try again later.")
            }







        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}

function clearitem() {
    // clear fields//
    $("#item_name").val(" ");
    $("#item_qty").val(" ");
    $("#amtpc").val(" ");
    $("#itm_total").val(" ");
}

function calculateitem(qty) {
    let itm_total = 0;
    let iamtpc = $("#amtpc").val();
    var iqty = $.trim($("#item_qty").val());
    if (iqty === '') {
        itm_total = parseFloat(iamtpc, 10) * 0;
        $("#itm_total").val(itm_total);

    } else {
        itm_total = parseFloat(iamtpc, 10) * parseFloat(qty, 10);
        $("#itm_total").val(itm_total);

    }



}

function calculateitemx(amtpc) {
    let itm_total = 0;

    let iqty = $("#item_qty").val();

    var amtppc = $.trim($("#amtpc").val());


    if (amtppc === '') {
        itm_total = parseFloat(amtpc, 10) * 0;
        $("#itm_total").val(itm_total);

    } else {
        itm_total = parseFloat(amtpc, 10) * parseFloat(iqty, 10);
        $("#itm_total").val(itm_total);

    }


}

function getitemtemp() {
    var dataString = "";
    var url = '../backend/itemlist_temp';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {




            $("#s3").html(data);





        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function deleteitmtemp(id) {
    var dataString = "id=" + id;
    var url = '../backend/deleteitemtemp';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {

                getitemtemp()

            } else {
                failed("Failed, Please try again later.")
            }







        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}



function addproject() {
    var pname = $.trim($("#a_projectname").val());
    var pcontractor = $.trim($("#a_contractor").val());
    var dfrom = $.trim($("#dfrom").val());
    var dto = $.trim($("#dto").val());
    var desc = $.trim($("#a_desc").val());
    var pbudget = $.trim($("#p_budget").val());
    var dataString = "proj_name=" + pname + "&proj_contractor=" + pcontractor + "&dfrom=" + dfrom + "&dto=" + dto + "&desc=" + desc + "&pbudget=" + pbudget;


    var url = '../backend/addproject';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {




            if (data.trim() === 'success') {

                success("Added Successfully !")
                clearprojdetail();
                backs1();



            } else {
                failed("Failed, Please try again later.")
            }





        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}

function clearprojdetail() {
    $("#a_projectname").val("");
    $("#a_contractor").val("");
    $("#dfrom").val("");
    $("#dto").val("");
    $("#a_desc").val("");
    $("#p_budget").val("");

}


function getprojectlist() {
    var dataString = "";
    var url = '../backend/projectlist';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#project_list").html(data);
            $("#plist_table").DataTable();





        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function deleteprojectconfirm(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            deleteproject(id)
        }
    })
}



function deleteproject(id) {
    var dataString = "id=" + id;
    var url = '../backend/deleteproject';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {

                success("Deleted Successfully !")

                getprojectlist();

            } else {
                failed("Failed, Please try again later.")
            }







        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function viewproject(id) {
    var dataString = "id=" + id;
    var url = '../backend/viewproject';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#p_content").html(data);




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function delitem(id, projid) {
    var dataString = "id=" + id;
    var url = '../backend/delitem';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {

                viewitemexp(projid);


            } else {
                failed("Failed, Please try again later.")
            }







        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function viewitemexp(id) {
    var dataString = "id=" + id;
    var url = '../backend/vitemlist';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#t_itemlist").html(data);





        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function approveproject(id) {

    var dataString = "id=" + id;
    var url = '../backend/approveproject';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            if (data.trim() === 'success') {

                success("Project Approved Successfully !");
                getprojectlist();
                $("#vproject_mod").modal("hide");

            } else {
                failed("Failed, Please try again later.")
            }





        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function rejectproject(id) {

    var dataString = "id=" + id;
    var url = '../backend/rejectproject';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            if (data.trim() === 'success') {

                success("Project Rejected !");
                getprojectlist();
                $("#vproject_mod").modal("hide");


            } else {
                failed("Failed, Please try again later.")
            }





        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function updateproject(id) {
    var u_pname = $.trim($("#u_pname").val());

    var u_pcontractor = $.trim($("#u_pcontractor").val());

    var u_pbudget = $.trim($("#u_pbudget").val());
    var u_dfrom = $.trim($("#u_dfrom").val());
    var u_dto = $.trim($("#u_dto").val());
    var u_desc = $.trim($("#u_desc").val());

    var dataString = "proj_name=" + u_pname + "&proj_contractor=" + u_pcontractor + "&dfrom=" + u_dfrom + "&dto=" + u_dto + "&desc=" + u_desc + "&pbudget=" + u_pbudget + "&id=" + id;


    var url = '../backend/updateproject';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {




            if (data.trim() === 'success') {
                getprojectlist();
                $("#vproject_mod").modal("hide");
                success("Changes Saved !")



            } else {
                failed("Failed, Please try again later.")
            }





        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}




////*** Dashboard Queries ***////

function getresidentcount() {
    var dataString = "";
    var url = '../backend/residentcount';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#resident_count").html(data);






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function getrequestcount() {
    var dataString = "";
    var url = '../backend/docreqcount';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#request_count").html(data);






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function getincidentcount() {
    var dataString = "";
    var url = '../backend/incidentcount';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#incident_count").html(data);






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function getprojectscount() {
    var dataString = "";
    var url = '../backend/projectscount';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#projects_count").html(data);






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function adduser() {
    var fname = $.trim($("#ufname").val());
    var position = $.trim($("#position").val());
    var contact = $.trim($("#ucontact").val());
    var username = $.trim($("#username").val());
    var password = $.trim($("#password").val());
    var utype = $.trim($("#utype").val());


    if (fname === '' && position === '' && contact === '' && username === '' && password === '' && utype === '') {
        warning("Missing Required Fields ")
    } else if (fname === '') {
        warning("Full Name is required !")
    } else if (position === '') {
        warning("Position is required !")
    } else if (contact === '') {
        warning("Contact is required !")
    } else if (username === '') {
        warning("Username is required !")
    } else if (password === '') {
        warning("Password is required !")
    } else if (utype === '') {
        warning("Please Select User type !")
    } else {




        var dataString = "name=" + fname + "&position=" + position + "&contact=" + contact + "&username=" + username + "&password=" + password + "&utype=" + utype;




        var url = '../backend/adduser';



        $.ajax({
            type: "POST",
            crossDomain: true,
            cache: false,
            url: url,
            data: dataString,
            beforeSend: function () {

            },
            success: function (data) {




                if (data.trim() === 'success') {

                    success("Added Successfully !")
getuserlist()
                    userclearfields();
                    $("#a_user").modal("hide");

                } else if (data.trim() === 'exists') {
                    warning("Username Already Exists !")
                } else {
                    failed("Failed, Please try again later.")
                }





            },
            error: function (jqXHR, status, err) {

            },
            complete: function (jqXHR, status) {



            }
        });
    }
}


function userclearfields() {
    $("#ufname").val("");
    $("#position").val("");
    $("#ucontact").val("");
    $("#username").val("");
    $("#password").val("");
    $("#utype").val("");
}


function getuserlist(){
    var dataString = "";
    var url = '../backend/userlist';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {




      
            $("#userlist").html(data);
            $("#utable").DataTable();



        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    }); 
}


function getu_details(id){
    
 
    var dataString = "id=" + id;
    var url = '../backend/useraccountdetails';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#eaccount_content").html(data);




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

    
}

function updateuser(id){
     var fname = $.trim($("#update_fname").val());
    var position = $.trim($("#update_position").val());
    var contact = $.trim($("#update_contact").val());
    var username = $.trim($("#update_username").val());
    var password = $.trim($("#update_password").val());
    var utype = $.trim($("#update_utype").val());
    
      var dataString = "name=" + fname + "&position=" + position + "&contact=" + contact + "&username=" + username + "&password=" + password + "&utype=" + utype + "&id="+id;
    
    var url = '../backend/updateuser';



        $.ajax({
            type: "POST",
            crossDomain: true,
            cache: false,
            url: url,
            data: dataString,
            beforeSend: function () {

            },
            success: function (data) {




                if (data.trim() === 'success') {

                    success("Changes Saved !")
                    getuserlist();
                    $("#e_user").modal("hide");

                } else if (data.trim() === 'exists') {
                    warning("Username Already Exists !")
                } else {
                    failed("Failed, Please try again later.")
                }





            },
            error: function (jqXHR, status, err) {

            },
            complete: function (jqXHR, status) {



            }
        });
}

function deleteuserconfirm(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            deleteuser(id)
        }
    })
}

function deleteuser(id){
    var dataString = "id=" + id;
    var url = '../backend/deleteuser';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {
                 getuserlist();
                    $("#e_user").modal("hide");
                success("Deleted Successfully !")




            } else {
                failed("Failed, Please try again later.")
            }






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}
function getudocumentlist(){
    var dataString = "";
    var url = '../backend/documentlist';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {




      
            $("#document_list").html(data);
            $("#dtable").DataTable();



        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    }); 
}

function deletedocument(id){
    var dataString = "id=" + id;
    var url = '../backend/deletedocument';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



            if (data.trim() === 'success') {
                 getudocumentlist();
                   
                success("Deleted Successfully !")




            } else {
                failed("Failed, Please try again later.")
            }






        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function deletedocumentconfirm(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            deletedocument(id)
        }
    })
}

function editdoc(id){
    var dataString = "id=" + id;
    var url = '../backend/editdocument';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#d_content").html(data);




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function updatedocument(id){
    
     var udname = $.trim($("#update_dname").val());
    var uamt = $.trim($("#update_amt").val());
    
      var dataString = "dname=" + udname + "&amt=" + uamt + "&id="+id;
    
 var url = '../backend/updatedocument';



        $.ajax({
            type: "POST",
            crossDomain: true,
            cache: false,
            url: url,
            data: dataString,
            beforeSend: function () {

            },
            success: function (data) {




                if (data.trim() === 'success') {

                    success("Changes Saved !")
                    getudocumentlist();
                    $("#dedit").modal("hide");

            
                } else {
                    failed("Failed, Please try again later.")
                }





            },
            error: function (jqXHR, status, err) {

            },
            complete: function (jqXHR, status) {



            }
        });   
}

function updateincidentstat(id,stat){
    
    if(stat === '1'){
       stat = "For Hearing";
       }else if (stat === '2'){
                 stat = "Resolved"; 
                 }
    
    var dataString = "id="+id+"&stat="+stat;
    
 var url = '../backend/updateincidentstat';



        $.ajax({
            type: "POST",
            crossDomain: true,
            cache: false,
            url: url,
            data: dataString,
            beforeSend: function () {

            },
            success: function (data) {




                if (data.trim() === 'success') {

                    success("Changes Saved !")
                   getincidentlist()
$("#incident_details").modal("hide");
            
                } else {
                    failed("Failed, Please try again later.")
                }





            },
            error: function (jqXHR, status, err) {

            },
            complete: function (jqXHR, status) {



            }
        });
}


function printreport(type){
    var url = '../documents/printreport'  + '?rtype=' +type;

    window.open(url, '_blank');  
}

function printcost(type,name,id){
    
    var url = '../documents/printcost'  + '?rtype=' +type+'&name='+name+'&id='+id;

    window.open(url, '_blank');  
}


function accountsettings(id){
    
     var dataString = "id=" + id;
    var url = '../backend/editaccount';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {





            $("#acc_content").html(data);




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function updateuseraccount(id){
    
      var upname = $.trim($("#update_username").val());
    var upoldpass = $.trim($("#opassword").val());
    var upnewpass = $.trim($("#npassword").val());
    
      var dataString = "upusername=" + upname + "&oldpass=" + upoldpass + "&newpass="+upnewpass+"&id="+id;
    
   
    var url = '../backend/updateaccount';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {



   if (data.trim() === 'success') {

                    success("Changes Saved !")
                   
$("#accountsettings").modal("hide");
            
                } else if(data.trim() === 'wrongpass'){
                          warning("Old Password Mimatch !")
                          }else{
                    failed("Failed, Please try again later.")
                }



          




        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}