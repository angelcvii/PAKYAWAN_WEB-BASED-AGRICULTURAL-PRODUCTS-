
function getReservationList(){
    var dataString = "";
    var url = '../backend/creservation.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#reservation_content").html(data);

            $("#dt_reservation_list").DataTable();
        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function res_details(id){

    var dataString = "rid="+id;
    var url = '../backend/reservation_details.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#reservation_modalcontent").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function cancel_order(id){

    var dataString = "rid="+id;
    var url = '../backend/cancel_reservation.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

           if(data==1){
            success("Request Cancelled !");
            $("#reservation_details_modal").modal("hide");
       
            setTimeout(function() {
                getReservationList();
              }, 1000);
           
           }else{

           }


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}



function dconfirm_creserve(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            cancel_order(id);
        }
    })
}