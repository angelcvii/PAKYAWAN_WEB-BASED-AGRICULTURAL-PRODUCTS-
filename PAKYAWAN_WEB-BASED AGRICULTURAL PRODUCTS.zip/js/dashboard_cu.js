function editprofile(){
    var dataString = "";
    var url = '../backend/userprofile_content.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#userprofile_content").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function up_profile() {
    var form = document.getElementById("userprofile_form");
    var fdata = new FormData(form);
    $.ajax({
      type: "POST",
      url: "../backend/u_profile.php",
      data: fdata,
      contentType: false,
      cache: false,
      processData: false,
      success: function (result) {
        if (result == 1) {
         
          success("Changes Saved !");
          $("#userprofile_modal").modal("hide");
       
          setTimeout(function() {
            location.reload();
          }, 1000);
     
        
        } else {
          failed("Failed, Please try again later.");
        }
      },
    });
  }


  function getHReservationList(){
    var dataString = "";
    var url = '../backend/chreservation.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#h_content").html(data);

            $("#dt_hreservation_list").DataTable();
        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function hres_details(id){

  var dataString = "rid="+id;
  var url = '../backend/reservation_details.php';



  $.ajax({
      type: "POST",
      crossDomain: true,
      cache: false,
      url: url,
      data: dataString,
      beforeSend: function () {

      },
      success: function (data) {

          $("#hreservation_modalcontent").html(data);


      },
      error: function (jqXHR, status, err) {

      },
      complete: function (jqXHR, status) {



      }
  });
}


//general functions
function hide_div(div){
  $("#"+div).hide();
}

function show_div(div){
  $("#"+div).show();
}





//Check Expired Reservation and Delete

function autodelete_expired_reservation(){

  var dataString = "";
  var url = '../backend/del_expiredreservation.php';


  $.ajax({
      type: "POST",
      crossDomain: true,
      cache: false,
      url: url,
      data: dataString,
      beforeSend: function () {

      },
      success: function (data) {

       
      },
      error: function (jqXHR, status, err) {

      },
      complete: function (jqXHR, status) {



      }
  });
}

