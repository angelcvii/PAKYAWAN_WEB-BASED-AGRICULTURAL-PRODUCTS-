function getAadminList() {
  var dataString = "";
  var url = "../backend/aadminlist.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#adminsettings_main_content").html(data);
      $("#dt_admin_list").DataTable();
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}
function edit_admin(id) {
  var dataString = "userid=" + id;
  var url = "../backend/e_admincontent.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#editadmin_content").html(data);
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function up_profile() {
  var form = document.getElementById("userprofile_form");
  var fdata = new FormData(form);
  $.ajax({
    type: "POST",
    url: "../backend/u_profile.php",
    data: fdata,
    contentType: false,
    cache: false,
    processData: false,
    success: function (result) {
      if (result == 1) {
        success("Changes Saved !");
        $("#editadmin_modal").modal("hide");
      } else {
        failed("Failed, Please try again later.");
      }
    },
  });
}

function dconfirm_admin(id) {
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      del_admin(id);
    }
  });
}

function del_admin(id) {
  var dataString = "id=" + id;
  var url = "../backend/del_admin.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Admin Deleted !");
        $("#editadmin_modal").modal("hide");
        getAadminList();
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function add_admin() {
  var uname = $("#up_username").val();
  var pword = $("#up_password").val();
  var fname = $("#up_fullname").val();
  var age = $("#up_age").val();
  var address = $("#up_address").val();
  var contact = $("#up_contact").val();
  var email = $("#up_email").val();

  const contactvalid = contact.slice(0, 2);
  let emailvalid = email.includes("@");

  if (
    uname === "" &&
    pword === "" &&
    fname === "" &&
    age === "" &&
    address === "" &&
    contact === "" &&
    email === ""
  ) {
    warning("Missing Fields Required !");
  } else if (contactvalid !== "09") {
    warning("Invalid Contact Number !");
  } else if (contact.length !== 11) {
    warning("Invalid Contact Number !");
  } else if (emailvalid == false) {
    warning("Invalid Email Account !");
  } else {
    var form = document.getElementById("addadmin_form");
    var fdata = new FormData(form);
    $.ajax({
      type: "POST",
      url: "../backend/a_admin.php",
      data: fdata,
      contentType: false,
      cache: false,
      processData: false,
      success: function (result) {
        if (result == 1) {
          success("Admin Added !");
          $("#addadmin_modal").modal("hide");
          getAadminList();

          resetform("addadmin_form");
        } else if (result == 3) {
          warning("Username Already Exists !");
        } else {
          failed("Failed, Please try again later.");
        }
      },
    });
  }
}

function resetform(id) {
  document.getElementById(id).reset();
}

//Product Category

function getPCatList() {
  var dataString = "";
  var url = "../backend/apcatlist.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#prodcat_main_content").html(data);
      $("#dt_pcat_list").DataTable();
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function edit_category(catid) {
  var dataString = "catid=" + catid;
  var url = "../backend/e_pcategory.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#editcatprod_content").html(data);
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function add_category() {
  var prodcat = $("#pcat").val();
  var dataString = "cat=" + prodcat;
  var url = "../backend/a_pcategory.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Category Added !");
        $("#addcategory_modal").modal("hide");
        getPCatList();
      } else if (data == 3) {
        warning("Product Category Exists !");
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function up_category(catid) {
  var prodcat = $("#up_pcat").val();
  var dataString = "cat=" + prodcat + "&catid=" + catid;
  var url = "../backend/up_pcategory.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Changes Saved !");
        $("#editcategory_modal").modal("hide");
        getPCatList();
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function delcon_cat(id) {
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      del_cat(id);
    }
  });
}

function del_cat(id) {
  var dataString = "catid=" + id;
  var url = "../backend/del_pcategory.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Category Deleted !");
        $("#editcategory_modal").modal("hide");
        getPCatList();
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

//Product Measurement
function getPMeasList() {
  var dataString = "";
  var url = "../backend/apmeslist.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#measurement_main_content").html(data);
      $("#dt_pmes_list").DataTable();
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function edit_measurement(mesid) {
  var dataString = "mesid=" + mesid;
  var url = "../backend/e_pmes.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#editmesprod_content").html(data);
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}
function add_measurement() {
  var prodmes = $("#pmes").val();
  var dataString = "mes=" + prodmes;
  var url = "../backend/a_pmes.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Measurement Added !");
        $("#addmeasurement_modal").modal("hide");
        getPMeasList();
      } else if (data == 3) {
        warning("Product Measurement Exists !");
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function delcon_mes(id) {
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      del_mes(id);
    }
  });
}

function del_mes(id) {
  var dataString = "mesid=" + id;
  var url = "../backend/del_pmes.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Measurement Deleted !");
        $("#editmeasurement_modal").modal("hide");
        getPMeasList();
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function up_mes(mesid) {
  var prodmes = $("#up_pmes").val();
  var dataString = "mes=" + prodmes + "&mesid=" + mesid;
  var url = "../backend/up_pmes.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Changes Saved !");
        $("#editmeasurement_modal").modal("hide");
        getPMeasList();
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}



function up_terms() {
  var terms = $("#terms").val();
  var dataString = "terms=" + terms ;
  var url = "../backend/up_terms.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Changes Saved !");
        $("#tc_modal").modal("hide");
      
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}


function up_pc() {
  var privacy = $("#privacy").val();
  var dataString = "privacy=" + privacy ;
  var url = "../backend/up_privacy.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Changes Saved !");
        $("#privacy_modal").modal("hide");
      
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}