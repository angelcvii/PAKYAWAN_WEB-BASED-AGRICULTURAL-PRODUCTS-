function active(id) {
    const element = document.getElementById(id);
    element.classList.add("active");
}

function notactive(id) {
    const element = document.getElementById(id);
    element.classList.remove("active");
}

///Seller Side Bar
//content
var sdash = "#Sdash_content";
var sorders = "#Sorders_content";
var sshop = "#Sshopprof_content";
var sprods = "#Sproducts_content";
var sreports = "#Sreports_content";
var saccount = "#Sacc_content";


//Sidebar item Name
var ssda = "side_sdasha";
var ssor = "side_sordersa";
var sspr = "side_sprofa";
var sspro = "side_sproductsa";
var ssre = "side_sreportsa";
var ssacc = "side_saccsetta";

sdashtab();
getorderscount();
function sdashtab() {
  $(sdash).show();
  $(sorders).hide();
  $(sshop).hide();
  $(sprods).hide();
  $(sreports).hide();
  $(saccount).hide();

  active(ssda);
  notactive(ssor);
  notactive(sspr);
  notactive(sspro);
  notactive(ssre);
  notactive(ssacc);
}

function sordertab() {
  $(sdash).hide();
  $(sorders).show();
  $(sshop).hide();
  $(sprods).hide();
  $(sreports).hide();
  $(saccount).hide();

  notactive(ssda);
  active(ssor);
  notactive(sspr);
  notactive(sspro);
  notactive(ssre);
  notactive(ssacc);
  getOrderList();

  getorderscount();
}

function sproftab() {
  $(sdash).hide();
  $(sorders).hide();
  $(sshop).show();
  $(sprods).hide();
  $(sreports).hide();
  $(saccount).hide();

  notactive(ssda);
  notactive(ssor);
  active(sspr);
  notactive(sspro);
  notactive(ssre);
  notactive(ssacc);
  getorderscount();
  getshopprof();
}

function sprodstab() {
  $(sdash).hide();
  $(sorders).hide();
  $(sshop).hide();
  $(sprods).show();
  $(sreports).hide();
  $(saccount).hide();

  notactive(ssda);
  notactive(ssor);
  notactive(sspr);
  active(sspro);
  notactive(ssre);
  notactive(ssacc);
  getorderscount();
  getProductsList();
}

function sreprttab() {
  $(sdash).hide();
  $(sorders).hide();
  $(sshop).hide();
  $(sprods).hide();
  $(sreports).show();
  $(saccount).hide();

  notactive(ssda);
  notactive(ssor);
  notactive(sspr);
  notactive(sspro);
  active(ssre);
  notactive(ssacc);
  getorderscount();
  getSRepchart();
}

function sacctab() {
  $(sdash).hide();
  $(sorders).hide();
  $(sshop).hide();
  $(sprods).hide();
  $(sreports).hide();
  $(saccount).show();

  notactive(ssda);
  notactive(ssor);
  notactive(sspr);
  notactive(sspro);
  notactive(ssre);
  active(ssacc);
  getorderscount();
}
