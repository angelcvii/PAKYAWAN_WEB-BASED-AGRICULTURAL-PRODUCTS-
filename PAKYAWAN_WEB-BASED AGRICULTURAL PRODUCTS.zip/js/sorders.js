function getOrderList(){
    var dataString = "";
    var url = '../backend/sorders.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#shop_orders_main_content").html(data);
            $("#dt_orders_list").DataTable();

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function res_details(id){

    var dataString = "rid="+id;
    var url = '../backend/sreservation_details.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#reservation_modalcontent").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function getPOList(){
    var dataString = "";
    var url = '../backend/sporders.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#processed_order_main_content").html(data);
            $("#dt_porders_list").DataTable();

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function getFDList(){
    var dataString = "";
    var url = '../backend/sforders.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#for_delivery_main_content").html(data);
            $("#dt_forders_list").DataTable();

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

function getOHList(){
    var dataString = "";
    var url = '../backend/shorders.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#history_main_content").html(data);
            $("#dt_horders_list").DataTable();

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function up_orderstat(rid, stat){

    var dataString = "rid="+rid+"&stat="+stat;
    var url = '../backend/up_ostat.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            if(data == 1){

                hidemodal("reservation_details_modal");
                success("Request Moved to "+ stat );
                getPOList();
                getFDList();
                getOHList();
                getOrderList();
                getorderscount();


            }else{
               
                hidemodal("reservation_details_modal");
                failed("Something's wrong !., Please try again later");
 
            }

          

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}


function getorderscount(){
    var dataString = "";
    var url = '../backend/sordercount.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#sorder_count").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


