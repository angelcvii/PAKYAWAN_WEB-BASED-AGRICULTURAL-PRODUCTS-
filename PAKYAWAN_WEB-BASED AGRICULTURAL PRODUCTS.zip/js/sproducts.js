function getProductsList(){
    var dataString = "";
    var url = '../backend/sproducts.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#shop_product_main_content").html(data);
            $("#dt_products_list").DataTable();

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function a_product() {

  var pname = $("#prodname").val();
  var pcat = $("#category").val();
  var sqm = $("#sqm").val();
  var price = $("#price").val();
  var cloc = $("#clocation").val();
  var pdate = $("#pdate").val();
  var hdate = $("#hdate").val();
  if(pname === "" && pcat === "" && sqm === "" && price === "" &&
  cloc === "" && pdate === "" && hdate === ""){
    warning("Missing Fields Required !");
  }else{

  

    var form = document.getElementById("addproduct_form");
    var fdata = new FormData(form);
    $.ajax({
      type: "POST",
      url: "../backend/add_product.php",
      data: fdata,
      contentType: false,
      cache: false,
      processData: false,
      success: function (result) {
        if (result = 1) {
         
          success("Product Added!");
          $("#addprod_modal").modal("hide");
       
          setTimeout(function() {
            getProductsList();
          }, 1000);
     
        
        } else {
          failed("Failed, Please try again later.");
        }
      },
    });
  }
}


  function editproduct(id){


    var dataString = "prodid="+id;
    var url = '../backend/eproduct.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#editprod_modalcontent").html(data);
          

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}
  

function dconfirm_dproduct(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            del_prod(id);
        }
    })
}

function del_prod(id){
    var dataString = "prodid="+id;
    var url = '../backend/dproduct.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            if(data == 1){
              hidemodal("editprod_modal");

                success("Product Removed !");
    
    
                setTimeout(function() {
                    getProductsList();
                  }, 1000);
            }else{
                failed("Failed, Please try again later."); 
            }

         
        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}



function u_product() {
  
  var pname = $("#u_prodname").val();
  var pcat = $("#u_category").val();
  var sqm = $("#usqm").val();
  var price = $("#u_price").val();
  var cloc = $("#u_clocation").val();
  var pdate = $("#u_pdate").val();
  var hdate = $("#u_hdate").val();
  if(pname === "" && pcat === "" && sqm === "" && price === "" &&
  cloc === "" && pdate === "" && hdate === ""){
    warning("Missing Fields Required !");
  }else if(pname === ""){

    warning("Product Name is Required !");
  }else if(pcat === ""){
    warning("Product Category is Required !");
  }else if(sqm === ""){
    warning("Farm Lot Size is Required!");
  }else if(cloc === ""){
    warning("Crop Location is Required");
  }else{
    var form = document.getElementById("updateproduct_form");
    var fdata = new FormData(form);
    $.ajax({
      type: "POST",
      url: "../backend/up_product.php",
      data: fdata,
      contentType: false,
      cache: false,
      processData: false,
      success: function (result) {
        if (result = 1) {
         
          success("Changes Saved !");
          $("#editprod_modal").modal("hide");
       
          setTimeout(function() {
            getProductsList();
          }, 1000);
     
        
        } else {
          failed("Failed, Please try again later.");
        }
      },
    });
  }
}