//=========LOGIN=========//

// Get the input field
var pwlog = document.getElementById("password");

// Execute a function when the user releases a key on the keyboard
pwlog.addEventListener("keypress", function (event) {
  // Number 13 is the "Enter" key on the keyboard
  if (event.key === "Enter") {
    // Cancel the default action, if needed
    event.preventDefault();
    // Trigger the button element with a click
    login();
  }
});

// Get the input field
var unlog = document.getElementById("username");

// Execute a function when the user releases a key on the keyboard
unlog.addEventListener("keypress", function (event) {
  // Number 13 is the "Enter" key on the keyboard
  if (event.key === "Enter") {
    // Cancel the default action, if needed
    event.preventDefault();
    // Trigger the button element with a click
    pwlog.focus();
  }
});

function login() {
  var uname = $("#username").val();
  var pword = $("#password").val();

  if (uname === "" && pword === "") {
    warning("Missing Fields Required !");
  } else {
    var form = document.getElementById("login_form");
    var fdata = new FormData(form);
    $.ajax({
      type: "POST",
      url: "backend/authenticate.php",
      data: fdata,
      contentType: false,
      cache: false,
      processData: false,
      success: function (result) {
        if (result == 1) {
          //admin
          setTimeout((window.location.href = "user/admin"), 1500);
          form.reset();
        } else if (result == 2) {
          //seller
          setTimeout((window.location.href = "user/seller"), 1500);
          form.reset();
        } else if (result == 3) {
          //customer
          setTimeout((window.location.href = "user/customer"), 1500);
          form.reset();
        } else if (result == 8) {
          //not Active

          warning("Please wait for your account approval ! .");

        } else if (result == 7) {
            warning("Your Account is blocked !");

        } else {
          failed("Access Denied !");
        }
      },
    });
  }
}

function resetform(id) {
  document.getElementById(id).reset();
}

///signup

function signup() {
  var uname = $("#username").val();
  var pword = $("#password").val();
  var fname = $("#fname").val();
  var address = $("#address").val();
  var contact = $("#contact").val();
  var email = $("#email").val();

  const contactvalid = contact.slice(0, 2);
  let emailvalid = email.includes("@");

  if (
    uname === "" &&
    pword === "" &&
    fname === "" &&
    address === "" &&
    contact === ""
  ) {
    warning("Missing Fields Required !");
  } else if (contactvalid !== "09") {
    warning("Invalid Contact Number !");
  } else if (contact.length !== 11) {
    warning("Invalid Contact Number !");
  } else if (emailvalid == false) {
    warning("Invalid Email Account !");
  } else {
    var form = document.getElementById("signup_form");
    var fdata = new FormData(form);
    $.ajax({
      type: "POST",
      url: "backend/signup.php",
      data: fdata,
      contentType: false,
      cache: false,
      processData: false,
      success: function (result) {
        if (result == 1) {
          success("Account Added !");

          form.reset();
        } else if (result == 4) {
          warning("Email Already Exists !");

          //  setTimeout((window.location.href = 'index.php'), 1500);
        } else {
          failed("Failed, Please try again later.");
        }
      },
    });
  }
}
