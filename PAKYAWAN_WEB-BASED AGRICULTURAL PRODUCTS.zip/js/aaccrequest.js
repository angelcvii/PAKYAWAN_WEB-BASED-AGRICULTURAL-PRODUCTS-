function getAccRList() {
  hide_div("activeacc_main");
  show_div("accreq_main");

  var dataString = "";
  var url = "../backend/accreqlist.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#accreq_main_content").html(data);
      $("#dt_accreq_list").DataTable();
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function getActiveAcc() {
  show_div("activeacc_main");
  hide_div("accreq_main");

  var dataString = "";
  var url = "../backend/accactivelist.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#activeacc_main_content").html(data);
      $("#dt_active_list").DataTable();
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function accrequests_count() {
  var dataString = "";
  var url = "../backend/accreqcount.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#req_count").html(data);
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function showprofile(id) {
  var dataString = "userid=" + id;
  var url = "../backend/req_userprofile_content.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#userprofile_content").html(data);
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function showshopprofile(id) {
  var dataString = "shopid=" + id;
  var url = "../backend/req_shopprofile_content.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      $("#userprofile_content").html(data);
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function up_account_stat(id, atype, isactive) {
  var dataString = "id=" + id + "&isactive=" + isactive;
  var url = "../backend/up_account_stat.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        if (atype == "2") {
          if (isactive == "1") {
            success(" Account is now Active !");
          } else if (isactive == "7") {
            success(" Account Blocked !");
          }
        } else if(atype == "") {
          if (isactive == "1") {
            success("Account is now Active !");
          } else if (isactive == "7") {
            success(" Account Blocked !");
          }
        }
        getAccRList();
        accrequests_count();
        hidemodal("userprofile_modal");
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}

function delconfirm_req(id, atype) {
  Swal.fire({
    title: "Are you sure?",
    text: "You won't be able to revert this!",
    icon: "warning",
    showCancelButton: true,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes, delete it!",
  }).then((result) => {
    if (result.isConfirmed) {
      del_areq(id, atype);
    }
  });
}

function del_areq(id, atype) {
  var dataString = "id=" + id;
  var url = "../backend/del_arequest.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        if (atype == "2") {
          success("Shop Account Deleted !");
        } else {
          success("User Account Deleted !");
        }
        getAccRList();
        accrequests_count();
        hidemodal("userprofile_modal");
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}
