//general functions
function hide_div(div){
    $("#"+div).hide();
  }
  
  function show_div(div){
    $("#"+div).show();
  }

  function hidemodal(id){
    $("#"+id).modal("hide");
}





function up_resfee() {
  var resfee = $("#resfee").val();
  var sellerid = $("#sellerid").val();
  var dataString = "resfee=" + resfee + "&sellerid="+sellerid ;
  var url = "../backend/up_resfee.php";

  $.ajax({
    type: "POST",
    crossDomain: true,
    cache: false,
    url: url,
    data: dataString,
    beforeSend: function () {},
    success: function (data) {
      if (data == 1) {
        success("Changes Saved !");
        $("#reserve_modal").modal("hide");
      
      } else {
        failed("Failed, Please try again later.");
      }
    },
    error: function (jqXHR, status, err) {},
    complete: function (jqXHR, status) {},
  });
}