function activetab(id) {
    var element = document.getElementById(id);
    element.classList.add("active");
}

function notactivetab(id) {
    var element = document.getElementById(id);
    element.classList.remove("active");
}


///Customer Side Bar

//content
var home = "#home_content";
var dash = "#dash_content";
var prod = "#prod_content";
var reserv = "#reserv_content";
var chistory = "#history_content";
var caccount = "#account_content";
var cartcontent = "#cart_content";
var shopcontent = "#shop_profile_content";


//Sidebar item Name
var schom = "side_chome";
var scda = "side_cdash";
var scpr = "side_cprod";
var scre = "side_creserv";
var schi = "side_chistory";
var scac = "side_caccount";



 chometab();
 cartCount();
 autodelete_expired_reservation();


 function chometab(){ 
    $(home).show();
    $(dash).hide();
    $(prod).hide();
    $(reserv).hide();
    $(chistory).hide();
    $(caccount).hide();
    $(cartcontent).hide();
    $(shopcontent).hide();
    activetab(schom);
    notactivetab(scda);
    notactivetab(scpr);
    notactivetab(scre);
    notactivetab(schi);
    notactivetab(scac);

    cartCount();

    
    show_div("hprodbycat_content");
          
    hide_div("search_products_content");
}


function cdashtab(){
    $(home).hide();
    $(dash).show();
    $(prod).hide();
    $(reserv).hide();
    $(chistory).hide();
    $(caccount).hide();
    $(cartcontent).hide();
    $(shopcontent).hide();
    notactivetab(schom);
    activetab(scda);
    notactivetab(scpr);
    notactivetab(scre);
    notactivetab(schi);
    notactivetab(scac);

    cartCount();
}


function cprodtab(){
    $(home).hide();
    $(dash).hide();
    $(prod).show();
    $(reserv).hide();
    $(chistory).hide();
    $(caccount).hide();
    $(cartcontent).hide();
    $(shopcontent).hide();
    notactivetab(schom);
    notactivetab(scda);
    activetab(scpr);
    notactivetab(scre);
    notactivetab(schi);
    notactivetab(scac);

    cartCount();
}

function cbreserve_tab(){
    $(home).hide();
    $(dash).hide();
    $(prod).hide();
    $(reserv).show();
    $(chistory).hide();
    $(caccount).hide();
    $(cartcontent).hide();
    $(shopcontent).hide();

    notactivetab(schom);
    notactivetab(scda);
    notactivetab(scpr);
    activetab(scre);
    notactivetab(schi);
    notactivetab(scac);

    cartCount();
    getReservationList();
}


function chistory_tab(){
    $(home).hide();
    $(dash).hide();
    $(prod).hide();
    $(reserv).hide();
    $(chistory).show();
    $(caccount).hide();
    $(cartcontent).hide();
    $(shopcontent).hide();

    notactivetab(schom);
    notactivetab(scda);
    notactivetab(scpr);
    notactivetab(scre);
    activetab(schi);
    notactivetab(scac);

    cartCount();

}

function cacc_tab(){
    $(home).hide();
    $(dash).hide();
    $(prod).hide();
    $(reserv).hide();
    $(chistory).hide();
    $(caccount).show();
    $(cartcontent).hide();
    $(shopcontent).hide();

    notactivetab(schom);
    notactivetab(scda);
    notactivetab(scpr);
    notactivetab(scre);
    notactivetab(schi);
    activetab(scac);

    cartCount();

}


function cart_content(){
    $(home).hide();
    $(dash).hide();
    $(prod).hide();
    $(reserv).hide();
    $(chistory).hide();
    $(caccount).hide();
    $(shopcontent).hide();
    $(cartcontent).show();
}


function shop_prof(){
    $(home).hide();
    $(dash).hide();
    $(prod).hide();
    $(reserv).hide();
    $(chistory).hide();
    $(caccount).hide();
    $(cartcontent).hide();
    $(shopcontent).show();
}


