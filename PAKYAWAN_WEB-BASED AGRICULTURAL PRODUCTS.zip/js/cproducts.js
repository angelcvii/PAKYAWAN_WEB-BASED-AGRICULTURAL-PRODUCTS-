function getcprodlist(catid) {
    var dataString = "catid="+catid;
    var url = '../backend/cproducts.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#prodbycat_content").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}




function s_cart(){
    var dataString = "";
    var url = '../backend/cart_itemlist.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#reservation_cart_content").html(data);
            cart_content();

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}



function UpQty(price,  prodid, operation){
   var itmqty =  $("#qty_prod"+prodid).val();

    if(operation == "add"){


       itmqty++;


      
    }else{

            if(itmqty==1){

            }else{
                itmqty--;
               
            }
          
        
           
        }
      

    
  
    

   


   var dataString = "pid="+prodid+"&qty="+itmqty+"&price="+price;
   var url = '../backend/up_cart.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            if(data==1){
                $("#qty_prod"+prodid).val(itmqty);
               s_cart();
               cartCount();
            }
          
          
           


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });




}



function addtocartmodal(prodid){
    var dataString = "productid="+prodid;
    var url = '../backend/addtocartmodal.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#cart_modalcontent").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function addtorcart(prodid, price){

    var qty = $("#itemqty").val();
    var dataString = "pid="+prodid+"&qty="+qty + "&price="+price;
    var url = '../backend/a_rcart.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            if(data==1){
                success("Added to Reservation cart !");
                hidemodal("product_addtocart");
                cartCount();
            }else{
                failed("Something's wrong !. Please try again later .")
            }


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


function hidemodal(id){
    $("#"+id).modal("hide");
}


function cartCount(){
    var dataString = "";
    var url = '../backend/cartcount.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#cart_count").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}



function dconfirm_citm(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            del_cartitm(id);
        }
    })
}


function del_cartitm(id){

    var dataString = "pid="+id;
    var url = '../backend/d_cartitm.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            if(data==1){
                success("Item Deleted !");
                s_cart();
                cartCount();
            }else{
                failed("Something's wrong !. Please try again later .")
            }


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}

function placeorder(prodid,subtotal, resfee, total){


   if( $('#terms').is(":checked")){

  

    var dataString = "prodid="+prodid+"&stot="+subtotal+"&rfee="+resfee+"&tot="+total;
    var url = '../backend/placeorder.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            if(data==1){
                success("Reservation Order Placed !");
                hidemodal("product_addtocart");

                setTimeout(function() {
                    cprodtab();
                  }, 1000);
                }else if(data == 7){  
                    warning("Product Already Reserved !");
            }else{
                failed("Something's wrong !. Please try again later .")
            }


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });

}else{
    warning("You must agree to terms and conditions before proceeding !");
}
}


function qProduct(search){

    var dataString = "search="+search;
    var url = '../backend/searchprod.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            if(data == 0){
                
            }else{

                hide_div("hprodbycat_content");
          
                show_div("search_products_content");
               
                $("#search_products_content").html(data);
           

            }

                

        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

//shop profile

function shopProfile(id){
    var dataString = "shopid="+id;
    var url = '../backend/shop_profile.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {
    
            shop_prof();
            hidemodal("product_addtocart");
            $("#shop_profile_content").html(data);
            viewedShop(id);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}

//shop prods

function getcprodlistS(catid,shopid) {
    var dataString = "catid="+catid+"&shopid="+shopid;
    var url = '../backend/cproductsS.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#sprods_content").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}


//View Shop Record

function viewedShop(shopid){
    var dataString = "shopid="+shopid;
    var url = '../backend/c_viewedshop.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {
    
      


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}