function gethomeprodlist(catid) {
    var dataString = "catid="+catid;
    var url = '../backend/hcproducts.php';



    $.ajax({
        type: "POST",
        crossDomain: true,
        cache: false,
        url: url,
        data: dataString,
        beforeSend: function () {

        },
        success: function (data) {

            $("#hprodbycat_content").html(data);


        },
        error: function (jqXHR, status, err) {

        },
        complete: function (jqXHR, status) {



        }
    });
}