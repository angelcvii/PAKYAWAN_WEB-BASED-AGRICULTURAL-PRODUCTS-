function getAProductList() {

    var dataString = "";
    var url = "../backend/aprodlist.php";
  
    $.ajax({
      type: "POST",
      crossDomain: true,
      cache: false,
      url: url,
      data: dataString,
      beforeSend: function () {},
      success: function (data) {
        $("#aprodlist_main_content").html(data);
        $("#dt_prod_list").DataTable();
      },
      error: function (jqXHR, status, err) {},
      complete: function (jqXHR, status) {},
    });
  }
  