<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Pakyawan Wholesale Crops Reservation | Sign In</title>
	<!-- Favicon -->
	<link rel="shortcut icon" href="./img/logo2.png" type="image/x-icon">
	<!-- Custom styles -->
	<link rel="stylesheet" href="./css/style.min.css">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>

<body class="theme_co" style="background-image:url('./img/bgimage.jpg'); background-size:cover;">
	<div class="layer"></div>
	<main class="page-center">
		<article class="sign-up">

			<form id="signup_form">
				<div class="sign-up-form form" style="width:80vh;">
					<center> <img src="img/logo2.png" style="height:25vh;">
					</center>



					<h5 class="login_title " style="color:#276900;"> Sign Up</h5>

					<h6 class="">Personal Information</h6>
					<hr class="success">
					<label class="form-label-wrapper">
						<p class="form-label">Full Name / Shop Name</p>
						<input class="form-input" type="text" placeholder="Enter your Full Name" id="fname"
							name="fname">
					</label>





					<label class="form-label-wrapper">
						<p class="form-label">Address</p>
						<input class="form-input" type="text" placeholder="Enter your Complete Address" id="address"
							name="address">
					</label>

					<h6 class="">I am a</h6>
					<hr class="success">

					<input type="radio" class="form-input-check bg-success" checked name="userrole" value="2"><i
						class="bi bi-shop"></i> SHOP / SELLER &nbsp;
					<input type="radio" class="form-input-check " name="userrole" value="3"><i class="bi bi-person"></i>
					CUSTOMER

					<br><br>

					<h6 class="">Contact Information</h6>
					<hr class="success">
					<label class="form-label-wrapper">
						<p class="form-label">Contact</p>
						<input class="form-input" type="number" placeholder="Enter your contact" id="contact"
							name="contact">
					</label>

					<label class="form-label-wrapper">
						<p class="form-label">Email</p>
						<input class="form-input" type="text" placeholder="Enter your email" id="email" name="email">
					</label>
					<h6 class="">Account Information</h6>
					<hr class="success">
					<label class="form-label-wrapper">
						<p class="form-label">Username</p>
						<input class="form-input" type="text" placeholder="Enter your username" id="username"
							name="username">
					</label>
					<label class="form-label-wrapper">
						<p class="form-label">Password</p>
						<input class="form-input" type="password" placeholder="Enter your password" id="password"
							name="password">
					</label>
					<h6 class="">Upload atleast 1 Valid ID</h6>
					<hr class="success">
					<label class="form-label-wrapper">
						<p class="form-label">Valid ID</p>
						<input class="form-input" type="file" id="validid" name="validid">
					</label>
					<br>
					<a class="link-success forget-link" href="index.php">Already have an account? Log in</a>

					<a href="#" class="form-btn btn btn-success " onclick="signup()">Sign Up</a>


				</div>

			</form>
		</article>
	</main>

	<script type="text/javascript" src="./js/mdb.min.js"></script>
	<script src="./js/jquery.js"></script>

	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


	<script src="./js/login.js"></script>
	<script src="./js/notif.js"></script>
</body>

</html>