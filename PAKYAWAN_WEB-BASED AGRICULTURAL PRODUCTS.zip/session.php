<?php
session_start();
$uid = $_SESSION["uid"];
$ut = $_SESSION["user_role"];

if($uid==""){
    header("location:../index.php");
}
?>