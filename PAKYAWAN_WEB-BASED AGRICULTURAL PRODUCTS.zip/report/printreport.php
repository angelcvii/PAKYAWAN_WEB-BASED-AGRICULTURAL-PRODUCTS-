<?php
  session_start();
  $shopid = $_SESSION['uid'];
  $path = "../data/shop/";

  include "../db.php";
  $sql = "SELECT *  FROM m_user_info where userid = '$shopid'  ";
  $result = $con->query($sql);
  if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      $shopname = $row['shopname'];
      $s_desc = $row['s_description'];
      $s_banner = $row['s_banner'];
      $s_logo = $row['s_logo'];
      $s_address = $row['address'];

      if ($s_logo == "") {
          $s_logo = "default.png";
      }

      if ($s_banner == "") {
          $s_banner = "shop.jpg";
      }

      if ($s_desc == "") {
          $s_desc = "This is a sample shop description";
      }
  }

  ?>

<!DOCTYPE html>
<html lang="">

<head>
	<meta charset="utf-8">
	<title>Pakyawan Shop Management System</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

	<!-- base:js -->
	<script src="../vendors/base/vendor.bundle.base.js"></script>
	<!-- endinject -->
	<!-- Plugin js for this page-->
	<!-- End plugin js for this page-->
	<!-- inject:js -->
	<script type="text/javascript" src="../js/mdb.min.js"></script>
	<script src="../js/off-canvas.js"></script>
	<script src="../js/hoverable-collapse.js"></script>

	<!-- endinject -->
	<!-- plugin js for this page -->
	<script src="../vendors/chart.js/Chart.min.js"></script>
	<script src="../vendors/jquery-bar-rating/jquery.barrating.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.2/datatables.min.css" />
	<link rel="icon" type="image/x-icon" href="" />
</head>
<script type="text/javascript">
	function wprint() {
		window.print()
	}
	setTimeout(function() {
		wprint();
	}, 1000);
</script>

<body>




	<div id="docx" class="container-fluid border border-success rounded col"
		style="height:100vh; background-image:src('img/logo.png');">
		<div class="row" style="margin-top:1vh;">
			<div class="col-1 ">
				<img src="<?php echo $path.$s_logo; ?>"
					height="100px" width="100px">
			</div>

			<div class="col-9">
				<center>
					<p class="text-center" style="font-family:Times New Roman;margin-left:8vw;">

					<h4 class="text-center" style="font-family:Times New Roman">
						<?php echo $shopname; ?>
					</h4> <i
						class="text-center"><?php echo  $s_address; ?>
					</i>


					</p>
				</center>
			</div>

			<div class="col-1 ">
				<img src="../img/logo2.png" height="100px" width="100px">
			</div>
		</div>

		<br>

		<div class="row">
			<div class="col">
				<h4 class="text-center" style="font-family:Times New Roman"> System Report</h4>
			</div>
		</div>

		<div id="content">

			<h4 class="text-center" style="font-family:Times New Roman"> Chart
			</h4>
			<div class="container">

				<canvas id="ocount" style="height:100px; ">
				</canvas>
			</div>


			<br>
			<h4 class="text-center" style="font-family:Times New Roman"> Data
			</h4>
			<br>
			<hr style="margin:1vh;">

			<table id="dt_horders_list" class="table table-striped table-bordered table-hover   ">
				<thead>
					<tr>
						<th> Transaction No </th>
						<th>Customer</th>
						<th>Total Amount </th>
						<th> Address</th>
						<th> Status </th>
						<th> Reservation Date</th>

					</tr>
				</thead>
				<tbody>
					<?php


          $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed'  order by id desc  ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $customer_id = $rowz['buyer_id'];
          $drid = $rowz['id'];
          $transaction_no = $rowz['transaction_no'];

          $ostat = $rowz['status'];
          $reservation_date = $rowz['added_date'];
          $subtotal= $rowz['subtotal'];
          $resfee= $rowz['res_fee'];
          $totalamount = $rowz['total_amount'];


          $sqlg = "SELECT *  FROM m_user_info where userid = '$customer_id'";
          $resultg = $con->query($sqlg);

          if ($resultg->num_rows > 0) {
              $rowg = $resultg->fetch_assoc();
              $fullname = $rowg['fullname'];

              $contact = $rowg['contact'];
              $address = $rowg['address'];
              $email = $rowg['email'];
              $age = $rowg['age'];
              $image = $rowg['image'];
          }


          $prodid = $rowz['product_id'];



          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $rowm = $resultm->fetch_assoc();





              ?>


					<tr>
						<td><?php echo  $transaction_no; ?></td>
						<td><?php echo $fullname; ?></td>
						<td><?php echo  $totalamount; ?></td>

						<td><?php echo $address; ?></td>

						<td><?php echo $ostat; ?>
						</td>
						<td><?php echo  $reservation_date; ?>
						</td>

						</td>
					</tr>


					<?php

          }
      }
  }




  ?>


				</tbody>
			</table>






		</div>




	</div>



	<!--- chart--->
	<div id="chart_panel">










		<?php
            include "../db.php";

  $months = array();
  $monthData = array();
  $months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  $curryear = date('Y');

  $jf = $curryear . "-01-01 00:00:00";
  $jt = $curryear . "-01-31 00:00:00";

  $ff = $curryear . "-02-01";
  $ft = $curryear . "-02-28";

  $mcf = $curryear . "-03-03";
  $mct = $curryear . "-03-31";

  $apf = $curryear . "-04-01";
  $apt = $curryear . "-04-30";

  $myf = $curryear . "-05-01";
  $myt = $curryear . "-05-30";

  $jnf = $curryear . "-06-01";
  $jnt = $curryear . "-06-31";

  $jlf = $curryear . "-07-01";
  $jlt = $curryear . "-07-30";

  $agf = $curryear . "-08-01";
  $agt = $curryear . "-08-31";

  $sef = $curryear . "-09-01";
  $set = $curryear . "-09-30";

  $ocf = $curryear . "-10-01";
  $oct = $curryear . "-10-31";

  $nof = $curryear . "-11-01";
  $not = $curryear . "-11-30";

  $def = $curryear . "-12-01";
  $det = $curryear . "-12-31";








  $jdata = array();
  $fdata = array();
  $mdata = array();
  $adata = array();
  $mydata = array();
  $jndata = array();
  $jldata = array();
  $audata = array();
  $sedata = array();
  $odata = array();
  $ndata = array();
  $ddata = array();



  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$jf' and '$jt' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $jdata[] =  $totalAmt;
          }
      }
  }



  $monthData[] = array_sum($jdata);

  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$ff' and '$ft' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $fdata[] =  $totalAmt;
          }
      }
  }



  $monthData[] = $fdata;

  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$mcf' and '$mct' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $mdata[] =  $totalAmt;
          }
      }
  }



  $monthData[] = array_sum($mdata);

  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$apf' and '$apt' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $adata[] =  $totalAmt;
          }
      }
  }



  $monthData[] = array_sum($adata);


  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$myf' and '$myt' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $mydata[] =  $totalAmt;
          }
      }
  }



  $monthData[] =  array_sum($mydata);



  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$jnf' and '$jnt' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $jndata[] =  $totalAmt;
          }
      }
  }



  $monthData[] =  array_sum($jndata);


  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$jlf' and '$jlt' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $jldata[] =  $totalAmt;
          }
      }
  }



  $monthData[] =  array_sum($jldata);


  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$agf' and '$agt' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $audata[] =  $totalAmt;
          }
      }
  }



  $monthData[] =  array_sum($audata);

  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$sef' and '$set' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $sedata[] =  $totalAmt;
          }
      }
  }



  $monthData[] =  array_sum($sedata);




  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$ocf' and '$oct' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $odata[] =  $totalAmt;
          }
      }
  }



  $monthData[] =  array_sum($odata);


  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$nof' and '$not' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];

          $prodid = $rowz['product_id'];
          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $ndata[] =  $totalAmt;
          }
      }
  }



  $monthData[] =  array_sum($ndata);


  $sqlz = "SELECT  *  FROM d_reservation_details where status = 'Completed' and added_date BETWEEN '$def' and '$det' ";
  $resultz = $con->query($sqlz);
  if ($resultz->num_rows > 0) {
      while ($rowz = $resultz->fetch_assoc()) {
          $drid = $rowz['id'];
          $totalAmt = $rowz['total_amount'];
          $prodid = $rowz['product_id'];

          $sqlm = "SELECT  *  FROM d_product where id = '$prodid' and seller_id = '$shopid'  ";
          $resultm = $con->query($sqlm);
          if ($resultm->num_rows > 0) {
              $ddata[] =  $totalAmt;
          }
      }
  }



  $monthData[] =  array_sum($ddata);





  ?>

	</div>
	<script>
		var ctx = document.getElementById("ocount");
		var myChart = new Chart(ctx, {
			backgroundColor: "#fff",
			type: 'bar',
			data: {
				datasets: [{


					label: "<?php echo $curryear; ?> Reservations",
					type: "bar",
					backgroundColor: "#E11E0C",
					data: <?php echo json_encode($monthData) . ','; ?>
						// This binds the dataset to the right y axis
						yAxisID: 'right-y-axis',
					fill: false,



				}],
				labels: <?php echo json_encode($months) . ','; ?>
			},
			options: {
				scales: {
					yAxes: [{
						id: 'right-y-axis',
						type: 'linear',
						position: 'left',
						ticks: {
							beginAtZero: true
						},

					}]
				}
			}
		});
		ctx.style.height = "50vh";
		ctx.style.width = "90vw";
	</script>

</body>

<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
	integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">

</script>

</html>