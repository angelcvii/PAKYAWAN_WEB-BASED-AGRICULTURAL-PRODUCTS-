<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Pakyawan Wholesale Crops Reservation | Sign In</title>
	<!-- Favicon -->
	<link rel="shortcut icon" href="./img/logo2.png" type="image/x-icon">
	<!-- Custom styles -->
	<link rel="stylesheet" href="./css/style.min.css">
	<link rel="stylesheet" href="./css/main_login.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>

<body class="theme_co" style="background-image:url('./img/bgimage.jpg'); background-size:cover;">
	<div class="layer"></div>
	<main class="page-center">
		<article class="sign-up">

			<form id="login_form">
				<div class="sign-up-form form">
					<center> <img src="img/logo2.png" style="height:20vh;width:18vh;"></center>


					<center>
						<h6 class="login_title text-center" style="color:#276900;"> WHOLESALE CROP RESERVATION</h6>
					</center>
					<label class="form-label-wrapper">
						<p class="form-label">Username</p>
						<input class="form-input" type="text" placeholder="Enter your username" id="username"
							name="username">
					</label>
					<label class="form-label-wrapper">
						<p class="form-label">Password</p>
						<input class="form-input" type="password" placeholder="Enter your password" id="password"
							name="password">
					</label>
					<a class="link-success forget-link" href="signup.php">Dont have account ? Signup</a>

					<a href="#" class="form-btn primary-default-btn theme_co_btn" onclick="login()"
						style="text-decoration:none;">Sign in</a>


				</div>

			</form>
		</article>
	</main>

	<script type="text/javascript" src="./js/mdb.min.js"></script>
	<script src="./js/jquery.js"></script>

	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


	<script src="./js/login.js"></script>
	<script src="./js/notif.js"></script>
</body>

</html>