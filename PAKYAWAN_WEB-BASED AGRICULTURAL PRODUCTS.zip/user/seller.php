<?php
include "../session.php";

?>

<?php
include "../db.php";
$sql = "SELECT *  FROM m_user where id = '$uid'";
$result = $con->query($sql);
$rowb = $result->fetch_assoc();

$uname = $rowb['username'];
?>
<?php
include "../includes/top_page.php"

?>

<?php
include "../includes/head_navS.php"

?>

<div class="container-fluid page-body-wrapper">
	<!----Sidebar--->
	<?php
    include "../includes/sidebar_ow.php"

?>

	<!------->

	<div class="main-panel">
		<div class="content-wrapper">

			<div id="user_greet" hidden>
				<?php include "../includes/user_greet.php"; ?>
			</div>

			<div id="Sdash_content">
				<?php include "../tabs/dashboard_ow.php"; ?>
			</div>

			<div id="Sorders_content">
				<?php include "../tabs/sorder_list.php"; ?>
			</div>

			<div id="Sshopprof_content">
				<?php include "../tabs/sprof.php"; ?>
			</div>

			<div id="Sproducts_content">
				<?php include "../tabs/sprod_list.php"; ?>
			</div>

			<div id="Sreports_content">

				<?php include "../tabs/sreport.php"; ?>

			</div>

			<div id="Sacc_content">
				<?php include "../tabs/caccount.php"; ?>
			</div>


		</div>
		<?php include "../includes/footer.php"; ?>
	</div>

</div>

<?php
include "../includes/sbottom_page.php";

?>


<div class="modal fade" id="reservation_details_modal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Reservation Details</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" id="reservation_modalcontent">





			</div>

		</div>
	</div>
</div>



<div class="modal fade" id="privacy_policy_modal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><i class="fa fa-eye"></i> Privacy Policy</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" id="privacy_modalcontent">


				<?php

                include "../db.php";

$sql = "SELECT *  FROM m_privacy";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$privacy = $row['description'];

?>

				<p style="text-align: justify;
  text-justify: inter-word;"><?php echo $privacy; ?>
				</p>

			</div>

		</div>
	</div>
</div>


<div class="modal fade" id="tc_modal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><i class="fa fa-eye"></i> Terms and Conditions</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" id="tc_modalcontent">


				<?php



$sql = "SELECT *  FROM m_terms";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$terms = $row['description'];

?>

				<p style="text-align: justify;
  text-justify: inter-word;"><?php echo $terms; ?>
				</p>


			</div>

		</div>
	</div>
</div>



<div class="modal fade" id="reserve_modal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  ">
		<div class="modal-content">
			<div class="modal-header">
				<h4>Reservation Fee</h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>

			<input id="sellerid" value="<?php echo $uid; ?>" hidden>
			<div class="modal-body" id="tc_content">

				<?php

include "../db.php";
$sql = "SELECT *  FROM d_reservation_fee where seller_id = '$uid' ";
$result = $con->query($sql);
$rowb = $result->fetch_assoc();

$fee = $rowb['fee'];
?>


				<textarea id="resfee" class="form-control form-control-lg"
					style="height:40vh;"><?php echo $fee; ?></textarea>
				<br>
				<a href="#" class="btn btn-rounded btn-outline-success float-end" onclick="up_resfee()"><i
						class="fa fa-check approved"></i> Save Changes</a>
			</div>



		</div>
	</div>
</div>