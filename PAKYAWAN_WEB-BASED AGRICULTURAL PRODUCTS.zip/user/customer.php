<?php
include "../session.php";

?>
<?php
include "../includes/top_page.php"

?>

<?php
include "../includes/head_nav.php"

?>

<div class="container-fluid page-body-wrapper">
	<!----Sidebar--->
	<?php
    include "../includes/sidebar_cu.php"

?>

	<!------->

	<div class="main-panel">
		<div class="content-wrapper">

			<div id="user_greet">
				<?php
            include "../includes/user_greet.php"

?>
			</div>


			<div id="home_content">
				<?php
include "../tabs/chome.php";
?>

			</div>


			<div id="dash_content">
				<?php
include "../tabs/dashboard_cu.php";
?>

			</div>


			<div id="prod_content">
				<?php
include "../tabs/cproducts_list.php";
?>
			</div>

			<div id="reserv_content">
				<?php
include "../tabs/cbook_reservation.php";
?>
			</div>

			<div id="history_content">
				<?php
include "../tabs/cbook_history.php";
?>
			</div>


			<div id="account_content">
				<?php
include "../tabs/caccount.php";
?>
			</div>




			<div class="row" id="search_products_content" style="display:none;">

				<div class="col-lg-12 grid-margin stretch-card">
					<div class="card">
						<div class="card-body">

						</div>
					</div>
				</div>
			</div>




			<div id="cart_content">


				<div id="reservation_panel">
					<div class="row">

						<div class="col-sm-12 grid-margin stretch-card">
							<div class="card">
								<div class="card-body">
									<div>
										<h4><i class="bi bi-cart"></i> Reservation Cart</h4>


									</div>
									<hr>

									<div id="reservation_cart_content">

									</div>


								</div>
							</div>
						</div>
					</div>
				</div>





			</div>


			<div id="shop_profile_content">

			</div>







		</div>
		<?php
        include "../includes/footer.php"
?>
	</div>
	<!----Footer--->


	<!------->
</div>

<?php
include "../includes/bottom_page.php"

?>

<!-- cart modal must be accessible anywhere-->
<div class="modal fade" id="product_addtocart" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Product Details</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" id="cart_modalcontent">





			</div>

		</div>
	</div>
</div>




<div class="modal fade" id="privacy_policy_modal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><i class="fa fa-eye"></i> Privacy Policy</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" id="privacy_modalcontent">


				<?php

                include "../db.php";

$sql = "SELECT *  FROM m_privacy";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$privacy = $row['description'];

?>

				<p style="text-align: justify;
  text-justify: inter-word;"><?php echo $privacy; ?>
				</p>

			</div>

		</div>
	</div>
</div>


<div class="modal fade" id="tc_modal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><i class="fa fa-eye"></i> Terms and Conditions</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" id="tc_modalcontent">


				<?php



$sql = "SELECT *  FROM m_terms";
$result = $con->query($sql);
$row = $result->fetch_assoc();
$terms = $row['description'];

?>

				<p style="text-align: justify;
  text-justify: inter-word;"><?php echo $terms; ?>
				</p>


			</div>

		</div>
	</div>
</div>