<?php
include "../session.php";

?>

<?php
include "../db.php";
$sql = "SELECT *  FROM m_user where id = '$uid'";
$result = $con->query($sql);
$rowb = $result->fetch_assoc();

$uname = $rowb['username'];
?>
<?php
include "../includes/top_page.php"

?>

<?php
include "../includes/head_navA.php"

?>

<div class="container-fluid page-body-wrapper">
	<!----Sidebar--->
	<?php
    include "../includes/sidebar.php"

?>

	<!------->

	<div class="main-panel">
		<div class="content-wrapper">




			<div id="Adash_content">
				<?php include "../tabs/dashboard.php"; ?>
			</div>

			<div id="Aacc_req_content">
				<?php include "../tabs/aaccrequest_list.php"; ?>
			</div>


			<div id="Ashop_list_content">
				<?php include "../tabs/ashop_list.php"; ?>
			</div>

			<div id="Aproducts_list_content">
				<?php include "../tabs/aprod_list.php"; ?>
			</div>
			<div id="Aacc_settings_content">
				<?php include "../tabs/caccount.php"; ?>
			</div>
			<div id="ASettings_content">
				<?php include "../tabs/adminsettings.php"; ?>
			</div>




		</div>
		<?php
    include "../includes/footer.php"
?>
	</div>

</div>

<?php
include "../includes/abottom_page.php"

?>

<div class="modal fade" id="userprofile_modal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  modal-lg">
		<div class="modal-content">
			<div class="modal-header">

				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" id="userprofile_content">





			</div>

		</div>
	</div>
</div>




<div class="modal fade" id="tc_modal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  ">
		<div class="modal-content">
			<div class="modal-header">
				<h4>Terms & Conditions</h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" id="tc_content">

				<?php

                include "../db.php";
$sql = "SELECT *  FROM m_terms ";
$result = $con->query($sql);
$rowb = $result->fetch_assoc();

$terms = $rowb['description'];
?>


				<textarea id="terms" class="form-control form-control-lg"
					style="height:60vh;"><?php echo $terms; ?></textarea>
				<br>
				<a href="#" class="btn btn-rounded btn-outline-success float-end" onclick="up_terms()"><i
						class="fa fa-check approved"></i> Save Changes</a>
			</div>



		</div>
	</div>
</div>


<div class="modal fade" id="privacy_modal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog  ">
		<div class="modal-content">
			<div class="modal-header">
				<h4>Privacy Policy</h4>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body" id="p_content">


				<?php

include "../db.php";
$sql = "SELECT *  FROM m_privacy";
$result = $con->query($sql);
$rowb = $result->fetch_assoc();

$pc = $rowb['description'];
?>
				<textarea id="privacy" class="form-control form-control-lg"
					style="height:60vh;"><?php echo $pc; ?></textarea>
				<br>
				<a href="#" class="btn btn-rounded btn-outline-success float-end" onclick="up_pc()"><i
						class="fa fa-check approved"></i> Save Changes</a>
			</div>
		</div>

	</div>
</div>