 <div class="row">
 	<div class="col-sm-12 mb-4 mb-xl-0">
 		<h4 class="font-weight-bold text-dark">Hi,
 			<?php
            echo $_SESSION['username']; ?>
 			!
 		</h4>
 		<p class="font-weight-normal mb-2 text-muted">
 			<?php

include "../db.php";

 			$sql = "SELECT *  FROM m_welcome";
 			$result = $con->query($sql);
 			$row = $result->fetch_assoc();
 			$welcome = $row['description'];

 			?>

 			<?php echo $welcome; ?>


 		</p>
 	</div>
 </div>