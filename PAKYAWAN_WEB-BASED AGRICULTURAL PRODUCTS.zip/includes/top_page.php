<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Pakyawan Wholesale Crops Reservation</title>


	<link rel="stylesheet" href="../css/font-awesome.md5.css">
	<link rel="stylesheet" href="../css/google-font.css">
	<link rel="stylesheet" href="../css/main.css">
	<!-- base:css -->
	<link rel="stylesheet" href="../vendors/mdi/css/materialdesignicons.min.css">
	<link rel="stylesheet" href="../vendors/feather/feather.css">
	<link rel="stylesheet" href="../vendors/base/vendor.bundle.base.css">
	<!-- endinject -->
	<!-- plugin css for this page -->
	<link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css" />
	<link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="../vendors/jquery-bar-rating/fontawesome-stars-o.css">
	<link rel="stylesheet" href="../vendors/jquery-bar-rating/fontawesome-stars.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.2/datatables.min.css" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<script src="../vendors/chart.js/Chart.min.js"></script>
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<!-- End plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="../css/style.css">

	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.2/datatables.min.css" />
	<!-- endinject -->
	<link rel="shortcut icon" href="../img/logo2.png" />
</head>