 <!-- partial:partials/_sidebar.html -->

 <nav class="sidebar sidebar-offcanvas" id="sidebar">


 	<br> <br>
 	<ul class="nav">
 		<li class="nav-item active" id="side_chome">
 			<a class="nav-link " href="#" onclick="chometab()">
 				<i class="fa fa-home menu-icon"></i>
 				<span class="menu-title">Home</span>
 			</a>
 		</li>
 		<li class="nav-item " id="side_cdash">
 			<a class="nav-link " href="#" onclick="cdashtab()">
 				<i class="fa fa-user menu-icon"></i>
 				<span class="menu-title">Profile</span>
 			</a>
 		</li>

 		<li class="nav-item" id="side_cprod">
 			<a class="nav-link" href="#" onclick="cprodtab()">
 				<i class="fa fa-leaf menu-icon"></i>
 				<span class="menu-title">Products</span>
 			</a>
 		</li>

 		<li class="nav-item" id="side_creserv">
 			<a class="nav-link" href="#" onclick="cbreserve_tab()">
 				<i class="bi bi-cart-fill menu-icon"></i>
 				<span class="menu-title">Reservations</span> &nbsp;

 			</a>
 		</li>

 		<li class="nav-item" id="side_chistory" hidden>
 			<a class="nav-link" data-toggle="collapse" href="#" onclick="chistory_tab()">
 				<i class="fa fa-history menu-icon"></i>
 				<span class="menu-title"> History</span>



 			</a>

 		</li>




 		<li class="nav-item" id="side_caccount">
 			<a class="nav-link" href="#" onclick="cacc_tab()">
 				<i class="fa fa-shield menu-icon"></i>
 				<span class="menu-title">Account Settings </span>
 			</a>
 		</li>


 		<li class="nav-item" id="side_sprivacy">
 			<a class="nav-link" href="#" onclick="" data-bs-toggle="modal" data-bs-target="#privacy_policy_modal">
 				<i class="fa fa-eye menu-icon"></i>
 				<span class="menu-title">Privacy Policy </span>
 			</a>
 		</li>

 		<li class="nav-item" id="side_sterms">
 			<a class="nav-link" href="#" onclick="" data-bs-toggle="modal" data-bs-target="#tc_modal">
 				<i class="fa fa-handshake-o menu-icon"></i>
 				<span class="menu-title">Terms and Conditions </span>
 			</a>
 		</li>




 	</ul>
 </nav>
 <!-- partial -->