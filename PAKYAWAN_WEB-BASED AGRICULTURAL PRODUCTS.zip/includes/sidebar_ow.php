<!-- partial:partials/_sidebar.html -->

<nav class="sidebar sidebar-offcanvas" id="sidebar">


	<br> <br>
	<ul class="nav">
		<li class="nav-item active" id="side_sdasha">
			<a class="nav-link " href="#" onclick="sdashtab()">
				<i class="icon-box menu-icon"></i>
				<span class="menu-title">Dashboard</span>
			</a>
		</li>

		<li class="nav-item" id="side_sordersa">
			<a class="nav-link" href="#" onclick="sordertab()">
				<i class="fa fa-comment menu-icon"></i>
				<span class="menu-title">Reservation</span> &nbsp;
				<span class="badge badge-light" id="sorder_count">0</span>
			</a>
		</li>

		<li class="nav-item" id="side_sprofa">
			<a class="nav-link" data-toggle="collapse" href="#" onclick="sproftab()">
				<i class="bi bi-shop menu-icon"></i>
				<span class="menu-title"> Shop Profile</span>



			</a>

		</li>
		<li class="nav-item" id="side_sproductsa">
			<a class="nav-link" href="#" onclick="sprodstab()">
				<i class="fa fa-leaf menu-icon"></i>
				<span class="menu-title">Products</span>
			</a>
		</li>

		<li class="nav-item" id="side_sreserve">
			<a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#reserve_modal">
				<i class="fa fa-tags menu-icon"></i>
				<span class="menu-title">Reservation Fee</span>
			</a>
		</li>

		<li class="nav-item" id="side_sreportsa">
			<a class="nav-link" href="#" onclick="sreprttab()">
				<i class="fa fa-folder-open menu-icon"></i>
				<span class="menu-title">Reports</span>
			</a>
		</li>

		<li class="nav-item" id="side_saccsetta">
			<a class="nav-link" href="#" onclick="sacctab()">
				<i class="fa fa-shield menu-icon"></i>
				<span class="menu-title">Account Settings </span>
			</a>
		</li>
		<li class="nav-item" id="side_sprivacy">
			<a class="nav-link" href="#" onclick="" data-bs-toggle="modal" data-bs-target="#privacy_policy_modal">
				<i class="fa fa-eye menu-icon"></i>
				<span class="menu-title">Privacy Policy </span>
			</a>
		</li>

		<li class="nav-item" id="side_sterms">
			<a class="nav-link" href="#" onclick="" data-bs-toggle="modal" data-bs-target="#tc_modal">
				<i class="fa fa-handshake-o menu-icon"></i>
				<span class="menu-title">Terms and Conditions </span>
			</a>
		</li>








	</ul>
</nav>
<!-- partial -->