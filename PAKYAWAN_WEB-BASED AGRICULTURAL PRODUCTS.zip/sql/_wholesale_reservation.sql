-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2022 at 02:16 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `_wholesale_reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `d_feedback`
--

CREATE TABLE `d_feedback` (
  `id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `d_product`
--

CREATE TABLE `d_product` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `description` varchar(9000) NOT NULL,
  `price` varchar(200) NOT NULL,
  `measurement_id` varchar(100) NOT NULL,
  `qty` int(100) NOT NULL,
  `c_location` varchar(500) NOT NULL,
  `planted_date` date NOT NULL,
  `harvest_date` date NOT NULL,
  `image` varchar(500) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `d_product_views`
--

CREATE TABLE `d_product_views` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `views` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `d_reservation_details`
--

CREATE TABLE `d_reservation_details` (
  `id` int(11) NOT NULL,
  `transaction_no` varchar(100) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `reservation_fee_id` int(11) NOT NULL,
  `total_amount` varchar(100) NOT NULL,
  `status` varchar(200) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `d_reservation_fee`
--

CREATE TABLE `d_reservation_fee` (
  `id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `fee` varchar(200) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `m_category`
--

CREATE TABLE `m_category` (
  `id` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `image` varchar(500) NOT NULL,
  `added_by` varchar(200) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `m_measurement`
--

CREATE TABLE `m_measurement` (
  `id` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `added_by` varchar(200) NOT NULL,
  `added_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `m_user`
--

CREATE TABLE `m_user` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `user_role` int(11) NOT NULL,
  `isActive` int(11) NOT NULL,
  `added_by` varchar(200) NOT NULL,
  `added_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `m_user`
--

INSERT INTO `m_user` (`id`, `username`, `password`, `user_role`, `isActive`, `added_by`, `added_date`) VALUES
(1, 'admin', 'admin', 1, 1, 'admin', '2022-10-07 15:39:45'),
(2, 'seller', 'seller', 2, 1, 'admin', '2022-10-07 15:56:15'),
(3, 'customer', 'c1', 3, 1, 'account', '2022-10-07 16:00:43');

-- --------------------------------------------------------

--
-- Table structure for table `m_user_info`
--

CREATE TABLE `m_user_info` (
  `id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `fullname` varchar(500) NOT NULL,
  `shopname` varchar(500) NOT NULL,
  `address` varchar(500) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `d_feedback`
--
ALTER TABLE `d_feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `d_product`
--
ALTER TABLE `d_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `d_product_views`
--
ALTER TABLE `d_product_views`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `d_reservation_details`
--
ALTER TABLE `d_reservation_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `d_reservation_fee`
--
ALTER TABLE `d_reservation_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_category`
--
ALTER TABLE `m_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_measurement`
--
ALTER TABLE `m_measurement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_user`
--
ALTER TABLE `m_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `m_user_info`
--
ALTER TABLE `m_user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `d_feedback`
--
ALTER TABLE `d_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `d_product`
--
ALTER TABLE `d_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `d_product_views`
--
ALTER TABLE `d_product_views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `d_reservation_details`
--
ALTER TABLE `d_reservation_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `d_reservation_fee`
--
ALTER TABLE `d_reservation_fee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `m_category`
--
ALTER TABLE `m_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `m_measurement`
--
ALTER TABLE `m_measurement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `m_user`
--
ALTER TABLE `m_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `m_user_info`
--
ALTER TABLE `m_user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
